# SPDX-License-Identifier: MIT
"""Assemble exact qualified files from local licensed inputs plus this overlay.
No network, emulator, boot/CF access, binary patching or inferred license grant.
"""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import json
import os

def inside(path, parent):
    try:
        return os.path.commonpath([str(path), str(parent)]) == str(parent)
    except ValueError:
        return False

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--local-dos-croot', required=True, type=Path, help='Existing local own-media/private DOS-CROOT, not a Windows-only install directory')
    ap.add_argument('--out', required=True, type=Path, help='New private output directory; must not already exist')
    args = ap.parse_args()
    home = Path(__file__).resolve().parent
    source = args.local_dos_croot.resolve(strict=True)
    target = args.out.resolve()
    if not source.is_dir() or target.exists() or inside(target, source) or inside(source, target):
        ap.error('Source must be a directory; output must be new and separate from source.')
    metadata = json.loads((home / 'LOCAL-REQUIREMENTS.json').read_text(encoding='utf-8'))
    overlaid = set(metadata['first_party_overlay_paths'])
    inputs, failures = [], []
    seen = set()
    for record in metadata['files']:
        rel = PurePosixPath(record['path'])
        if rel.is_absolute() or any(x in ('', '.', '..') or ':' in x for x in rel.parts) or record['path'] in seen:
            ap.error('Unsafe or duplicate manifest path')
        seen.add(record['path'])
        base = home / 'DOS-CROOT' if record['path'] in overlaid else source
        candidate = base.joinpath(*rel.parts).resolve()
        if not inside(candidate, base.resolve()) or not candidate.is_file():
            failures.append(record['path'] + ': required local file missing or outside its source root')
            continue
        data = candidate.read_bytes()
        if len(data) != record['bytes'] or hashlib.sha256(data).hexdigest() != record['sha256']:
            failures.append(record['path'] + ': exact qualified length/hash mismatch')
            continue
        inputs.append((rel, candidate, record))
    if failures:
        raise SystemExit('Local inputs are incomplete or differ from qualified R1. No output written.\n' + '\n'.join(failures))
    if len(inputs) != metadata['complete_assembled_file_count']:
        ap.error('Unexpected file count')
    target.mkdir(parents=True, exist_ok=False)
    for rel, candidate, record in inputs:
        # Recheck bytes while copying, guarding source changes after the preflight.
        data = candidate.read_bytes()
        if len(data) != record['bytes'] or hashlib.sha256(data).hexdigest() != record['sha256']:
            raise SystemExit('Input changed during assembly; retain/discard this partial output manually: ' + str(candidate))
        destination = target.joinpath(*rel.parts)
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open('xb') as out:
            out.write(data)
    for rel, _, record in inputs:
        data = target.joinpath(*rel.parts).read_bytes()
        if len(data) != record['bytes'] or hashlib.sha256(data).hexdigest() != record['sha256']:
            raise SystemExit('Output verification failed: ' + str(rel))
    print(json.dumps({'status': 'PASS_HOST_BYTE_ASSEMBLY', 'verified_files': len(inputs), 'overlay_files': len(overlaid), 'separately_supplied_local_files': len(inputs) - len(overlaid), 'native_execution': False, 'output': str(target)}, indent=2))

if __name__ == '__main__':
    main()
