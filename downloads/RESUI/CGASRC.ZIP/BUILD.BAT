@ECHO OFF
CL /nologo /G0 /AS /Os FRESH.C /link /STACK:4096
