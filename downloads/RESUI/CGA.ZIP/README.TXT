CGA FRESH WINDOWS 3.0 SETUP

IBM XT/8088, 640 KB, IBM CGA RGBI, plain DOS 3.3 or later.
Original English retail Windows 3.0 Setup media is required and not included.
This first increment uses the project's fixed 640x200 monochrome driver and
XT Pixels System/Fixed/OEM fonts during original graphical Windows Setup.
Other fresh display modes are not qualified by this packet.

Extract this ZIP on the DOS computer with a DOS ZIP extractor that keeps
folders (for example PKUNZIP -D). Keep FRESH.EXE, FRESH.TXT, SETUP.EXE,
CGA and FRESH640 together. No Python or modern computer conversion is needed.
Use your usual DOS transfer/extraction tools; this is not a boot disk.

PATHS USED IN THIS EXAMPLE
  C:\CGAKIT           Extracted CGA kit; contains FRESH.EXE.
  C:\W30SRC           Original Windows media files; contains Microsoft's
                      SETUP.EXE and SETUP.INF, not this kit's SETUP.EXE.
  C:\CGAKIT\FRESH640  Display driver folder supplied by this kit.
  C:\WINDOWS          New Windows destination, chosen inside Windows Setup.
Substitute your actual drives/directories. Keep the kit and Windows media
in separate directories. FRESH takes the Windows MEDIA path as its argument.
It finds the display driver beside FRESH.EXE, independently of that argument.

For unchanged original Windows media already collected in C:\W30SRC, run:
  C:
  CD \CGAKIT
  FRESH C:\W30SRC
With this extraction directory, the launcher prints:
  Display driver path: C:\CGAKIT\FRESH640
Write down that complete path before pressing ENTER to start original Setup.
Q then ENTER cancels. Optional read-only input verification:
  FRESH /CHECK C:\W30SRC

If using original floppy disks instead, insert the first Windows Setup disk
and run FRESH A:\ from C:\CGAKIT. The display driver path is still
C:\CGAKIT\FRESH640. Insert the requested original disks for Microsoft files.

FRESH verifies original Setup and the bundled display files, then starts
ORIGINAL Microsoft Setup. It does not modify your Windows media, select
hardware automatically, copy the operating system for you, or install the
Tandy desktop.

IN ORIGINAL SETUP
1. Select a new Windows destination, normally C:\WINDOWS.
2. At System Information, move to Display and press ENTER.
3. Move DOWN to Other (the last choice), then press ENTER.
4. At the manufacturer's driver-disk prompt, enter C:\CGAKIT\FRESH640.
   If you extracted elsewhere, enter the exact display driver path printed
   by FRESH instead. C:\W30SRC is the Windows media path, not the driver path.
5. Select Windows XT IBM CGA 640x200 mono. Select No Changes to accept the
   hardware list, then continue original Setup.
6. For each later disk prompt, use the path for the disk it names:
   - Windows XT CGA fresh Setup: C:\CGAKIT\FRESH640.
   - Microsoft Windows 3.0 Disk #1 (or another Windows disk): C:\W30SRC.
     With original floppies, insert the requested Windows disk and use A:\.
   - If the disk name is blank and Copying shows CGA.GR2, give the original
     Windows Disk 3 path (C:\W30SRC when using the combined media folder).
   Setup may prefill the path from the previous disk request. Replace it
   when it names the other disk; do not accept the old path automatically.
   Choose the keyboard and mouse appropriate to your own computer.
7. Start the installed Windows from C:\WINDOWS with WIN /R.

Project display support is bundled. Original CGA.GR2 comes from your own
Windows Disk 3 through normal Setup; it is not in this ZIP. Do not gather stock CGA fonts
or edit INIs. The fresh candidate uses proportional XTC and compact wide 640-mode controls, and
does not require a placement/panning helper during graphical Setup.

AFTER WINDOWS IS INSTALLED
Exit Windows and use the complete CGA packet's SETUP for any other
mode, matching proportional dialog fonts and helper settings:
  SETUP C:\WINDOWS
or choose directly, for example SETUP C:\WINDOWS PAN or SETUP C:\WINDOWS 320C.
See CGAOLD.TXT for this existing-Windows route and its UNDO behavior. UNDO
restores that installer's starting configuration, which may be the fresh
CGA640 selection. It does not uninstall Windows or remove the fresh driver.

Keep the kit for later Windows Setup requests. Windows 3.1 and modified or
different Setup versions are refused. Physical hardware is unqualified.
FONTLIC.TXT, LOGOLIC.TXT and NOTICE.TXT retain the component terms.
FRESHLIC.TXT covers the launcher source; OWATCOM.TXT carries its runtime
notice.
Source and developer build: src/cga/FRESH.C and FRESHPK.PY in the repository.
The launcher source, compiled input header and project display inputs are
also supplied as CGASRC.ZIP. BUILD.BAT requires an external DOS C6 toolchain.
No operating system, compiler, emulator or disk image is included.
