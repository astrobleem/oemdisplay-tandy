"""Exact palette/fetch/decode functions used by native qualification.
Unused legacy cursor/400-row probes are excluded.
"""
import numpy as np
PAL=np.array([(0,0,0),(0,0,170),(0,170,0),(0,170,170),(170,0,0),(170,0,170),(170,85,0),(170,170,170),(85,85,85),(85,85,255),(85,255,85),(85,255,255),(255,85,85),(255,85,255),(255,255,85),(255,255,255)],dtype=np.uint8)
def fetch(raw,start):
 a=np.frombuffer(raw,dtype=np.uint8);y=np.arange(200)[:,None];xb=np.arange(160)[None,:]
 off=(y%4)*8192+((2*start+160*(y//4)+xb)&8191);b=a[off];r=np.empty((200,320),dtype=np.uint8);r[:,0::2]=b>>4;r[:,1::2]=b&15;return r
def decode(rgb,want,geom=None):
 h,w,_=rgb.shape;best=None
 candidates=[geom] if geom else [(ox,oy,sx,sy) for sx in [1,2] for sy in [1,2] for oy in range(min(81,max(0,h-sy*200+1))) for ox in range(17) if ox+320*sx<=w]
 target=PAL[want]
 for ox,oy,sx,sy in candidates:
  a=rgb[oy:oy+200*sy:sy,ox:ox+320*sx:sx]
  if a.shape!=(200,320,3):continue
  errors=int(np.count_nonzero(np.any(a!=target,axis=2)))
  if best is None or errors<best[0]:best=(errors,(ox,oy,sx,sy))
  if errors==0:break
 if best is None:raise RuntimeError('No complete320x200 capture geometry')
 return best
