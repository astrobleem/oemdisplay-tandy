from pathlib import Path
import sys,json,subprocess,os,time,base64,re
import numpy as np
from PIL import Image
W=Path(__file__).resolve().parent
sys.path.insert(0,r'C:\Users\chad\Documents\Codex\2026-10-14\task-16\deps-local')
sys.path.insert(0,r'E:\DOSMCP\mcp-server')
sys.path.insert(0,r'C:\Users\chad\Documents\Codex\2026-10-14\task-16')
from pyfatfs.PyFatFS import PyFatFS
from pyfatfs._exceptions import PyFATException
from src.gdbclient import GdbClient
from src.headless_input import HeadlessCtl,type_string
from hw_model import fetch,decode,PAL
from xy_lease import lease,hidden
O=W/sys.argv[1];m=json.loads((O/'MEDIA.json').read_text());assert Path(m['disk']).parent==O
records=[];dos_records=[];seen=set();g=ctl=p=None;error=None;done=False;guard=None;log=''
keys_sent=False
move_sent=False;size_sent=False
sent_keyfiles=set()
def expected(raw,left,top,kind,x,y):
    a=np.frombuffer(raw,dtype=np.uint8).reshape(256,4,80);b=np.unpackbits(a,axis=2)
    allpixels=b[:,0,:]*4+b[:,1,:]*2+b[:,2,:]+b[:,3,:]*8
    want=allpixels[top:top+200,left:left+320].copy()
    if kind:
        for yy in range(8):
            for xx in range(8):
                u=x-left+xx;v=y-top+yy
                if 0<=u<320 and 0<=v<200:want[v,u]=15 if xx==yy else 0
    return want
def readguest():
    with PyFatFS(m['disk'],offset=m['offset'],read_only=True) as fs:
        return (fs.readtext('XY.LOG') if fs.exists('XY.LOG') else '',fs.readtext('XYSTEP.TXT') if fs.exists('XYSTEP.TXT') else '',fs.exists('HPDONE.TXT'))
def dos_state(label):
    mode=g.read_memory(0x449,1)[0];page=g.read_memory(0x462,1)[0];bda=int.from_bytes(g.read_memory(0x44e,2),'little')
    index=g.in_port(0x3d4);g.out_port(0x3d4,12);hi=g.in_port(0x3d5);g.out_port(0x3d4,13);lo=g.in_port(0x3d5);g.out_port(0x3d4,index)
    text=g.read_memory(0xb8000,4000);(O/(label+'.BIN')).write_bytes(text)
    (O/(label+'.PNG')).write_bytes(base64.b64decode(ctl.capture_frame_png_b64()))
    r=dict(label=label,mode=mode,page=page,bda_offset=bda,start=hi*256+lo,chars=''.join(chr(x) if 32<=x<127 else ' ' for x in text[::2]));dos_records.append(r)
    assert mode==3 and page==0 and bda==0 and hi*256+lo==0,r
hidden()
with lease(O/'LEASE.json'),(O/'HOST.LOG').open('wb') as output:
    start=time.monotonic()
    try:
        p=subprocess.Popen([r'E:\DOSMCP\86Box\build\development\src\86Box.exe','-P',str(O),'-R',r'E:\x86box\roms','-N'],cwd=O,stdout=output,stderr=subprocess.STDOUT,env=dict(os.environ,QT_QPA_PLATFORM='offscreen',PATH=r'C:\msys64\ucrt64\bin;'+os.environ['PATH']))
        (O/'OWNED.json').write_text(json.dumps(dict(pid=p.pid,exe=r'E:\DOSMCP\86Box\build\development\src\86Box.exe')))
        for i in range(20):
            try:g=GdbClient(timeout=3);g.connect();ctl=HeadlessCtl('127.0.0.1',12346);break
            except (OSError,ConnectionError):
                if g:g.close();g=None
                time.sleep(.25)
        else:raise RuntimeError('Native control channels unavailable')
        while time.monotonic()-start<480:
            if p.poll() is not None:raise RuntimeError('Owned emulator exited')
            g.run_while(lambda:None,settle_seconds=.35,start_delay=.01)
            try:log,step,done=readguest()
            except PyFATException:continue
            (O/'LIVE.LOG').write_text(log)
            if 'STEP ' in step:
                v={k:int(x) for k,x in re.findall(r'(\w+)=(-?\d+)',step)};i=v['id']
                if i not in seen:
                    with PyFatFS(m['disk'],offset=m['offset'],read_only=True) as fs:
                        s=fs.readbytes('S%03d.BIN'%i);video=fs.readbytes('V%03d.BIN'%i)
                    want=expected(s,v['left'],v['top'],v['cursor'],v['x'],v['y']);actual=fetch(video,v['head'])
                    wrong=int(np.count_nonzero(actual!=want));assert wrong==0,(i,'VRAM pixels',wrong)
                    index=g.in_port(0x3d4);g.out_port(0x3d4,12);hi=g.in_port(0x3d5);g.out_port(0x3d4,13);lo=g.in_port(0x3d5);g.out_port(0x3d4,index)
                    assert hi*256+lo==v['head'],(i,'actual CRTC',hi*256+lo,v['head'])
                    now=g.read_memory(0x97ff0,16)
                    if guard is None:guard=now
                    assert now==guard,(i,'reservation MCB changed')
                    (O/('FRAME%03d.PNG'%i)).write_bytes(base64.b64decode(ctl.capture_frame_png_b64()))
                    rgb=np.asarray(Image.open(O/('FRAME%03d.PNG'%i)).convert('RGB'))
                    errors,geom=decode(rgb,want,[8,38,2,1]);assert errors==0,(i,'display',errors,geom)
                    Image.fromarray(PAL[want]).save(O/('VIEW%03d.PNG'%i));(O/('S%03d.BIN'%i)).write_bytes(s);(O/('V%03d.BIN'%i)).write_bytes(video)
                    records.append(dict(**v,pixels_wrong=wrong,display_wrong=errors,geometry=geom,mcb_intact=True));seen.add(i)
                    (O/'PROGRESS.json').write_text(json.dumps(dict(frames=len(records),latest=v,elapsed=time.monotonic()-start)))
                    print('FRAME',i,'PASS',v,flush=True)
            if not dos_records:
                with PyFatFS(m['disk'],offset=m['offset'],read_only=True) as fs:returned=fs.exists('HPRET1.TXT')
                if returned:
                    g.run_while(lambda:None,settle_seconds=.4,start_delay=.01);dos_state('DOS1')
                    g.run_while(lambda:type_string(ctl,'{ENTER}'),settle_seconds=.4,start_delay=.01)
            if done:
                g.run_while(lambda:None,settle_seconds=.4,start_delay=.01);dos_state('DOS2');break
        else:raise TimeoutError('Native 480 second watchdog')
    except Exception as e:error=repr(e);print('FAILED',error,flush=True)
    finally:
        if g:g.close()
        if ctl:ctl.close()
        if p and p.poll() is None:p.terminate()
        if p:
            try:p.wait(timeout=8)
            except subprocess.TimeoutExpired:p.kill();p.wait()
    with PyFatFS(m['disk'],offset=m['offset'],read_only=True) as fs:
        for n in ['XY.LOG','HPRET1.TXT','HPRET2.TXT','HPDONE.TXT','RESERVE.TXT','CW/HCTL.LOG']:
            if fs.exists(n):(O/Path(n).name).write_bytes(fs.readbytes(n))
    required=set(range(9))|{900,901}
    result=dict(status='PASS' if not error and done and required<=seen and len(dos_records)==2 and not re.search(r'CHECK \w+=0|FAILURES=[1-9]',log) else 'FAIL',error=error,frames=records,dos_states=dos_records,seconds=time.monotonic()-start,driver_sha256=m['driver_sha256'],hardware_tested=False,mem_kb=640,hz=m['hz'],ems=False,xms=False)
    (O/'RESULT.json').write_text(json.dumps(result,indent=2));print(result['status'],len(records),result['seconds'],flush=True)
