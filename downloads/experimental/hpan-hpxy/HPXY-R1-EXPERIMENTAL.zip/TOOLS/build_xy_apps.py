from pathlib import Path
import sys,shutil,subprocess,os,json,struct,hashlib
from xy_lease import lease,hidden,DOSBOX
W=Path(__file__).resolve().parent;O=W/sys.argv[1];O.mkdir()
P=W/'xy-source/experiments/XYPAN';names=sys.argv[2:] or ['XYQA','XYCTL']
for n in names:
 shutil.copyfile(P/(n+'.C'),O/(n+'.C'))
 (O/(n+'.DEF')).write_text("NAME "+n+"\nDESCRIPTION 'PRIVATE XY qualification/control'\nEXETYPE WINDOWS\nCODE PRELOAD FIXED\nDATA PRELOAD FIXED MULTIPLE\nHEAPSIZE 2048\nSTACKSIZE 4096\nEXPORTS\n Wnd @1\n"+(' Dlg @2\n' if n=='XYUI' else ''))
s='@ECHO OFF\nSET PATH=C:\\BIN\nSET INCLUDE=C:\\DDK\\286\\INC;C:\\INCLUDE\nSET LIB=C:\\LIB\n'
for n in names:s+='CL /nologo /c /AS /G0 /Gw /Zp /Od '+n+'.C > '+n+'.BLD\nLINK4 /NOD /NOE '+n+'.OBJ,'+n+'.EXE,NUL,C:\\LIB\\SLIBCEW.LIB C:\\LIB\\LIBW.LIB,'+n+'.DEF >> '+n+'.BLD\n'
(O/'BUILD.BAT').write_bytes((s+'EXIT\n').replace('\n','\r\n').encode())
(O/'BUILD.CNF').write_text('[sdl]\noutput=surface\n[dosbox]\nmachine=tandy\n[cpu]\ncycles=fixed 200000\n[mixer]\nnosound=true\n[autoexec]\nmount C "E:\\budmaker\\Claude-Build-Kit\\tools\\MSC6"\nmount D "'+str(O)+'"\nD:\nBUILD.BAT\n')
hidden()
with lease(O/'LEASE.json'),(O/'HOST.LOG').open('wb') as f:
 subprocess.run([str(DOSBOX),'-nopromptfolder','-conf',str(O/'BUILD.CNF')],stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy'),timeout=120,check=True)
records=[]
for n in names:
 log=(O/(n+'.BLD')).read_text();print(n,log,flush=True)
 assert not any(x in log.lower() for x in ['error c','fatal error','error l']),n
 p=O/(n+'.EXE');data=bytearray(p.read_bytes());ne=struct.unpack_from('<I',data,0x3c)[0];assert data[ne:ne+2]==b'NE';struct.pack_into('<H',data,ne+0x3e,0x300);p.write_bytes(data)
 records.append(dict(name=p.name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
(O/'BUILD.json').write_text(json.dumps(dict(status='PASS',apps=records,compiler='MSC6 /AS /G0 /Gw /Zp /Od; LINK4',target='Windows3.0 real mode 8088'),indent=2))
