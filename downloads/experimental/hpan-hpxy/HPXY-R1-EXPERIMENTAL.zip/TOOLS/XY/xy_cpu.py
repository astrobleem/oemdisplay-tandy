"""Execute linked HPAN NE routines in Unicorn16 with mocked cursor/ports.
Windows API integration and displayed output require the separate native run.
"""
from pathlib import Path
import sys,struct,re,json,random
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'deps'))
from unicorn import Uc,UC_ARCH_X86,UC_MODE_16,UC_HOOK_CODE,UC_HOOK_INSN,UC_HOOK_MEM_WRITE
from unicorn.x86_const import *
import numpy as np
W=Path(__file__).resolve().parents[1];B=W/sys.argv[1]
raw=(B/'HPXY.DRV').read_bytes();ne=struct.unpack_from('<I',raw,0x3c)[0]
u=Uc(UC_ARCH_X86,UC_MODE_16);u.mem_map(0,0x110000)
segments={};address=0x10000
cnt=struct.unpack_from('<H',raw,ne+0x1c)[0];table=ne+struct.unpack_from('<H',raw,ne+0x22)[0];shift=struct.unpack_from('<H',raw,ne+0x32)[0]
for i in range(1,cnt+1):
    off,n,flags,alloc=struct.unpack_from('<4H',raw,table+8*(i-1));size=max(n or (65536 if off else 0),alloc or 65536)
    segments[i]=dict(seg=address>>4,base=address,off=off<<shift,n=n or 65536,flags=flags,size=size)
    if off:u.mem_write(address,raw[off<<shift:(off<<shift)+(n or 65536)])
    address+=(size+4095)&~4095
for i,s in segments.items():
    if not s['flags']&0x100 or not s['off']:continue
    pos=s['off']+s['n'];count=struct.unpack_from('<H',raw,pos)[0]
    for j in range(count):
        typ,flags,src,t1,t2=struct.unpack_from('<BBHHH',raw,pos+2+j*8)
        target_seg=segments[t1&255]['seg'] if flags&3==0 and t1&255 in segments else 0
        dest=(struct.pack('<H',target_seg) if typ==2 else struct.pack('<HH',t2,target_seg) if typ==3 else struct.pack('<H',t2))
        assert typ in (2,3,5),(typ,flags)
        visited=set()
        while src!=65535:
            assert src not in visited;visited.add(src);p=s['base']+src
            nxt=struct.unpack('<H',u.mem_read(p,2))[0]
            if flags&4:
                value=(int.from_bytes(dest[:2],'little')+nxt)&65535
                u.mem_write(p,struct.pack('<H',value)+dest[2:]);break
            u.mem_write(p,dest);src=nxt
symbols={m[3]:(int(m[1],16),int(m[2],16)) for m in re.finditer(r'(?m)^\s*([0-9A-Fa-f]{4}):([0-9A-Fa-f]{4})\s+(\w+)\s*$',(B/'renderer/EGA/TSOFT.MAP').read_text())}
def sym(name):i,off=symbols[name];return segments[i]['base']+off
def word(name,v=None):
    p=sym(name)
    if v is None:return int.from_bytes(u.mem_read(p,2),'little')
    u.mem_write(p,struct.pack('<H',v&65535))
ds=segments[symbols['hp_left'][0]]['seg'];cs=segments[symbols['hp_set'][0]]['seg']
video=0xb8000;cursor_depth=0;ports=[];writes=[];toggle=[0];checks=0;blank=False;capture=False;stage_writes=[]
def hook(uc,address,size,data):
    global cursor_depth
    if address in (0x90000,(cs<<4)+0xf000):uc.emu_stop();return
    if address in (sym('cursor_hide'),sym('cursor_show')):
        cursor_depth+=1 if address==sym('cursor_hide') else -1
        assert cursor_depth>=0
        sp=uc.reg_read(UC_X86_REG_SP);ss=uc.reg_read(UC_X86_REG_SS)<<4
        ip,seg=struct.unpack('<HH',uc.mem_read(ss+sp,4));uc.reg_write(UC_X86_REG_SP,(sp+4)&65535);uc.reg_write(UC_X86_REG_CS,seg);uc.reg_write(UC_X86_REG_IP,ip)
def inp(uc,port,size,data):toggle[0]^=8;return toggle[0]
def out(uc,port,size,value,data):
    global blank
    ports.append((port,value))
    assert port in (0x3d4,0x3d5,0x3d8)
    if port==0x3d8:blank=not bool(value&8)
def wh(uc,access,address,size,value,data):
    if video<=address<video+32768 and capture:writes.append((address,size,blank))
    if sym('hp_stage')<=address<sym('hp_stage')+1440 and capture:stage_writes.append((address,size,blank))
u.hook_add(UC_HOOK_CODE,hook);u.hook_add(UC_HOOK_INSN,inp,None,1,0,UC_X86_INS_IN);u.hook_add(UC_HOOK_INSN,out,None,1,0,UC_X86_INS_OUT);u.hook_add(UC_HOOK_MEM_WRITE,wh)
def call(name,ax=0,bx=0,cx=0,dx=0,far=False):
    global checks
    regs={UC_X86_REG_AX:ax,UC_X86_REG_BX:bx,UC_X86_REG_CX:cx,UC_X86_REG_DX:dx,UC_X86_REG_SI:0x1111,UC_X86_REG_DI:0x2222,UC_X86_REG_BP:0x3333,UC_X86_REG_DS:ds,UC_X86_REG_ES:0x7777}
    for r,v in regs.items():u.reg_write(r,v&65535)
    u.reg_write(UC_X86_REG_SS,0x8000);u.reg_write(UC_X86_REG_SP,0xff00);u.reg_write(UC_X86_REG_EFLAGS,0x202)
    ret=struct.pack('<HH',0,0x9000) if far else struct.pack('<H',0xf000)
    u.reg_write(UC_X86_REG_SP,0xff00-len(ret));u.mem_write(0x80000+0xff00-len(ret),ret)
    idx,off=symbols[name];u.reg_write(UC_X86_REG_CS,segments[idx]['seg']);u.reg_write(UC_X86_REG_IP,off)
    u.emu_start(sym(name),0,count=20000000)
    assert u.reg_read(UC_X86_REG_SP)==0xff00,(name,'SP',hex(u.reg_read(UC_X86_REG_SP)))
    for r,v in regs.items():
        if r in (UC_X86_REG_AX,UC_X86_REG_CX,UC_X86_REG_DX) and name in ('hp_config',):continue
        if r==UC_X86_REG_AX and far:continue
        assert u.reg_read(r)==(v&65535),(name,'register',r,u.reg_read(r),v)
    assert cursor_depth==0,(name,'cursor lease',cursor_depth)
    checks+=1
rng=np.random.default_rng(1223);source=rng.integers(0,256,81920,dtype=np.uint8).tobytes()
u.mem_write(sym('shadow_bits'),source[:64000]);u.mem_write(sym('shadow_tail'),source[64000:]);u.mem_write(0x465,b'\x0a')
u.mem_write(sym('enabled_flag'),b'\x01');call('hp_reset',far=True)
def expected():
    raw=bytes(u.mem_read(sym('shadow_bits'),64000))+bytes(u.mem_read(sym('shadow_tail'),17920))
    a=np.frombuffer(raw,dtype=np.uint8).reshape(256,4,80);b=np.unpackbits(a,axis=2);s=b[:,0]*4+b[:,1]*2+b[:,2]+b[:,3]*8
    return s[word('hp_top'):word('hp_top')+200,word('hp_left'):word('hp_left')+320]
def verify():
    global checks
    a=np.frombuffer(u.mem_read(video,32768),dtype=np.uint8);y=np.arange(200)[:,None];x=np.arange(160)[None,:]
    b=a[(y%4)*8192+((2*word('hp_start')+160*(y//4)+x)&8191)];v=np.empty((200,320),dtype=np.uint8);v[:,::2]=b>>4;v[:,1::2]=b&15
    assert np.array_equal(v,expected()),(word('hp_left'),word('hp_top'),word('hp_start'),int(np.count_nonzero(v!=expected())))
    checks+=1
call('FlushShadow');verify();call('hp_config',1,far=True);verify()
path=[(0,y) for y in range(4,57,4)]+[(0,y) for y in range(52,-1,-4)]
for y in range(0,57,4):path.extend((x,y) for x in (range(8,321,8) if y%8==0 else range(312,-1,-8)))
path += [(320,56),(0,0)]
for dx,dy in [(8,4),(-8,-4),(8,-4),(-8,4)]:
    x,y=(0 if dx>0 else 320),(0 if dy>0 else 56);path.append((x,y))
    for k in range(14):x+=dx;y+=dy;path.append((x,y))
steps=[]
for x,y in path:
    oldx,oldy=word('hp_left'),word('hp_top');dx,dy=x-oldx,y-oldy
    writes.clear();stage_writes.clear();guard=bytes(u.mem_read(sym('shadow_bits')+64000,16))+bytes(u.mem_read(sym('shadow_tail')+17920,16));capture=True;call('hp_set',x,dx=y,far=True);capture=False;verify()
    assert bytes(u.mem_read(sym('shadow_bits')+64000,16))+bytes(u.mem_read(sym('shadow_tail')+17920,16))==guard,'band guards'
    n=sum(n for a,n,b in writes)
    if (dx or dy) and abs(dx)<=8 and abs(dy)<=4:
        want=(800 if dx else 0)+(640 if dy else 0)
        assert n==want,(x,y,'count',n,want)
        assert sum(n for a,n,b in stage_writes)==want,(x,y,'stage count')
        assert all(not b for a,n,b in stage_writes),'stage while blank'
        assert all(b for a,n,b in writes),'commit unblanked'
    assert not blank
    steps.append(dict(x=x,y=y,dx=dx,dy=dy,written=n))
for x,y in [(0,0),(320,56),(160,28)]:
    call('hp_set',x,dx=y,far=True)
    for a,b,c,d in [(-5,270,-8,99),(198,204,0,80),(254,260,78,99),(0,256,0,0),(257,270,0,80)]:call('FlushColumns',a,b,c,d);verify()
call('hp_config',2,far=True);call('hp_set',168,dx=32,far=True);verify();assert word('hp_start')==0 and word('hp_bytes')==0
call('hp_set',999,dx=999,far=True);verify();assert (word('hp_left'),word('hp_top'))==(320,56)
call('hp_set',0xffff,dx=0xffff,far=True);verify();assert (word('hp_left'),word('hp_top'))==(0,0)
assert bytes(u.mem_read(sym('shadow_bits'),64000))+bytes(u.mem_read(sym('shadow_tail'),17920))==source
result=dict(status='PASS',checks=checks,steps=len(steps),write_counts={str(n):sum(s['written']==n for s in steps) for n in sorted(set(s['written'] for s in steps))},scope='Exact linked XY pan/flush code, NE relocation, random split shadow, viewport pixels, staging before blank/VRAM under blank, bank wrap, x/y/diagonal in both directions, clipped flush, large-jump fallback, fault fallback, clamps, registers/stack; cursor entry points and ports mocked',physical_tested=False,Windows_tested=False)
(B/'XY-CPU.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
