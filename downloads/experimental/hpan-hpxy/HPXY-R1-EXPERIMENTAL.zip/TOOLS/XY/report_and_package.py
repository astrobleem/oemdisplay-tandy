"""Create a private packet only after final_audit passes. No emulator or CF use."""
from pathlib import Path
import sys,json,hashlib,shutil,subprocess,zipfile
W=Path(__file__).resolve().parents[1];P=W/'xy-source/experiments/XYPAN'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def dos(p,s):p.write_bytes(s.replace('\r\n','\n').replace('\n','\r\n').encode('ascii'))
phase=sys.argv[1]
audit=json.loads((W/'XY/FINAL-AUDIT.json').read_text());assert audit['status']=='PASS'
pins=[dict(file=n,bytes=p.stat().st_size,sha256=sha(p)) for n,p in [('HPXY.DRV',W/'XYB2/HPXY.DRV'),('XYCTL.EXE',W/'XYAPPS7/XYCTL.EXE')]]
if phase=='report':
 base=W/'XYB2/BASEPIPE.json'
 if not base.exists():shutil.copyfile(W/'XYB2/RESULT.json',base)
 original=json.loads(base.read_text());assert original['build']=='PASS' and original['link_audit']['result']=='PASS' and original['instruction_audit']['unsupported']==[]
 report=dict(build='PASS',runtime='PASS_NATIVE_EMULATOR',candidate='PRIVATE combined HPXY R1',target='Windows3.0 real mode original Tandy EX/HX 8088 640KiB',logical=[640,256,16],viewport=[320,200,16],shadow_bands=[64000,17920],stage_bytes=1440,gross_NE_bytes=121412,delta_from_R3_gross_bytes=18457,ceiling_delta=24576,hardware_default=False,edge_default=False,follow_default=False,physical_tested=False,CF_access=False,sha256=sha(W/'XYB2/HPXY.DRV'),native_full='XYUN3/RESULT.json (APPS6 helper)',native_final_helper='XYFOCN3/RESULT.json (APPS7 helper)',source_reproduction='XY/SOURCE-REPRO.json',baseline_pipeline_report='BASEPIPE.json retains the original intermediate pipeline labels; mode/optimization descriptions there are not final XY behavior',instruction_audit=original['instruction_audit'],link_audit=original['link_audit'],rep_prefix_audit=original['rep_prefix_audit'])
 save(W/'XYB2/RESULT.json',report)
 save(P/'PINS.JSN',dict(candidate='PRIVATE HPXY R1',base_commit='00f232840f18b471c20aedaa1a2d07fb1813017d',runtime=pins,full_suite_helper_sha256=sha(W/'XYAPPS6/XYCTL.EXE'),final_helper_source_sha256=sha(P/'XYCTL.C'),physical_XY_tested=False))
 dos(P/'PINS.JSN',(P/'PINS.JSN').read_text())
 dos(P/'.gitattributes','* -text\n')
 dos(P/'.gitignore','__pycache__/\n*.pyc\n')
 text='''HPXY R1 PRIVATE QUALIFICATION - 2026-10-17 UTC
Logical 640x256x16; physical 320x200x16. Hardware origin X0..320/8,Y0..56/4.
Physical XY testing is pending. No CF access, installer change, public release
or merge. The accepted horizontal-only HPAN R3 payloads remain unchanged.

MEMORY
Two fixed owned bands: 64,000 + 17,920 = 81,920 bytes. Stage 1,440 bytes.
Compiled gross NE segments: 121,412; accepted R3: 102,955; increase: 18,457.
Chosen increase ceiling: 24,576. This sum is not a resident-memory estimate.
Native full QA: 250,560 free bytes before/after EACH Windows invocation;
largest start 234,560, ends 246,144 then 234,560. Other applications have their
own memory demands. No EMS/XMS/UMB or newer CPU escape. A single 16-bit
flat bitmap would overflow; all second-band paths were adapted explicitly.
640x400 needs 128,000 shadow bytes, outside this bounded budget. It is not
claimed physically impossible or qualified by this two-band experiment.

PASSED EVIDENCE
XYUN3: complete combined native Windows suite: 12 exact frames, 2 clean DOS
returns, all checks pass. Tandy HX/8088 4.772728 MHz, 640 KiB, native 86Box.
XYFOCN3: final helper binary focused suite: 5 exact frames, 2 clean returns.
Every captured frame checks full displayed pixels, VRAM against canonical
shadow, actual CRTC start, and reservation MCB. DOS checks mode 3, page 0,
BDA offset 0, CRTC start 0. Stopped disk FAT copies match. Relaunch defaults
to software/origin 0,0. This is emulator evidence, not physical acceptance.
The native RESULT head field is CRTC MA; headBytes in ordinal106 is twice
that value. At168,28 this is MA 602 / byte offset 1204.
Full suite covers 80 combined edge firings from 0,0 to 320,56 and back,
28 vertical menu steps, stable 500ms edge dwell, pointer local position,
queued CtrlAltUp/Q, visible popup, active corner dialog fit, keyboard window
move, clipped lower/right drawing, retrace fault recovery, and relaunch.
Native GDI crosses row 199/200: Pixel, overlap BitBlt in both directions,
text vs reference, 4bpp DIB, clipping, invalid coordinates and row chunks.
Earlier XYN3 engine capture has 11 exact frames and 2 clean returns including
visible cursor at clipped corners, diagonal motion and save-under erasure.
Its original overall verdict remains FAIL: a bad CLIP_OUTSIDE assertion
expected a formerly white pixel to change. Corrected black sentinels pass
in XYUN3. Do not present the whole historical XYN3 suite as PASS.
XYUN1/2 historical raw-key failures exposed timer polling misses; focused
KEYPRB showed correct raw scan input and queued USER messages. The final
helper handles focused queued keys, suppresses repeat, and latches across
focus changes. Background timer polling remains best effort.
The full suite used APPS6. APPS7 adds one held-key latch store and fixes
three static TextOut lengths. Exact delta is asserted by FINAL-AUDIT;
XYFOCN3 passed with the byte-identical APPS7 helper and APPS8 fixture.
The helper also passed host key/cleanup tests. Initial XYFOCN1 failed because
two unescaped C marker paths prevented the controller from sending keys; its original FAIL is retained.
XYFOCN2 was interrupted by exec-server transport loss after frame 0; both
owned processes stopped. Its INCOMPLETE record is retained separately.

Host independent bank model: 2,344 checks / 1,570 moves / 1,358 wrapped views.
Exact linked presenter: 1,425 checks / 690 moves; pixel packing, bank wraps,
diagonals, register/stack preservation, stage-before-blank/commit-under-
blank, clipping, fault and full fallback. Ports/cursor mocked there.
Actual linked generic BitBlt crosses the band both ways at actual segment
deltas 1000h and F000h, preserving 1,792 guard bytes. Host Pixel fixture was
stopped after three failures; Pixel/text acceptance comes from Windows.
Host cleanup (8 cases) and queued-key/repeat/focus transition regressions pass.
CRLF overlay reproduces changed linked assembler inputs byte-for-byte.

COST (ONE EMULATOR BATCH)
Eight Escape-only steps per axis/mode; no QA logging inside timed loop.
Software: 13,896ms per 8 for each axis. Hardware horizontal 824ms (800B/step),
vertical 439ms (640B/step),diagonal 1,044ms (1,440B/step). Clock~54.925ms.
Large jumps/recovery copy 32,000B. No physical blank-duration measurement;
86Box bit3 behavior does not qualify a real CRT's black interval.

SAFE USE / REPRODUCTION
Read README.TXT and PINS.JSN. Only use a private cloned qualified Windows
directory with existing compact resources, RESERVE 16K and WIN /R. This
packet is not an installer. Start XYCTL in software; opt into hardware,
then enable edges/follow if desired. Focus helper for reliable key chords.
Exit helper or select Home/Software before leaving Windows. Check DOS text
and relaunch. Preserve the accepted clone and all CF files.
Apply SOURCE/PATCH.DIFF to base 00f232840f18b471c20aedaa1a2d07fb1813017d
or use the delivered source directory. XYBUILD.PY requires the existing
pinned external DDK/compiler/resource build view and shared emulator gate.
Evidence controllers retain original local paths to owned media/tools;
they are provenance/reproduction fixtures, not portable installers.
No DDK, Windows installation, ROM, emulator or compiler is redistributed.
'''
 dos(P/'QUAL.TXT',text)
 save(W/'XY-CHECKPOINT.json',dict(status='COMPLETE_PRIVATE_NATIVE_QUALIFIED',logical=[640,256,16],viewport=[320,200,16],source_branch='experiment/xy-pan-20261017',driver='XYB2/HPXY.DRV',helper='XYAPPS7/XYCTL.EXE',driver_gross_delta_bytes=18457,native_full='XYUN3/RESULT.json',native_final_helper='XYFOCN3/RESULT.json',physical_XY_tested=False,CF_access=False,remaining='Physical XY qualification; background key polling remains best effort. No pending implementation blocker.'))
 print('Reports prepared; review and commit only experiments/XYPAN before package phase')
elif phase=='package':
 repo=W/'xy-source';base='00f232840f18b471c20aedaa1a2d07fb1813017d'
 assert subprocess.check_output(['git','-C',str(repo),'status','--porcelain'],text=True).strip()=='','Commit the reviewed source before packaging'
 head=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip();assert head!=base,'Source patch must be committed'
 changed=subprocess.check_output(['git','-C',str(repo),'diff','--name-only',base,'HEAD'],text=True).splitlines()
 assert changed and all(n.startswith('experiments/XYPAN/') for n in changed),'Unrelated source changes'
 for p in P.iterdir():
  if p.is_file():assert subprocess.check_output(['git','-C',str(repo),'show','HEAD:experiments/XYPAN/'+p.name])==p.read_bytes(),p
 O=W/'PRIVATE-HPXY-R1';assert not O.exists();O.mkdir()
 def cp(p,rel):
  q=O/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
 for pin in pins:cp(W/('XYB2/' if pin['file']=='HPXY.DRV' else 'XYAPPS7/')/pin['file'],'RUNTIME/'+pin['file'])
 for p in P.iterdir():
  if p.is_file():cp(p,'SOURCE/experiments/XYPAN/'+p.name)
 for n in ['README.TXT','QUAL.TXT','PINS.JSN']:cp(P/n,n)
 patch=subprocess.check_output(['git','-C',str(W/'xy-source'),'diff','--binary','00f232840f18b471c20aedaa1a2d07fb1813017d','HEAD','--','experiments/XYPAN'])
 assert patch
 subprocess.run(['git','-C',str(repo),'apply','--reverse','--check','--whitespace=nowarn','-'],input=patch,check=True)
 (O/'SOURCE/PATCH.DIFF').write_bytes(patch)
 commit=subprocess.check_output(['git','-C',str(W/'xy-source'),'rev-parse','HEAD'],text=True).strip()
 save(O/'SOURCE/COMMIT.json',dict(branch='experiment/xy-pan-20261017',commit=commit,base='00f232840f18b471c20aedaa1a2d07fb1813017d',scope='Only experiments/XYPAN; no merge/push/publication'))
 if (W/'xy-source/LICENSE').exists():cp(W/'xy-source/LICENSE','SOURCE/LICENSE')
 for rel in ['XYB2/RESULT.json','XYB2/BASEPIPE.json','XYB2/XY.json','XYB2/XY-CPU.json','XY/BANK-MODEL.json','XY/MEMORY.json','XY/HUGE-BLT-POS.json','XY/HUGE-BLT-NEG.json','XY/KEYS.json','XY/CLEANUP.json','XY/SOURCE-REPRO.json','XY/STRING-COUNTS.json','XY/BENCH.json','XY/API.json','XY/FINAL-AUDIT.json']:
  cp(W/rel,'EVIDENCE/'+rel)
 for name in ['XYUN3','XYFOCN3','XYN3']:
  for p in (W/name).iterdir():
   if p.is_file() and (p.suffix.upper() in ['.PNG','.BIN'] or p.name in ['RESULT.json','XY.LOG','XYCTL.LOG','LEASE.json','MEDIA.json','86box.cfg','RESERVE.TXT','HPRET1.TXT','HPRET2.TXT','HPDONE.TXT']):cp(p,'EVIDENCE/'+name+'/'+p.name)
 for name in ['XYAPPS2','XYAPPS6','XYAPPS7','XYAPPS8']:
  for p in (W/name).iterdir():
   if p.is_file() and (p.suffix.upper() in ['.C','.BLD','.DEF','.EXE'] or p.name in ['BUILD.json','HELPER.json','LEASE.json']):cp(p,'EVIDENCE/'+name+'/'+p.name)
 for n in ['RESULT.json','KEY.LOG','INPUT.json','LEASE.json']:cp(W/'XYNKEY'/n,'EVIDENCE/XYNKEY/'+n)
 for n in ['RESULT.json','XY.LOG','XYCTL.LOG','LEASE.json','MEDIA.json']:cp(W/'XYFOCN1'/n,'EVIDENCE/XYFOCN1/'+n)
 for n in ['INTERRUPTED.json','RECOVERYLEASE.json','LEASE.json','PROGRESS.json','MEDIA.json']:cp(W/'XYFOCN2'/n,'EVIDENCE/XYFOCN2/'+n)
 for n in ['bank_model.py','xy_cpu.py','huge_blt.py','keys_test.py','cleanup_test.py','source_repro.py','final_audit.py','report_and_package.py']:
  cp(W/'XY'/n,'TOOLS/XY/'+n)
 for n in ['prepare_xy_native.py','prepare_xy_ui_native.py','prepare_xy_focus.py','run_xy_native.py','run_xy_ui.py','run_xy_focus.py','build_xy_apps.py','build_xy.py','xy_lease.py','lease.py','hw_model.py']:
  cp(W/n,'TOOLS/'+n)
 dos(O/'TOOLS/README.TXT','Original local qualification tools, with original owned-media/tool paths.\nNo owned media or external library is included. Use an isolated clone.\nNative controllers acquire the nonblocking shared gate and stop only their\nowned process. SOURCE/experiments/XYPAN/XYBUILD.PY is the parameterized\ndriver builder; use it with the pinned external build view.\n')
 manifest=[]
 for p in sorted(O.rglob('*')):
  if p.is_file():manifest.append(dict(path=p.relative_to(O).as_posix(),bytes=p.stat().st_size,sha256=sha(p)))
 save(O/'MANIFEST.json',dict(runtime=pins,source_commit=commit,files=manifest,physical_XY_tested=False,CF_access=False))
 z=W/'Windows3-XY-CRTC-Private-20261017-R1.zip';assert not z.exists()
 with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as f:
  for p in sorted(O.rglob('*')):
   if p.is_file():f.write(p,p.relative_to(O).as_posix())
 with zipfile.ZipFile(z) as f:
  assert f.testzip() is None
  assert len(f.namelist())==len(manifest)+1
  for row in manifest:assert hashlib.sha256(f.read(row['path'])).hexdigest()==row['sha256']
  assert not any(n.lower().endswith(('.img','.obj','.rom','.lst','.dll')) or '__pycache__' in n for n in f.namelist())
 delivery=dict(status='PASS_PRIVATE_CANDIDATE',zip=str(z),bytes=z.stat().st_size,sha256=sha(z),files=len(manifest)+1,source_commit=commit,runtime=pins,full_suite_frames=12,final_helper_frames=5,native_DOS_returns=4,physical_XY_tested=False,CF_access=False,public_release=False)
 save(W/'XY-DELIVERY.json',delivery);print(json.dumps(delivery,indent=2))
else:raise ValueError(phase)
