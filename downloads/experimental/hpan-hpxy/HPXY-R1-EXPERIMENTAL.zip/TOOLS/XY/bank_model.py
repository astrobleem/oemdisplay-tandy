"""Independent two-band backing and two-axis packed-aperture model.
Does not execute the driver, Windows, mouse ISR or physical CRTC.
"""
from pathlib import Path
import numpy as np,json
W=Path(__file__).resolve().parent
rng=np.random.default_rng(21617)
pixels=rng.integers(0,16,(256,640),dtype=np.uint8)
planes=np.stack([((pixels>>b)&1) for b in [2,1,0,3]],axis=1)
back=np.packbits(planes,axis=2).tobytes()
bands=[bytearray(back[:64000]),bytearray(back[64000:])]
checks=0;wraps=0;counts={};steps=0
def row(y):
 band=0 if y<200 else 1;offset=(y if band==0 else y-200)*320
 assert 0<=offset and offset+319<len(bands[band]) and offset+319<=65535
 a=np.frombuffer(bands[band],np.uint8,count=320,offset=offset).reshape(4,80)
 p=np.unpackbits(a,axis=1)
 return p[0]*4+p[1]*2+p[2]+p[3]*8
for y in range(256):assert np.array_equal(row(y),pixels[y]);checks+=1
# Descriptor segment deltas need not equal0x1000 when only two bands exist.
for first,second in [(0x2000,0x6000),(0x7000,0x3000)]:
 delta=(second-first)&65535
 for y in range(256):
  segment=(first+(y//200)*delta)&65535;off=(y%200)*320
  assert segment==(first if y<200 else second) and off+319<65536;checks+=1
def pack(y,x,n):
 p=row(y)[x:x+n];return ((p[::2]<<4)|p[1::2])
def destination(head,vy,bx):
 return (vy&3)*8192+((head+(vy//4)*160+bx)&8191)
def fetch(video,head):
 y=np.arange(200)[:,None];x=np.arange(160)[None,:]
 b=video[(y&3)*8192+((head+(y//4)*160+x)&8191)]
 p=np.empty((200,320),np.uint8);p[:,::2]=b>>4;p[:,1::2]=b&15;return p
def full(video,x,y,head):
 for vy in range(200):
  b=pack(y+vy,x,320)
  for i,value in enumerate(b):video[destination(head,vy,i)]=value
def verify(video,x,y,head):
 global checks,wraps
 assert 0<=head<8192 and head%4==0
 assert np.array_equal(fetch(video,head),pixels[y:y+200,x:x+320]),(x,y,head)
 if head+7999>=8192:wraps+=1
 checks+=1
for anchor in [0,4092,8100]:
 x=y=0;head=anchor;video=np.full(32768,0xA5,np.uint8);full(video,x,y,head);verify(video,x,y,head)
 directions=([(8,0)]*40+[(-8,0)]*40+[(0,4)]*14+[(0,-4)]*14+
             [(8,4)]*40+[(-8,-4)]*40+[(8,-4)]*40+[(-8,4)]*40+
             [tuple(v) for v in rng.choice([-1,0,1],(300,2))*[8,4]])
 for dx,dy in directions:
  nx=max(0,min(320,x+dx));ny=max(0,min(56,y+dy));dx=nx-x;dy=ny-y
  if dx==dy==0:continue
  newhead=(head+dx//2+(dy//4)*160)&8191
  staged=[]
  if dx:
   start=320-abs(dx) if dx>0 else 0
   for vy in range(200):
    for i,value in enumerate(pack(ny+vy,nx+start,abs(dx))):
     staged.append((destination(newhead,vy,start//2+i),int(value)))
  if dy:
   start=200-abs(dy) if dy>0 else 0
   for vy in range(start,start+abs(dy)):
    for i,value in enumerate(pack(ny+vy,nx,320)):
     staged.append((destination(newhead,vy,i),int(value)))
  # A real buffer is bounded by1440, including16 duplicated corner bytes.
  expected=1440 if dx and dy else 800 if dx else 640
  assert len(staged)==expected and len(staged)<=1440
  oldvideo=video.copy();unique={}
  for p,value in staged:
   assert 0<=p<32768
   if p in unique:assert unique[p]==value
   unique[p]=value
  assert np.array_equal(oldvideo,video),'staging changed old VRAM'
  assert len(unique)==(1424 if dx and dy else expected)
  for p,value in staged:video[p]=value
  x,y,head=nx,ny,newhead;verify(video,x,y,head)
  counts[str(expected)]=counts.get(str(expected),0)+1;steps+=1
 # Software fallback rebases to zero with a complete viewport copy.
 full(video,x,y,0);verify(video,x,y,0)
result=dict(status='PASS',checks=checks,steps=steps,bank_wrapped_view_checks=wraps,
            writes_per_step=counts,staging_max_bytes=1440,diagonal_unique_bytes=1424,
            backing_band_bytes=list(map(len,bands)),physical_tested=False,windows_tested=False,
            scope='Independent two-band address and packed-aperture preservation proof; not generic DDK huge-renderer or hardware acceptance')
(W/'BANK-MODEL.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
