"""Offline checks only: candidate pins, FAT copies, source format, preserved R3."""
from pathlib import Path
import hashlib,json,struct,re,subprocess
W=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
P=W/'xy-source/experiments/XYPAN'
source=[]
for p in sorted(P.iterdir()):
 if not p.is_file():continue
 b=p.read_bytes();assert b'\n' not in b.replace(b'\r\n',b''),p
 source.append(dict(name=p.name,bytes=len(b),sha256=sha(p)))
assert sha(P/'XYCTL.C')==sha(W/'XYAPPS7/XYCTL.C')
assert sha(P/'XYFOC.C')==sha(W/'XYAPPS8/XYFOC.C')
assert sha(W/'XYAPPS8/XYCTL.EXE')==sha(W/'XYAPPS7/XYCTL.EXE')
markers=re.findall(r'Marker\("([^"]+)"\)',(P/'XYFOC.C').read_text())
assert set(markers)=={r'C:\\XYKEY.TXT',r'C:\\XYQUIT.TXT'},markers
assert sha(P/'XYUI.C')==sha(W/'XYAPPS6/XYUI.C')
old=(W/'XYAPPS6/XYCTL.C').read_text();new=(P/'XYCTL.C').read_text()
expected=old.replace('   if(i==8)KeyAction(i);','   latch[i]=1; /* A held key must not fire again if focus changes. */\n   if(i==8)KeyAction(i);')
for text,count in [('PRIVATE 640x256 / 320x200',25),('Home reset; H hardware; Q exit',30),('E edges 500ms; F dialog follow',30)]:
 expected=re.sub(r'("'+re.escape(text)+r'",)\d+',lambda m:m[1]+str(count),expected)
assert expected==new,'Final helper differs beyond the reviewed latch and text lengths'
fat=[]
for name in ['XYN3','XYUN3','XYFOCN3']:
 m=json.loads((W/name/'MEDIA.json').read_text());p=Path(m['disk'])
 assert p.parent==W/name
 with p.open('rb') as f:
  f.seek(m['offset']);boot=f.read(512)
  bps=struct.unpack_from('<H',boot,11)[0];reserved=struct.unpack_from('<H',boot,14)[0];copies=boot[16];spf=struct.unpack_from('<H',boot,22)[0]
  assert bps==512 and copies==2 and spf>0
  f.seek(m['offset']+reserved*bps);a=f.read(spf*bps);b=f.read(spf*bps)
 assert a==b,(name,'FAT copies differ after owned process stopped')
 lease=json.loads((W/name/'LEASE.json').read_text());assert lease['released']
 fat.append(dict(run=name,FAT_copies_equal=True,FAT_bytes=len(a),sha256=hashlib.sha256(a).hexdigest(),lease_released=True))
pins=[('BUILD5/HPAN.DRV','70ccb3957aa68d310e3bfc0407ebbf96634bbcd9347a929486463223471f215b'),('EDGE-TRACE/HCTL.EXE','0f5c335f8c3641775aa85793f2bffb95e107054c3271cf087e19cdfce4df405c'),('Windows3-Horizontal-CRTC-Edge-Private-20261017-R3.zip','b5e53482bc00f3cff42ad7b0bbe4e099fe27a8a726ab6d628cbcf7da48572c28')]
for rel,want in pins:assert sha(W/rel)==want,rel
assert subprocess.check_output(['git','-C',str(W/'sweep-source'),'status','--porcelain'],text=True).strip()==''
raw=(W/'XYB2/HPXY.DRV').read_bytes();ne=struct.unpack_from('<I',raw,0x3c)[0]
pos=ne+struct.unpack_from('<H',raw,ne+4)[0];ordinal=1;exports=[]
while True:
 count=raw[pos];pos+=1
 if not count:break
 bundle=raw[pos];pos+=1
 if bundle:
  exports.extend(range(ordinal,ordinal+count));pos+=count*(6 if bundle==255 else 3)
 ordinal+=count
assert 106 in exports and 108 in exports and 107 not in exports,exports
save(W/'XY/API.json',dict(status='PASS',exported_ordinals=exports,statistics_ordinal=106,stream_rows_ordinal=108,old_flat_snapshot107_absent=True))
full=json.loads((W/'XYUN3/RESULT.json').read_text());focus=json.loads((W/'XYFOCN3/RESULT.json').read_text())
assert full['status']==focus['status']=='PASS'
assert len(full['frames'])==12 and len(focus['frames'])==5
for r in [full,focus]:
 assert r['driver_sha256']==sha(W/'XYB2/HPXY.DRV')
 assert len(r['dos_states'])==2
 assert all(f['pixels_wrong']==f['display_wrong']==0 and f['mcb_intact'] for f in r['frames'])
 assert all(s['mode']==3 and s['page']==s['bda_offset']==s['start']==0 for s in r['dos_states'])
for rel in ['XY/BANK-MODEL.json','XYB2/XY-CPU.json','XY/HUGE-BLT-POS.json','XY/HUGE-BLT-NEG.json','XY/CLEANUP.json','XY/KEYS.json','XY/SOURCE-REPRO.json']:
 assert json.loads((W/rel).read_text())['status']=='PASS',rel
for rel in ['XY/CLEANUP.json','XY/KEYS.json']:
 assert json.loads((W/rel).read_text())['source_sha256']==sha(P/'XYCTL.C')
logs=(W/'XYUN3/XY.LOG').read_text();free=[]
for name in ['XYUN3','XYFOCN3']:
 text=(W/name/'XY.LOG').read_text()
 for run in [1,2]:
  start=re.search(r'START run='+str(run)+r' free=(\d+) largest=(\d+)',text)
  end=re.search(r'END run='+str(run)+r' FAILURES=(\d+) free=(\d+) largest=(\d+)',text)
  assert end[1]=='0' and start[1]==end[2]
  free.append(dict(suite=name,run=run,free_start=int(start[1]),free_end=int(end[2]),largest_start=int(start[2]),largest_end=int(end[3])))
bench=[]
for kind,mode,steps,ms,last,enabled in re.findall(r'BENCH kind=(\d+) mode=(\d+) steps=(\d+) ms=(\d+) lastBytes=(\d+) enabled=(\d+)',logs):
 bench.append(dict(axis=['horizontal','vertical','diagonal'][int(kind)],hardware=bool(int(mode)),steps=int(steps),elapsed_ms=int(ms),ms_per_step=int(ms)/int(steps),last_bytes=int(last)))
save(W/'XY/BENCH.json',dict(status='PASS',scope='One native 4.772728MHz HX/8088 emulator batch; eight Escape-only steps, hidden cursor, no QA logging inside timed loop',clock_resolution_ms=54.9254,physical_blank_duration_measured=False,measurements=bench))
save(W/'XY/FINAL-AUDIT.json',dict(status='PASS',sources=source,final_helper_source_sha256=sha(P/'XYCTL.C'),helper_delta_from_full_suite='One held-key focus-transition latch store and three constant TextOut lengths; exact delta asserted',native_full_helper_sha256=sha(W/'XYAPPS6/XYCTL.EXE'),native_final_helper_sha256=sha(W/'XYAPPS7/XYCTL.EXE'),native_frames=17,native_DOS_returns=4,free_memory=free,offline_FAT=fat,R3_payloads_unchanged=True,R3_source_clean=True,physical_XY_tested=False,CF_access=False))
print('PASS final pins, exact helper delta, 17 frames, 4 DOS returns, FAT copies and preserved R3')
