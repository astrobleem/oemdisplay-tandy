from pathlib import Path
import subprocess,os,json,hashlib
W=Path(__file__).resolve().parents[1];P=W/'xy-source/experiments/XYPAN/XYCTL.C'
s=P.read_text();a=s.index('static void Cleanup(void)');b=s.index('static void Stop(',a);body=s[a:b]
stub=r'''
#include <stdio.h>
#include <assert.h>
#define LPSTR char*
#define ESC_MODE 0x5861
#define ESC_XY 0x5860
static int display=33,left=320,top=56,hardware=1,live=0;
static int calls,queries,records,modeOK,panOK,queryOK;
static int Escape(int dc,int code,int size,LPSTR in,LPSTR out){
 assert(dc==33);assert(*(int*)in==0);
 if(calls==0){assert(code==ESC_MODE && size==2 && out==0);calls++;return modeOK;}
 assert(calls==1 && code==ESC_XY && size==4 && ((int*)in)[1]==0 && out!=0);calls++;return panOK;
}
static int Query(void){queries++;if(queryOK){left=top=hardware=0;}return queryOK;}
static void Log(char*event,int a,int b,int c,int d){records++;}
'''
main=r'''
int main(void){int i;for(i=0;i<8;i++){calls=queries=records=0;live=0;modeOK=i&1;panOK=(i>>1)&1;queryOK=(i>>2)&1;Cleanup();assert(calls==2 && queries==1 && records==2);assert(live==0);}puts("PASS 8 stopped-controller cleanup cases");return 0;}
'''
# On the DOS target sizeof(int)=2; the mocked ABI checks literal byte lengths.
source=W/'XY/CLEANUP.C';exe=W/'XY/CLEANUP.EXE';source.write_text(stub+body+main)
env=dict(os.environ,PATH=r'C:\msys64\ucrt64\bin;'+os.environ['PATH'])
subprocess.run([r'C:\msys64\ucrt64\bin\gcc.exe','-x','c','-std=c99','-O0',str(source),'-o',str(exe)],env=env,check=True)
r=subprocess.run([str(exe)],env=env,text=True,capture_output=True,check=True)
report=dict(status='PASS',cases=8,source_sha256=hashlib.sha256(P.read_bytes()).hexdigest(),scope='Exact helper Cleanup function compiled with mocked Escape/Query/Log; live=0 with all combinations of failed/successful mode, pan and query. Verifies unconditional mode-off/home attempts and no reactivation. Windows int ABI verified separately by native build.',output=r.stdout.strip())
(W/'XY/CLEANUP.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
