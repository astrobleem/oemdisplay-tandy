"""Re-run deterministic source transforms, stop before any compiler launch."""
from pathlib import Path
import sys,importlib.machinery,json,hashlib
W=Path(__file__).resolve().parents[1];sys.path.insert(0,str(W/'build-view/src/tandysw'))
b=importlib.machinery.SourceFileLoader('xyrepro',str(W/'build-view/src/tandysw/BUILD88.PY')).load_module()
patch=importlib.machinery.SourceFileLoader('xypatch',str(W/'xy-source/experiments/XYPAN/XYPATCH.PY')).load_module()
prepare=b.baseline.prepare;state={}
class StopBeforeCompiler(Exception):pass
def prep(repo,out):
 r,s=prepare(repo,out);state['renderer']=r;return r,s
def stop(*args,**kw):
 r=state['renderer'];patch.patch(r);records=[]
 for rel in ['EGA/TSOFT.ASM','EGA/TCURSOR.ASM','EGA/TSOFT.DEF','SDIB88.ASM']:
  a=(r/rel).read_bytes();p=W/'XYB2/renderer'/rel;c=p.read_bytes();assert a==c,rel
  records.append(dict(path=rel,sha256=hashlib.sha256(a).hexdigest()))
 (W/'XY/SOURCE-REPRO.json').write_text(json.dumps(dict(status='PASS',matched=records,scope='Current CRLF overlay transforms reproduce all changed XYB2 linked inputs byte-for-byte; stopped before compiler/emulator'),indent=2))
 raise StopBeforeCompiler()
b.baseline.prepare=prep;b.bounded_run=stop
sys.argv=['BUILD88.PY','--repo',str(W/'build-view'),'--dosbox',r'E:\budmaker\Claude-Build-Kit\tools\DOSBOX\dosbox-x.exe','--out',str(W/'XYSRCCK1'),'--mode','320x200x16','--ui-profile','compact320']
try:b.main()
except StopBeforeCompiler:print('PASS source reproduction; no compiler/emulator launched')
