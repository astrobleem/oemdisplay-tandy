from pathlib import Path
import subprocess,os,json,hashlib
W=Path(__file__).resolve().parents[1];P=W/'xy-source/experiments/XYPAN/XYCTL.C';s=P.read_text()
def extract(a,b):return s[s.index(a):s.index(b,s.index(a))]
body=extract('static int Press(','static void KeyAction(')+extract('static int KeyMessage(','static void Edge(')
stub=r'''
#include <assert.h>
#include <stdio.h>
#define LPARAM long
#define VK_CONTROL 17
#define VK_MENU 18
#define FALSE 0
#define WM_CLOSE 16
static int keys[9]={37,39,38,40,36,'H','E','F','Q'},latch[10];
static int live=1,closing,window=77,active=77,left=160,top=32,hardware,edge,follow,directionX,directionY;
static int state[256],syncState[256],actions,lastAction=-1,panX,panY,asyncReads;
static int GetKeyState(int key){return syncState[key];}
static int GetAsyncKeyState(int key){asyncReads++;return state[key];}
static int GetActiveWindow(void){return active;}
static int Query(void){return 1;}
static void KeyAction(int i){actions++;lastAction=i;}
static void Pan(int x,int y){actions++;panX=x;panY=y;}
static void Mode(int mode){actions++;}
static void Log(char*a,int b,int c,int d,int e){}
static void InvalidateRect(int a,void*b,int c){}
static void PostMessage(int a,int b,int c,long d){actions++;}
'''
main=r'''
int main(void){int i;syncState[17]=syncState[18]=0x8000;
 for(i=0;i<9;i++){actions=0;latch[i]=0;assert(KeyMessage(keys[i],0)==1);assert(actions==1 && lastAction==i && latch[i]==1);actions=0;assert(KeyMessage(keys[i],0x40000000L)==1 && actions==0);}
 actions=asyncReads=0;Keyboard();assert(actions==0 && asyncReads==0);
 /* Queue action then lose focus while same chord/key is held. */
 latch[2]=0;actions=0;KeyMessage(keys[2],0);assert(actions==1);active=99;state[17]=state[18]=state[keys[2]]=0x8000;Keyboard();assert(actions==1);
 state[keys[2]]=0;Keyboard();assert(latch[2]==0);state[keys[2]]=0x8000;Keyboard();assert(actions==2 && panX==160 && panY==28);
 syncState[17]=0;actions=0;assert(KeyMessage('Q',0)==0 && actions==0);
 syncState[17]=0x8000;live=0;assert(KeyMessage('Q',0)==1 && lastAction==8);puts("PASS queued keys, repeats, active/background exclusivity, focus-transition latch and stopped-controller Q");return 0;}
'''
source=W/'XY/KEYS.C';exe=W/'XY/KEYS.EXE';source.write_text(stub+body+main)
env=dict(os.environ,PATH=r'C:\msys64\ucrt64\bin;'+os.environ['PATH'])
subprocess.run([r'C:\msys64\ucrt64\bin\gcc.exe','-x','c','-std=c99','-O0',str(source),'-o',str(exe)],env=env,check=True)
r=subprocess.run([str(exe)],env=env,text=True,capture_output=True,check=True)
result=dict(status='PASS',source_sha256=hashlib.sha256(P.read_bytes()).hexdigest(),scope='Exact Press/KeyMessage/Keyboard C functions, mocked USER key states and actions; 9 queued keys, repeat suppression, active/background exclusivity, held-key focus transition, release/repress and Q after live=0',output=r.stdout.strip())
(W/'XY/KEYS.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
