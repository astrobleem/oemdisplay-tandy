"""Exercise the linked Win3 TSOFT huge-bitmap raster entry points in Unicorn16.

This is a host CPU fixture: it loads the NE executable and applies its internal
segment relocations, but it does not run DOSBox, Windows, or a compiler.
"""
from __future__ import annotations

import json
import re
import struct
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "deps"))
from unicorn import Uc, UC_ARCH_X86, UC_MODE_16, UC_HOOK_CODE, UC_HOOK_MEM_READ
from unicorn.x86_const import UC_X86_REG_AX, UC_X86_REG_BX, UC_X86_REG_CS, UC_X86_REG_DS, UC_X86_REG_EFLAGS, UC_X86_REG_IP, UC_X86_REG_SP, UC_X86_REG_SS, UC_X86_REG_DX


def main() -> None:
    driver = ROOT / "XYB2/renderer/EGA/TSOFT.DRV"
    map_path = driver.with_suffix(".MAP")
    raw = driver.read_bytes()
    ne = struct.unpack_from("<I", raw, 0x3C)[0]
    assert raw[ne:ne + 2] == b"NE", "not a NE driver"

    u = Uc(UC_ARCH_X86, UC_MODE_16)
    u.mem_map(0, 0x110000)
    trace=[]
    def stop(uc, address, size, data):
        trace.append(hex(address));del trace[:-16]
        if address == 0x90000:
            uc.emu_stop()
        elif 0x98000 <= address < 0x99000:
            ordinal=(address-0x98000)//16
            assert ordinal in (171,175,176,177), ('unexpected kernel call',ordinal)
            sp=uc.reg_read(UC_X86_REG_SP);ss=uc.reg_read(UC_X86_REG_SS)<<4
            ip,cs=struct.unpack('<HH',uc.mem_read(ss+sp,4))
            if ordinal==177:
                arg=struct.unpack('<H',uc.mem_read(ss+sp+6,2))[0];size=8
            else:
                arg=struct.unpack('<H',uc.mem_read(ss+sp+4,2))[0];size=6
            uc.reg_write(UC_X86_REG_AX,arg if ordinal!=176 else 1)
            uc.reg_write(UC_X86_REG_SP,(sp+size)&65535);uc.reg_write(UC_X86_REG_CS,cs);uc.reg_write(UC_X86_REG_IP,ip)
    u.hook_add(UC_HOOK_CODE, stop)
    segments: dict[int, dict[str, int]] = {}
    addr = 0x10000
    count = struct.unpack_from("<H", raw, ne + 0x1C)[0]
    table = ne + struct.unpack_from("<H", raw, ne + 0x22)[0]
    shift = struct.unpack_from("<H", raw, ne + 0x32)[0]
    for i in range(1, count + 1):
        off, n, flags, alloc = struct.unpack_from("<4H", raw, table + 8 * (i - 1))
        file_bytes = n or (65536 if off else 0)
        size = max(file_bytes, alloc or 65536)
        segments[i] = {"seg": addr >> 4, "base": addr, "off": off << shift,
                       "n": file_bytes, "flags": flags, "size": size}
        if off and file_bytes:
            u.mem_write(addr, raw[off << shift:(off << shift) + file_bytes])
        addr += (size + 4095) & ~4095

    # Apply internal NE relocations. External kernel calls are left at their
    # zero target; the tested memory-bitmap paths should not invoke them.
    for i, seg in segments.items():
        if not seg["off"] or not (seg["flags"] & 0x100):
            continue
        pos = seg["off"] + seg["n"]
        nfix = struct.unpack_from("<H", raw, pos)[0]
        for j in range(nfix):
            typ, flags, src, t1, t2 = struct.unpack_from("<BBHHH", raw, pos + 2 + 8 * j)
            target = segments[t1 & 0xFF]["seg"] if (flags & 3) == 0 and (t1 & 0xFF) in segments else 0
            if flags&3==1:
                target=0x9800;t2*=16
            if typ == 2:
                value = struct.pack("<H", target)
            elif typ == 3:
                value = struct.pack("<HH", t2, target)
            elif typ == 5:
                value = struct.pack("<H", t2)
            else:
                raise AssertionError(f"unsupported NE relocation type {typ}")
            seen: set[int] = set()
            while src != 0xFFFF:
                assert src not in seen, "cyclic relocation chain"
                seen.add(src)
                p = seg["base"] + src
                nxt = struct.unpack("<H", u.mem_read(p, 2))[0]
                if flags & 4:
                    old = struct.unpack("<H", u.mem_read(p, 2))[0]
                    new = (old + struct.unpack("<H", value[:2])[0]) & 0xFFFF
                    u.mem_write(p, struct.pack("<H", new) + value[2:])
                    break
                u.mem_write(p, value)
                src = nxt

    symbols: dict[str, tuple[int, int]] = {}
    for m in re.finditer(r"(?m)^\s*([0-9A-Fa-f]{4}):([0-9A-Fa-f]{4})\s+(\w+)\s*$", map_path.read_text(errors="replace")):
        symbols[m.group(3)] = (int(m.group(1), 16), int(m.group(2), 16))

    def linear(name: str) -> int:
        idx, off = symbols[name]
        return segments[idx]["base"] + off

    def seg(name: str) -> int:
        return segments[symbols[name][0]]["seg"]

    def write_word(at: int, v: int) -> None:
        u.mem_write(at, struct.pack("<H", v & 0xFFFF))

    # Configure the actual linked two-band storage as a Win3 memory BITMAP.
    # GDIDEFS.INC layout: 32 bytes, with segment metadata at offsets 22/24/26.
    desc = linear("shadow_device")
    s0, s1 = seg("shadow_bits"), seg("shadow_tail")
    reverse='--reverse' in sys.argv
    if reverse:
        segments[symbols['shadow_bits'][0]]['base']=0x60000
        segments[symbols['shadow_bits'][0]]['seg']=0x6000
        segments[symbols['shadow_tail'][0]]['base']=0x50000
        segments[symbols['shadow_tail'][0]]['seg']=0x5000
        s0,s1=seg('shadow_bits'),seg('shadow_tail')
    delta = (s1 - s0)&65535
    assert delta > 0 and delta != 1, f"fixture did not get a nontrivial segment delta: {delta:#x}"
    u.mem_write(desc, bytes(32))
    write_word(desc + 0, 0)             # bmType: memory bitmap
    write_word(desc + 2, 640)           # bmWidth
    write_word(desc + 4, 256)           # bmHeight
    write_word(desc + 6, 80)            # bmWidthBytes
    u.mem_write(desc + 8, bytes((4, 1)))  # bmPlanes, bmBitsPixel
    write_word(desc + 10, 0)            # bmBits offset
    write_word(desc + 12, s0)           # bmBits selector
    u.mem_write(desc + 14, struct.pack("<I", 80 * 256))  # bmWidthPlanes
    write_word(desc + 18, 0)            # bmlpPDevice offset
    write_word(desc + 20, 0)            # bmlpPDevice selector
    write_word(desc + 22, delta)        # selector delta to band 2
    write_word(desc + 24, 200)          # rows per band
    write_word(desc + 26, 1536)         # 64K gap after 64,000 useful bytes

    # Two-byte guards cover the unused tail of each segment and several bytes
    # beyond the 17,920-byte final band. The first band includes the 1,536-byte
    # filler region required by the DDK huge-bitmap wrap arithmetic.
    guard0 = bytes([0xA5]) * (65536 - 64000)
    guard1 = bytes([0x5A]) * 256
    u.mem_write(segments[symbols["shadow_bits"][0]]["base"] + 64000, guard0)
    u.mem_write(segments[symbols["shadow_tail"][0]]["base"] + 17920, guard1)

    def band_bytes() -> bytes:
        return bytes(u.mem_read(linear("shadow_bits"), 64000)) + bytes(u.mem_read(linear("shadow_tail"), 17920))

    def seed() -> bytes:
        rows = bytearray()
        for y in range(256):
            rows.extend(((y * 29 + x * 13 + (x >> 6) * 47) & 0xFF) for x in range(320))
        first, second = rows[:64000], rows[64000:]
        u.mem_write(linear("shadow_bits"), bytes(first))
        u.mem_write(linear("shadow_tail"), bytes(second))
        return bytes(rows)

    # Pascal FAR calls use the same order as cCall with ?PLM=1: argument words
    # are pushed left-to-right; each far pointer is pushed segment then offset.
    stack_seg, sp0 = 0x8000, 0xFF00
    def call(name: str, args: list[tuple[str, object]]) -> tuple[int, int]:
        sp = sp0
        def push(v: int) -> None:
            nonlocal sp
            sp = (sp - 2) & 0xFFFF
            u.mem_write((stack_seg << 4) + sp, struct.pack("<H", v & 0xFFFF))
        for kind, value in args:
            if kind == "w":
                push(int(value))
            elif kind == "d":
                push(int(value) >> 16)
                push(int(value) & 65535)
            elif kind == "p":
                ps, po = value  # type: ignore[misc]
                push(ps)
                push(po)
            else:
                raise AssertionError(kind)
        push(0x9000)  # return CS
        push(0x0000)  # return IP; code hook stops here
        u.reg_write(UC_X86_REG_SS, stack_seg)
        u.reg_write(UC_X86_REG_SP, sp)
        u.reg_write(UC_X86_REG_DS, segments[symbols["enabled_flag"][0]]["seg"])
        u.reg_write(UC_X86_REG_CS, segments[symbols[name][0]]["seg"])
        u.reg_write(UC_X86_REG_IP, symbols[name][1])
        u.reg_write(UC_X86_REG_EFLAGS, 0x202)
        try:
            u.emu_start(linear(name), 0, count=5_000_000)
        except Exception:
            pc=(u.reg_read(UC_X86_REG_CS)<<4)+u.reg_read(UC_X86_REG_IP)
            print('CPU fault',name,hex(pc),bytes(u.mem_read(pc,12)).hex(),sorted(((pc-linear(n),n) for n in symbols if 0<=pc-linear(n)<512))[:6],trace)
            raise
        assert u.reg_read(UC_X86_REG_CS) == 0x9000 and u.reg_read(UC_X86_REG_IP) == 0, f"{name} did not return normally"
        assert u.reg_read(UC_X86_REG_SP) == sp0, f"{name} stack imbalance: {u.reg_read(UC_X86_REG_SP):04x} != {sp0:04x}"
        return u.reg_read(UC_X86_REG_DX), u.reg_read(UC_X86_REG_AX)

    def ptr(at: int) -> tuple[int, int]:
        return at >> 4, at & 15

    # Use a valid SRCCOPY ROP DWORD and null brush/draw-mode pointers.
    rop_addr = 0x95000
    u.mem_write(rop_addr, struct.pack("<I", 0x00CC0020))
    rop = ptr(rop_addr)
    null = (0, 0)
    descp = ptr(desc)

    result = {"driver": str(driver), "status": "PASS", "tests": [],
              "segment_delta": delta, "scan_segment": 200,
              "fill_bytes": 1536, "bands": [64000, 17920],
              "Pixel_and_text": "Verified in native Windows; this fixture is restricted to BitBlt after three host Pixel-fixture failures"}

    # Two overlapping moves deliberately require opposite Y traversal. The
    # complete source image is saved before each call, so overlap direction
    # errors cannot be hidden by the expected-value calculation.
    for dst_y, src_y, direction in ((198, 200, "forward"), (200, 198, "backward")):
        initial = seed()
        expected = bytearray(initial)
        expected[dst_y * 320:(dst_y + 4) * 320] = initial[src_y * 320:(src_y + 4) * 320]
        status = call("TBitBlt", [("p", descp), ("w", 0), ("w", dst_y),
                                  ("p", descp), ("w", 0), ("w", src_y),
                                  ("w", 640), ("w", 4), ("d", 0x00CC0020), ("p", null), ("p", null)])
        assert status[1] != 0x8000 or status[0] != 0, f"BitBlt {direction} returned error"
        actual = band_bytes()
        assert actual == bytes(expected), f"BitBlt {direction} rows {src_y}..{src_y+3} -> {dst_y}..{dst_y+3} mismatch"
        result["tests"].append({"kind": "BitBlt", "direction": direction, "dst_y": dst_y, "src_y": src_y, "height": 4, "status": list(status)})

    b0=linear("shadow_bits");b1=linear("shadow_tail")
    assert bytes(u.mem_read(b0 + 64000, len(guard0))) == guard0, "first-band fill guard changed"
    assert bytes(u.mem_read(b1 + 17920, len(guard1))) == guard1, "final-band guard changed"
    result["guard_bytes_preserved"] = len(guard0) + len(guard1)
    result["selector_delta_is_actual_loaded_delta"] = True
    result["status"] = "PASS"
    out = ROOT / ("XY/HUGE-BLT-NEG.json" if reverse else "XY/HUGE-BLT-POS.json")
    out.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
