from pathlib import Path
from contextlib import contextmanager
import msvcrt,json,os,subprocess,time
LOCK=Path(r'C:\Users\chad\Documents\Codex\2026-10-06\tandy-emulator.lock')
DOSBOX=Path(r'E:\budmaker\Claude-Build-Kit\tools\DOSBOX\dosbox-x.exe')
@contextmanager
def lease(status):
    with LOCK.open('rb') as f:
        f.seek(0);msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1)
        begin=time.time()
        try:
            count=subprocess.check_output(['powershell.exe','-NoProfile','-Command','@(Get-Process -Name dosbox-x,dosbox,86Box,pcem,tandybox -ErrorAction SilentlyContinue).Count'],text=True).strip()
            if count!='0':raise RuntimeError('Emulator active; no process touched')
            status.write_text(json.dumps(dict(acquired=True,pid=os.getpid(),purpose='horizontal CRTC private experiment',start=begin)))
            yield
        finally:
            f.seek(0);msvcrt.locking(f.fileno(),msvcrt.LK_UNLCK,1)
            status.write_text(json.dumps(dict(acquired=True,released=True,pid=os.getpid(),start=begin,end=time.time())))
def hidden():
    original=subprocess.Popen
    class HiddenPopen(original):
        def __init__(self,*a,**kw):
            si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0
            kw['startupinfo']=si;kw['creationflags']=kw.get('creationflags',0)|subprocess.CREATE_NO_WINDOW
            super().__init__(*a,**kw)
    subprocess.Popen=HiddenPopen
