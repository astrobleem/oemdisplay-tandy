from pathlib import Path
import sys,importlib.machinery,shutil,json,hashlib,struct
from xy_lease import lease,hidden,DOSBOX
W=Path(__file__).resolve().parent
sys.path.insert(0,str(W/'build-view/src/tandysw'))
P=W/'xy-source/experiments/XYPAN'
patcher=importlib.machinery.SourceFileLoader('xypatch',str(P/'XYPATCH.PY')).load_module()
b=importlib.machinery.SourceFileLoader('xybuild',str(W/'build-view/src/tandysw/BUILD88.PY')).load_module()
prepare,run=b.baseline.prepare,b.bounded_run;state={}
def prep(repo,out):
    r,s=prepare(repo,out);state.update(renderer=r,resources=s);return r,s
def do(*a,**kw):
    if not state.get('patched'):
        patcher.patch(state['renderer']);state['patched']=True
    return run(*a,**kw)
b.baseline.prepare,b.bounded_run=prep,do
tag=sys.argv[1] if len(sys.argv)>1 else 'XYB1'
hidden();sys.argv=['BUILD88.PY','--repo',str(W/'build-view'),'--dosbox',str(DOSBOX),'--out',str(W/tag),'--mode','320x200x16','--ui-profile','compact320']
with lease(W/(tag+'-LEASE.json')):b.main()
shutil.copyfile(W/tag/'TANDY88.DRV',W/tag/'HPXY.DRV')
p=W/tag/'HPXY.DRV';raw=p.read_bytes();ne=struct.unpack_from('<I',raw,0x3c)[0]
n=struct.unpack_from('<H',raw,ne+0x1c)[0];off=ne+struct.unpack_from('<H',raw,ne+0x22)[0]
gross=sum((struct.unpack_from('<H',raw,off+i*8+6)[0] or 65536) for i in range(n))
meta=dict(candidate='HPXY segmented 640x256 PRIVATE',logical=[640,256,16],viewport=[320,200,16],shadow_bands=[64000,17920],hardware_default=False,edge_default=False,physical_tested=False,software_fallback=True,stage_bytes=1440,NE_all_segments_gross_bytes=gross,delta_from_R3_gross_bytes=gross-102955,incremental_ceiling=24576,sha256=hashlib.sha256(raw).hexdigest())
(W/tag/'XY.json').write_text(json.dumps(meta,indent=2));assert gross-102955<=24576,meta
print(json.dumps(meta))
