"""Same shared nonblocking lock; includes the renamed FIXBOX audio guest."""
from pathlib import Path
from contextlib import contextmanager
import msvcrt,json,os,subprocess,time
from lease import hidden,DOSBOX,LOCK
@contextmanager
def lease(status):
    status=Path(status)
    with LOCK.open('rb') as f:
        f.seek(0);msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1)
        begin=time.time();acquired=False
        try:
            count=subprocess.check_output(['powershell.exe','-NoProfile','-Command','@(Get-Process -Name dosbox-x,dosbox,86Box,pcem,tandybox,FIXBOX -ErrorAction SilentlyContinue).Count'],text=True).strip()
            if count!='0':raise RuntimeError('Emulator active; no process touched')
            acquired=True
            status.write_text(json.dumps(dict(acquired=True,pid=os.getpid(),purpose='private segmented XY pan',start=begin)))
            yield
        finally:
            f.seek(0);msvcrt.locking(f.fileno(),msvcrt.LK_UNLCK,1)
            status.write_text(json.dumps(dict(acquired=acquired,released=True,pid=os.getpid(),start=begin,end=time.time())))
