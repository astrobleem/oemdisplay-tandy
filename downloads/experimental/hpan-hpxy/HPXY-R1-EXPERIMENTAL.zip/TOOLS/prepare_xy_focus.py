from pathlib import Path
import sys,shutil,re,json,hashlib
W=Path(__file__).resolve().parent
sys.path.insert(0,r'C:\Users\chad\Documents\Codex\2026-10-14\task-16\deps-local')
from pyfatfs.PyFatFS import PyFatFS
name,build,apps=sys.argv[1:4];O=W/name;O.mkdir();G=O/'guest';G.mkdir()
S=Path(r'C:\Users\chad\Documents\Codex\2026-10-13\task-4\PAN-R2-CAPTION\guest')
shutil.copytree(S/'WINDOWS',G/'WINDOWS')
shutil.copyfile(W/build/'HPXY.DRV',G/'WINDOWS/HPXY.DRV')
for n in ['XYFOC.EXE','XYCTL.EXE']:
    if (W/apps/n).exists():shutil.copyfile(W/apps/n,G/'WINDOWS'/n)
def dos(p,s):p.write_bytes(s.replace('\r\n','\n').replace('\n','\r\n').encode('ascii'))
edges=len(sys.argv)>4 and sys.argv[4]=='edges'
extra=len(sys.argv)>4 and sys.argv[4] in ('extra','edges')
for marker in re.findall(r'"C:\\\\(HP[A-Z0-9]+\.TXT)"',(W/'horizontal-source/experiments/HPAN/HQA.C').read_text()):
    base,ext=marker.split('.');assert len(base)<=8 and len(ext)<=3,('DOS 8.3 marker required',marker)
p=G/'WINDOWS/SYSTEM.INI';s=re.sub(r'(?im)^display.drv=.*','display.drv=HPXY.DRV',p.read_text(),count=1);s=re.sub(r'(?im)^shell=.*','shell=XYFOC.EXE',s);dos(p,s)
p=G/'WINDOWS/WIN.INI';dos(p,re.sub(r'(?im)^(run|load)=.*',lambda m:m[1]+'=',p.read_text())+'\n[HPanQA]\nExtra='+str(2 if edges else int(extra))+'\n')
disk=O/'DISK.IMG';shutil.copyfile(Path(r'C:\Users\chad\Documents\Codex\2026-10-14\task-15\HOV8088-BASE.IMG'),disk)
offset=17408
with PyFatFS(str(disk),offset=offset) as fs:
    def put(path,data):
        if fs.exists(path):fs.remove(path)
        fs.writebytes(path,data);assert fs.readbytes(path)==data
    fs.makedirs('CW',recreate=True)
    for p in (G/'WINDOWS').rglob('*'):
        rel='CW/'+p.relative_to(G/'WINDOWS').as_posix()
        if p.is_dir():fs.makedirs(rel,recreate=True)
        else:put(rel,p.read_bytes())
    for n in ['HPRUN.TXT','HP.LOG','HPSTEP.TXT','HPRET1.TXT','HPRET2.TXT','HPDONE.TXT','HPKEYS.TXT','HPDRAG.TXT','HPSIZE.TXT','HPKEYH.TXT','HPKEYHM.TXT','HPKEYQ.TXT','XYRUN.TXT','XY.LOG','XYSTEP.TXT']:
        if fs.exists(n):fs.remove(n)
    put('RESERVE.COM',(S/'RESERVE.COM').read_bytes())
    put('CONFIG.SYS',b'FILES=40\r\nBUFFERS=10\r\nLASTDRIVE=E\r\n')
    auto='@ECHO OFF\nC:\\RESERVE 16K > C:\\RESERVE.TXT\nIF ERRORLEVEL 1 GOTO BAD\nSET PATH=C:\\CW;C:\\DOS\nSET TEMP=C:\\CW\\TEMP\nCD \\CW\nWIN /R\nCD \\\nECHO RETURN1 > C:\\HPRET1.TXT\nPAUSE\nCD \\CW\nWIN /R\nCD \\\nECHO RETURN2 > C:\\HPRET2.TXT\nECHO DONE > C:\\HPDONE.TXT\n:BAD\n'
    put('AUTOEXEC.BAT',auto.replace('\n','\r\n').encode())
cfg=f'''[General]
confirm_exit = 0
confirm_reset = 0
confirm_save = 0
vid_renderer = qt_software
video_filter_method = 0
scale = 1
enable_overscan = 1
[Machine]
machine = tandy1000hx
cpu_family = 8088
cpu_speed = 4772728
cpu_multi = 1
cpu_use_dynarec = 0
mem_size = 640
time_sync = disabled
[Video]
gfxcard = internal
[Input devices]
keyboard_type = internal
mouse_type = msserial
[Storage controllers]
hdc_1 = xtide
[Hard disks]
hdd_01_fn = {disk}
hdd_01_ide_channel = 0:0
hdd_01_parameters = 34, 5, 969, 0, ide
hdd_01_speed = ramdisk
[PC/XT XTIDE]
bios = xt
[Tandy 1000 HX]
display_type = 0
'''
(O/'86box.cfg').write_text(cfg)
(O/'MEDIA.json').write_text(json.dumps(dict(disk=str(disk),offset=offset,build=build,apps=apps,extra=extra,edges=edges,driver_sha256=hashlib.sha256((W/build/'HPXY.DRV').read_bytes()).hexdigest(),emulator='86Box development native headless/GDB',hz=4772728,mem_kb=640,ems=False,xms=False),indent=2))
print('Prepared',O)
