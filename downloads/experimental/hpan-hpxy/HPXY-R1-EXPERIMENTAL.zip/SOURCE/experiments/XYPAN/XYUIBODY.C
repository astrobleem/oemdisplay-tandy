static HWND helper;
static HINSTANCE instanceUI;
static void Command(int code){Check("HELPER_WINDOW",IsWindow(helper));SendMessage(helper,WM_COMMAND,code,0L);Pan(-1,0);}
static void Marker(LPSTR name){HFILE f;f=_lcreat(name,0);_lwrite(f,"READY",5);_lclose(f);}
static int WaitPan(int x,int y,DWORD limit){DWORD start;start=GetTickCount();while((DWORD)(GetTickCount()-start)<limit){Pump(100);Pan(-1,0);if(pan[0]==x && pan[1]==y)return 1;}return 0;}
static void EdgeLeg(int x,int y,int tx,int ty,int id) {
 DWORD start;int oldx,oldy,ok;POINT p;
 Command(107);Pan(x,y);SetCursor(0);SetCursorPos(tx>x?x+319:x,ty>y?y+199:y);Command(106);oldx=x;oldy=y;ok=1;start=GetTickCount();
 while((DWORD)(GetTickCount()-start)<60000L){Pump(100);Pan(-1,0);if(pan[0]!=oldx || pan[1]!=oldy){
  if((pan[0]-oldx!=0 && pan[0]-oldx!=(tx>x?8:-8)) || (pan[1]-oldy!=0 && pan[1]-oldy!=(ty>y?4:-4)))ok=0;
  oldx=pan[0];oldy=pan[1];
 }if(pan[0]==tx && pan[1]==ty)break;}
 Command(107);Check("EDGE_STEPS",ok);Check("EDGE_TARGET",pan[0]==tx && pan[1]==ty);GetCursorPos(&p);Snap(id,0,p.x,p.y);
}
BOOL FAR PASCAL Dlg(HWND w,UINT m,WPARAM a,LPARAM b){RECT r;
 if(m==WM_INITDIALOG){SetWindowPos(w,0,480,218,144,36,SWP_NOZORDER);SetTimer(w,2,2200,0);return 1;}
 if(m==WM_TIMER){KillTimer(w,2);Pan(-1,0);GetWindowRect(w,&r);wsprintf(line,"DIALOG_RECT %d %d %d %d PAN %d %d\r\n",r.left,r.top,r.right,r.bottom,pan[0],pan[1]);Log(line);Check("DIALOG_FITS",r.left>=pan[0] && r.right<=pan[0]+320 && r.top>=pan[1] && r.bottom<=pan[1]+200);Snap(515,0,pan[0]+50,pan[1]+50);EndDialog(w,1);return 1;}
 return 0;
}
static void PutWord(BYTE FAR **p,unsigned v){*(*p)++=(BYTE)v;*(*p)++=(BYTE)(v>>8);}
static void DialogTest(void){HGLOBAL memory;BYTE FAR *p;FARPROC thunk;DWORD style;char *s;
 Command(107);Pan(0,0);Command(111);memory=GlobalAlloc(GMEM_MOVEABLE|GMEM_ZEROINIT,128);Check("DIALOG_ALLOC",memory!=0);if(!memory)return;
 p=(BYTE FAR *)GlobalLock(memory);style=WS_POPUP|WS_CAPTION|DS_MODALFRAME;PutWord(&p,LOWORD(style));PutWord(&p,HIWORD(style));*p++=0;PutWord(&p,0);PutWord(&p,0);PutWord(&p,80);PutWord(&p,20);*p++=0;*p++=0;s="XY corner dialog";while(*s)*p++=*s++;*p++=0;GlobalUnlock(memory);
 thunk=MakeProcInstance((FARPROC)Dlg,instanceUI);Check("DIALOG_RESULT",DialogBoxIndirect(instanceUI,memory,mainWnd,(DLGPROC)thunk)==1);FreeProcInstance(thunk);GlobalFree(memory);Command(112);
}
static void UI(void){DWORD start;int i,oldx,oldy;POINT p;RECT before,after;HWND moving;
 for(i=0;i<3;i++){Bench(i,0);Bench(i,1);}
 Check("HELPER_EXEC",WinExec("XYCTL.EXE",SW_SHOW)>31);start=GetTickCount();helper=0;while((DWORD)(GetTickCount()-start)<10000L){Pump(100);helper=FindWindow("XYControl",0);if(helper)break;}Check("HELPER_START",helper!=0);if(!helper)return;
 Pan(-1,0);statsProc(stats);Check("HELPER_SAFE_DEFAULT",stats[0]==0);Command(105);
 for(i=0;i<14;i++)Command(110);Check("MENU_DOWN",pan[1]==56 && pan[0]==0);for(i=0;i<14;i++)Command(109);Check("MENU_UP",pan[1]==0);Snap(510,0,400,120);
 EdgeLeg(0,0,320,56,511);EdgeLeg(320,56,0,0,512);
 Mode(2);Pan(8,4);Snap(518,0,50,50);Check("FAULT_FALLBACK",stats[0]==0 && stats[3]==4 && stats[2]==0);Command(105);Pan(0,0);
 SetCursor(0);Command(107);Pan(160,28);GetCursorPos(&p);SetCursorPos(180,48);Command(102);GetCursorPos(&p);Check("POINTER_X",p.x==188 && p.y==48);Command(110);GetCursorPos(&p);Check("POINTER_Y",p.x==188 && p.y==52);
 SetActiveWindow(helper);SetFocus(helper);Marker("C:\\XYKEY.TXT");Pump(5000);Pan(-1,0);Check("RAW_UP",pan[0]==168 && pan[1]==28);Snap(513,0,188,48);
 DialogTest();
 Pan(304,56);Command(107);SetWindowPos(helper,HWND_TOP,316,68,0,0,SWP_NOSIZE);SetActiveWindow(helper);SetFocus(helper);Marker("C:\\XYMENU.TXT");Pump(2000);Snap(514,0,500,120);Pump(500);
 moving=CreateWindow("XYQA","XY moved window",WS_OVERLAPPEDWINDOW,400,170,200,70,0,0,instanceUI,0);ShowWindow(moving,SW_SHOW);UpdateWindow(moving);SetActiveWindow(moving);GetWindowRect(moving,&before);Marker("C:\\XYMOVE.TXT");Pump(3000);GetWindowRect(moving,&after);Check("WINDOW_MOVED",after.left>before.left && after.top>before.top);Snap(516,0,500,180);DestroyWindow(moving);
 Command(103);Check("MENU_HOME",pan[0]==0 && pan[1]==0);Command(104);SetActiveWindow(helper);SetFocus(helper);Marker("C:\\XYQUIT.TXT");Pump(5000);Check("RAW_QUIT",!IsWindow(helper));Pan(-1,0);statsProc(stats);Check("HELPER_RESET",pan[0]==0 && pan[1]==0 && stats[0]==0);Snap(517,0,50,50);
}
