static void Bench(int kind,int mode) {
 HDC dc;int in[2],out[6],i,ok;DWORD start,elapsed;
 Mode(mode);Pan(0,0);dc=GetDC(0);ok=1;start=GetTickCount();
 for(i=0;i<8;i++){in[0]=(kind!=1 && !(i&1))?8:0;in[1]=(kind!=0 && !(i&1))?4:0;if(Escape(dc,ESC_XY,4,(LPSTR)in,(LPSTR)out)<=0)ok=0;}
 elapsed=GetTickCount()-start;ReleaseDC(0,dc);statsProc(stats);Check("BENCH_ESCAPES",ok);
 wsprintf(line,"BENCH kind=%d mode=%d steps=8 ms=%lu lastBytes=%u enabled=%u\r\n",kind,mode,elapsed,stats[7],stats[0]);Log(line);
}
