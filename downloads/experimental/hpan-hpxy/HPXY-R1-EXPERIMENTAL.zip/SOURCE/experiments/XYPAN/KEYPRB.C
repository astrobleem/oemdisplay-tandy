#include <windows.h>
#include <string.h>
static HWND window;static HFILE file;static DWORD start;static int last[8],records;static char line[240];
static void Log(LPSTR s){if(records++>128)return;_lwrite(file,s,lstrlen(s));_lclose(file);file=_lopen("C:\\KEY.LOG",OF_WRITE);_llseek(file,0L,2);}
static void State(int msg,int vk){int v[8],i,changed;v[0]=GetAsyncKeyState(VK_CONTROL);v[1]=GetAsyncKeyState(VK_MENU);v[2]=GetAsyncKeyState(VK_UP);v[3]=GetAsyncKeyState('Q');v[4]=GetKeyState(VK_CONTROL);v[5]=GetKeyState(VK_MENU);v[6]=GetKeyState(VK_UP);v[7]=GetKeyState('Q');changed=msg!=0;
 for(i=0;i<8;i++){if(v[i]!=last[i])changed=1;last[i]=v[i];}if(changed){wsprintf(line,"KEY tick=%lu msg=%x vk=%x async=%x,%x,%x,%x sync=%x,%x,%x,%x focus=%u active=%u own=%u\r\n",GetTickCount(),msg,vk,v[0],v[1],v[2],v[3],v[4],v[5],v[6],v[7],GetFocus(),GetActiveWindow(),window);Log(line);}}
long FAR PASCAL Wnd(HWND w,UINT m,WPARAM a,LPARAM b){PAINTSTRUCT ps;HDC dc;
 if(m==WM_PAINT){dc=BeginPaint(w,&ps);TextOut(dc,4,4,"Private raw input probe",23);EndPaint(w,&ps);return 0;}
 if(m==WM_KEYDOWN||m==WM_KEYUP||m==WM_SYSKEYDOWN||m==WM_SYSKEYUP)State(m,a);
 if(m==WM_TIMER){State(0,0);if((DWORD)(GetTickCount()-start)>16000L){KillTimer(w,1);Log("END\r\n");_lclose(file);ExitWindows(0,0);}return 0;}
 return DefWindowProc(w,m,a,b);}
int PASCAL WinMain(HINSTANCE instance,HINSTANCE previous,LPSTR cmd,int show){WNDCLASS wc;FARPROC thunk;MSG msg;HFILE marker;
 file=_lcreat("C:\\KEY.LOG",0);memset(&wc,0,sizeof(wc));thunk=MakeProcInstance((FARPROC)Wnd,instance);wc.lpfnWndProc=(WNDPROC)thunk;wc.hInstance=instance;wc.lpszClassName="KEYPRB";wc.hbrBackground=(HBRUSH)(COLOR_WINDOW+1);RegisterClass(&wc);
 window=CreateWindow("KEYPRB","Input probe",WS_OVERLAPPEDWINDOW,8,8,280,100,0,0,instance,0);ShowWindow(window,SW_SHOWNORMAL);BringWindowToTop(window);SetActiveWindow(window);SetFocus(window);UpdateWindow(window);State(1,0);start=GetTickCount();SetTimer(window,1,50,0);
 marker=_lcreat("C:\\KEYRDY.TXT",0);_lwrite(marker,"READY",5);_lclose(marker);
 while(GetMessage(&msg,0,0,0)){TranslateMessage(&msg);DispatchMessage(&msg);}return 0;}
