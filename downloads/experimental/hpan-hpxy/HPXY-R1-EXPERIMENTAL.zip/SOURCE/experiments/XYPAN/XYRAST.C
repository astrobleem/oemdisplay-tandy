#define WINVER 0x0300
#include <windows.h>
#include <string.h>
#define ESC_XY 0x5860
#define ESC_MODE 0x5861
typedef int (FAR PASCAL *ROWS)(LPSTR,unsigned,unsigned);
typedef int (FAR PASCAL *STATS)(unsigned FAR *);
static HWND mainWnd;
static HCURSOR cursor,active;
static HFILE logFile;
static ROWS rowsProc;
static STATS statsProc;
static char buffer[3840],line[240];
static int failures,run;
static unsigned stats[8];
static int pan[6];
static void Log(LPSTR s) { _lwrite(logFile,s,lstrlen(s));_lclose(logFile);logFile=_lopen("C:\\XY.LOG",OF_WRITE);_llseek(logFile,0L,2); }
static void Check(LPSTR s,int ok) {
 wsprintf(line,"CHECK %s=%d\r\n",s,ok!=0);Log(line);if(!ok)failures++;
}
static void Pump(DWORD ms) {
 DWORD start;MSG msg;start=GetTickCount();
 while((DWORD)(GetTickCount()-start)<ms)while(PeekMessage(&msg,0,0,0,PM_REMOVE)){TranslateMessage(&msg);DispatchMessage(&msg);}
}
static void Pan(int x,int y) {
 HDC dc;int in[2],ok;dc=GetDC(0);in[0]=x;in[1]=y;
 ok=Escape(dc,ESC_XY,4,(LPSTR)in,(LPSTR)pan)>0;if(x!=-1 || !ok)Check("ESC_XY",ok);ReleaseDC(0,dc);
}
static void Mode(int m) {HDC dc;dc=GetDC(0);Check("ESC_MODE",Escape(dc,ESC_MODE,2,(LPSTR)&m,0)>0);ReleaseDC(0,dc);}
static COLORREF Color(int k) {int r,g,b;r=(k&4)?170:0;g=(k&2)?170:0;b=(k&1)?170:0;if(k&8){r+=85;g+=85;b+=85;}return RGB(r,g,b);}
static void Pattern(HDC dc) {
 int x,y;RECT r;HBRUSH b;
 for(y=0;y<256;y+=32)for(x=0;x<640;x+=80){
  r.left=x;r.top=y;r.right=x+80;r.bottom=y+32;
  b=CreateSolidBrush(GetNearestColor(dc,Color((x/80+2*(y/32))&15)));FillRect(dc,&r,b);DeleteObject(b);
 }
 TextOut(dc,4,190,"BAND 199/200",12);TextOut(dc,340,234,"LOWER RIGHT",11);
}
static void Snap(int id,int visible,int x,int y) {
 HFILE f;char name[24];unsigned first,count,n,off;char FAR *video;POINT point;int rowsOK;
 active=visible?cursor:(HCURSOR)0;SetCursorPos(x,y);SetCursor(active);Pump(150);SetCursor(active);
 GetCursorPos(&point);x=point.x;y=point.y;Pan(-1,0);statsProc(stats);
 wsprintf(name,"C:\\S%03d.BIN",id);f=_lcreat(name,0);Check("SHADOW_FILE",f!=HFILE_ERROR);
 rowsOK=1;if(f!=HFILE_ERROR){for(first=0;first<256;first+=12){count=256-first;if(count>12)count=12;n=rowsProc(buffer,first,count);if(n!=count*320)rowsOK=0;if(_lwrite(f,buffer,n)!=n)rowsOK=0;}_lclose(f);}Check("ROWS_STREAM",rowsOK);
 wsprintf(name,"C:\\V%03d.BIN",id);f=_lcreat(name,0);video=(char FAR *)MAKELONG(0,0xb800);
 if(f!=HFILE_ERROR){for(off=0;off<32768U;off+=8192U)_lwrite(f,video+off,8192);_lclose(f);}else Check("VIDEO_FILE",0);
 wsprintf(line,"STEP id=%d left=%d top=%d head=%u enabled=%u reason=%u hw=%u sw=%u bytes=%u cursor=%d x=%d y=%d\r\n",id,pan[0],pan[1],stats[2],stats[0],stats[3],stats[4],stats[5],stats[7],visible,x,y);Log(line);
 f=_lcreat("C:\\XYSTEP.TXT",0);_lwrite(f,line,lstrlen(line));_lclose(f);Pump(1200);
}
static void Raster(HDC dc) {
 int i,x,y,ok,w,h;COLORREF want[8],outside;HRGN clip;DWORD extent;
 struct {BITMAPINFOHEADER header;RGBQUAD colors[16];} dib;
 BYTE bits[48];COLORREF color;
 for(i=0;i<8;i++){want[i]=GetNearestColor(dc,Color(i+1));SetPixel(dc,50,196+i,want[i]);}
 for(i=0;i<8;i++)Check("PIXEL_BAND",GetPixel(dc,50,196+i)==want[i]);
 SetPixel(dc,639,255,Color(15));Check("PIXEL_LAST",GetPixel(dc,639,255)==GetNearestColor(dc,Color(15)));
 BitBlt(dc,50,198,1,8,dc,50,196,SRCCOPY);
 for(i=0;i<8;i++)Check("BLT_BACKWARD_BAND",GetPixel(dc,50,198+i)==want[i]);
 BitBlt(dc,50,194,1,8,dc,50,198,SRCCOPY);
 for(i=0;i<8;i++)Check("BLT_FORWARD_BAND",GetPixel(dc,50,194+i)==want[i]);
 SetPixel(dc,299,196,Color(0));SetPixel(dc,300,196,Color(0));outside=GetPixel(dc,299,196);clip=CreateRectRgn(300,196,380,206);SelectClipRgn(dc,clip);
 PatBlt(dc,280,190,120,30,WHITENESS);TextOut(dc,300,198,"TEXT CROSS",10);
 SelectClipRgn(dc,0);DeleteObject(clip);
 Check("CLIP_OUTSIDE",GetPixel(dc,299,196)==outside);
 Check("CLIP_INSIDE",GetPixel(dc,300,196)==GetNearestColor(dc,Color(15)));
 TextOut(dc,400,100,"CROSS",5);TextOut(dc,400,196,"CROSS",5);extent=GetTextExtent(dc,"CROSS",5);w=LOWORD(extent);h=HIWORD(extent);ok=w>0 && w<=80 && h>4 && h<=16;
 if(ok)for(y=0;y<h;y++)for(x=0;x<w;x++)if(GetPixel(dc,400+x,100+y)!=GetPixel(dc,400+x,196+y))ok=0;
 Check("TEXT_BAND_REFERENCE",ok);
 memset(&dib,0,sizeof(dib));dib.header.biSize=sizeof(BITMAPINFOHEADER);dib.header.biWidth=8;dib.header.biHeight=12;dib.header.biPlanes=1;dib.header.biBitCount=4;dib.header.biSizeImage=48;
 for(i=0;i<16;i++){color=Color(i);dib.colors[i].rgbRed=GetRValue(color);dib.colors[i].rgbGreen=GetGValue(color);dib.colors[i].rgbBlue=GetBValue(color);}
 for(i=0;i<48;i++)bits[i]=(BYTE)((i/4)*17);
 Check("DIB_BAND_ROWS",SetDIBitsToDevice(dc,600,194,8,12,0,0,0,12,bits,(BITMAPINFO FAR *)&dib,DIB_RGB_COLORS)==12);
 ok=1;for(y=0;y<12;y++)if(GetPixel(dc,600,194+y)!=GetNearestColor(dc,Color(11-y)))ok=0;Check("DIB_BAND_PIXELS",ok);
 outside=GetPixel(dc,629,247);BitBlt(dc,630,248,32,16,dc,620,240,SRCCOPY);Check("BLT_BOTTOM_RIGHT_CLIP",GetPixel(dc,639,255)==outside);
 Check("PIXEL_OUTSIDE",GetPixel(dc,640,255)==0xffffffffL && GetPixel(dc,639,256)==0xffffffffL);
 Check("CHUNK_REJECT",rowsProc(buffer,255,2)==0 && rowsProc(buffer,0,13)==0);
}
long FAR PASCAL Wnd(HWND w,UINT m,WPARAM a,LPARAM b) {
 PAINTSTRUCT ps;HDC dc;
 if(m==WM_SETCURSOR){SetCursor(active);return 1;}
 if(m==WM_PAINT){dc=BeginPaint(w,&ps);Pattern(dc);EndPaint(w,&ps);return 0;}
 return DefWindowProc(w,m,a,b);
}
static void Bench(int kind,int mode) {
 HDC dc;int in[2],out[6],i,ok;DWORD start,elapsed;
 Mode(mode);Pan(0,0);dc=GetDC(0);ok=1;start=GetTickCount();
 for(i=0;i<8;i++){in[0]=(kind!=1 && !(i&1))?8:0;in[1]=(kind!=0 && !(i&1))?4:0;if(Escape(dc,ESC_XY,4,(LPSTR)in,(LPSTR)out)<=0)ok=0;}
 elapsed=GetTickCount()-start;ReleaseDC(0,dc);statsProc(stats);Check("BENCH_ESCAPES",ok);
 wsprintf(line,"BENCH kind=%d mode=%d steps=8 ms=%lu lastBytes=%u enabled=%u\r\n",kind,mode,elapsed,stats[7],stats[0]);Log(line);
}

int PASCAL WinMain(HINSTANCE instance,HINSTANCE previous,LPSTR command,int show) {
 HINSTANCE display;WNDCLASS wc;FARPROC thunk;HDC dc;HFILE f;int x,y,i;unsigned char am[64],xm[64];DWORD a,b;
 f=_lopen("C:\\XYRUN.TXT",OF_READ);run=f==HFILE_ERROR?1:2;if(f!=HFILE_ERROR)_lclose(f);
 if(run==1){f=_lcreat("C:\\XYRUN.TXT",0);_lwrite(f,"1",1);_lclose(f);logFile=_lcreat("C:\\XY.LOG",0);}else{logFile=_lopen("C:\\XY.LOG",OF_WRITE);_llseek(logFile,0L,2);}
 wsprintf(line,"START run=%d free=%lu largest=%lu\r\n",run,GetFreeSpace(0),GlobalCompact(0L));Log(line);
 Check("GEOMETRY",GetSystemMetrics(0)==640 && GetSystemMetrics(1)==256);
 display=GetModuleHandle("DISPLAY");rowsProc=(ROWS)GetProcAddress(display,(LPSTR)108L);statsProc=(STATS)GetProcAddress(display,(LPSTR)106L);
 Check("EXPORTS",rowsProc!=0 && statsProc!=0);if(!rowsProc || !statsProc)goto done;
 Pan(-1,0);Check("INITIAL",pan[0]==0 && pan[1]==0 && pan[4]==640 && pan[5]==256);statsProc(stats);Check("DEFAULT_SOFTWARE",stats[0]==0);
 memset(&wc,0,sizeof(wc));thunk=MakeProcInstance((FARPROC)Wnd,instance);wc.lpfnWndProc=(WNDPROC)thunk;wc.hInstance=instance;wc.lpszClassName="XYQA";wc.hbrBackground=(HBRUSH)(COLOR_WINDOW+1);RegisterClass(&wc);
 memset(am,255,sizeof(am));memset(xm,0,sizeof(xm));for(i=0;i<8;i++){am[i*4]=0;xm[i*4]=(unsigned char)(0x80>>i);}
 cursor=CreateCursor(instance,0,0,32,16,am,xm);active=0;
 mainWnd=CreateWindow("XYQA","PRIVATE XY segmentation proof",WS_POPUP,0,0,640,256,0,0,instance,0);Check("WINDOW",mainWnd!=0);ShowWindow(mainWnd,SW_SHOW);UpdateWindow(mainWnd);SetCursor(0);
 dc=GetDC(mainWnd);if(run==1)Raster(dc);ReleaseDC(mainWnd,dc);Snap(run==1?0:900,0,400,120);
 if(run==1){for(i=0;i<3;i++){Bench(i,0);Bench(i,1);}Pan(320,56);Snap(700,0,500,180);Mode(2);Pan(312,52);Snap(701,0,500,180);Check("FAULT_FALLBACK",stats[0]==0 && stats[3]==4 && stats[2]==0);}else{Mode(1);Pan(320,56);Snap(901,1,639,255);}
 SetCursor(0);Mode(0);Pan(0,0);DestroyWindow(mainWnd);DestroyCursor(cursor);UnregisterClass("XYQA",instance);FreeProcInstance(thunk);
done:
 wsprintf(line,"END run=%d FAILURES=%d free=%lu largest=%lu\r\n",run,failures,GetFreeSpace(0),GlobalCompact(0L));Log(line);_lclose(logFile);ExitWindows(0,0);return 0;
}
