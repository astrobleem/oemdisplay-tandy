#define WINVER 0x0300
#include <windows.h>
#include <string.h>
#define ESC_XY 0x5860
#define ESC_MODE 0x5861
#define LEFT 101
#define RIGHT 102
#define HOME 103
#define SOFT 104
#define HARD 105
#define EDGEON 106
#define EDGEOFF 107
#define QUIT 108
#define UP 109
#define DOWN 110
#define FOLLOWON 111
#define FOLLOWOFF 112
typedef int (FAR PASCAL *STATS)(unsigned FAR *);
static HWND window;
static HDC display;
static STATS statsProc;
static HFILE logFile=HFILE_ERROR;
static int left,top,hardware,edge,follow,live,closing,logCount;
static int directionX,directionY,latch[10];
static DWORD since;
static int keys[9]={VK_LEFT,VK_RIGHT,VK_UP,VK_DOWN,VK_HOME,'H','E','F','Q'};
static void Log(LPSTR event,int a,int b,int c,int d) {
 char line[112];
 if(logFile==HFILE_ERROR || logCount>=512)return;
 wsprintf(line,"%s tick=%lu a=%d b=%d c=%d d=%d\r\n",event,GetTickCount(),a,b,c,d);
 _lwrite(logFile,line,lstrlen(line));logCount++;
}
static int Query(void) {
 int in[2],out[6],ok;unsigned st[8];
 in[0]=-1;in[1]=0;
 ok=Escape(display,ESC_XY,4,(LPSTR)in,(LPSTR)out)>0;
 if(!ok || out[0]<0 || out[0]>320 || (out[0]&7) || out[1]<0 || out[1]>56 || (out[1]&3) || out[2]!=320 || out[3]!=200 || out[4]!=640 || out[5]!=256)return 0;
 left=out[0];top=out[1];
 if(statsProc){statsProc(st);hardware=st[0]!=0;}
 return 1;
}
static int Pan(int x,int y) {
 int in[2],out[6],oldX,oldY,keep;POINT p;unsigned st[8];
 directionX=directionY=0;if(!live)return 0;
 if(x<0)x=0;if(x>320)x=320;if(y<0)y=0;if(y>56)y=56;
 x&=0xfff8;y&=0xfffc;oldX=left;oldY=top;
 if(x==oldX && y==oldY)return 1;
 GetCursorPos(&p);keep=p.x>=oldX && p.x<oldX+320 && p.y>=oldY && p.y<oldY+200;
 in[0]=x;in[1]=y;
 if(Escape(display,ESC_XY,4,(LPSTR)in,(LPSTR)out)<=0 || !Query()) {live=0;Log("ERROR",x,y,0,0);return 0;}
 if(keep)SetCursorPos(p.x+left-oldX,p.y+top-oldY);
 Log("PAN",oldX,oldY,left,top);
 if(statsProc){statsProc(st);Log("PSTAT",st[2],st[3],st[7],st[0]);}
 InvalidateRect(window,0,FALSE);return 1;
}
static void Mode(int value) {
 int ok;if(!live)return;directionX=directionY=0;
 ok=Escape(display,ESC_MODE,2,(LPSTR)&value,0)>0;Query();Log("MODE",value,hardware,ok,0);InvalidateRect(window,0,FALSE);
}
static void Cleanup(void) {
 int modeResult,panResult,confirmed,value,in[2],out[6];
 /* A failed query stops normal controls, but must never skip recovery. */
 value=0;in[0]=in[1]=0;
 modeResult=Escape(display,ESC_MODE,2,(LPSTR)&value,0);
 panResult=Escape(display,ESC_XY,4,(LPSTR)in,(LPSTR)out);
 confirmed=Query();Log("STOP",modeResult,panResult,confirmed,hardware);
 Log("STOP_ORIGIN",left,top,live,0);
}
static void Stop(void) {
 if(closing)return;closing=1;edge=follow=0;KillTimer(window,1);Cleanup();live=0;
}
static int Press(int key,int i) {
 int down;down=(GetAsyncKeyState(key)&0x8000)!=0;
 if(!down){latch[i]=0;return 0;}if(latch[i])return 0;latch[i]=1;return 1;
}
static void KeyAction(int i) {
 Log("KEY",i,left,top,0);
 switch(i){
 case 0:Pan(left-8,top);break;case 1:Pan(left+8,top);break;
 case 2:Pan(left,top-4);break;case 3:Pan(left,top+4);break;
 case 4:Pan(0,0);break;case 5:Mode(!hardware);break;
 case 6:edge=!edge;directionX=directionY=0;Log("EDGE",edge,500,0,0);InvalidateRect(window,0,FALSE);break;
 case 7:follow=!follow;Log("FOLLOW",follow,0,0,0);InvalidateRect(window,0,FALSE);break;
 case 8:PostMessage(window,WM_CLOSE,0,0L);break;
 }
}
static int KeyMessage(int key,LPARAM flags) {
 int i;if(!(GetKeyState(VK_CONTROL)&0x8000) || !(GetKeyState(VK_MENU)&0x8000))return 0;
 for(i=0;i<9;i++)if(keys[i]==key){
  if(!(flags&0x40000000L) && !closing){
   if(i==8)KeyAction(i);
   else if(live && Query())KeyAction(i);
  }return 1;
 }return 0;
}
static void Keyboard(void) {
 int k[10],chord,i,controlDown,altDown;
 /* Focused commands use queued messages so a short press survives paint.
    The timer remains a best-effort background chord path, never both. */
 if(GetActiveWindow()==window)return;
 controlDown=(GetAsyncKeyState(VK_CONTROL)&0x8000)!=0;altDown=(GetAsyncKeyState(VK_MENU)&0x8000)!=0;chord=controlDown && altDown;
 for(i=0;i<9;i++)k[i]=Press(keys[i],i);
 if(!chord)return;
 if(k[8]){KeyAction(8);return;}
 if(k[4])Pan(0,0);
 else if(k[0]||k[1]||k[2]||k[3])Pan(left+(k[1]-k[0])*8,top+(k[3]-k[2])*4);
 else if(k[5])Mode(!hardware);
 else if(k[6]){edge=!edge;directionX=directionY=0;Log("EDGE",edge,500,0,0);InvalidateRect(window,0,FALSE);}
 else if(k[7]){follow=!follow;Log("FOLLOW",follow,0,0,0);InvalidateRect(window,0,FALSE);}
}
static void Edge(void) {
 POINT p;int dx,dy,px,py,ok;DWORD now,elapsed;
 if(!edge || !live || closing){directionX=directionY=0;return;}
 GetCursorPos(&p);px=p.x-left;py=p.y-top;dx=dy=0;
 if(px<=0 && left>0)dx=-1;else if(px>=319 && left<320)dx=1;
 if(py<=0 && top>0)dy=-1;else if(py>=199 && top<56)dy=1;
 if(!dx && !dy){directionX=directionY=0;return;}
 now=GetTickCount();
 if(dx!=directionX || dy!=directionY){directionX=dx;directionY=dy;since=now;return;}
 elapsed=now-since;if(elapsed<500L)return;
 /* Clamp both overshoots before preserving the pointer's local position. */
 if(px<0)px=0;if(px>319)px=319;if(py<0)py=0;if(py>199)py=199;
 SetCursorPos(left+px,top+py);GetCursorPos(&p);
 if(p.x!=left+px || p.y!=top+py){directionX=directionY=0;return;}
 Log("EFIRE",left,top,dx,dy);Log("DWELL",(int)elapsed,px,py,0);
 ok=Pan(left+dx*8,top+dy*4);
 if(ok && live && edge){directionX=dx;directionY=dy;since=GetTickCount();}
}
static int Fit(int origin,int low,int high,int extent,int step,int limit) {
 int result;result=origin;
 if(high-low>extent || low<origin)result=low&~(step-1);
 else if(high>origin+extent)result=(high-extent+step-1)&~(step-1);
 if(result<0)result=0;if(result>limit)result=limit;return result;
}
static void Follow(void) {
 HWND active;RECT r;char name[32];int x,y;
 if(!follow || !live || closing)return;active=GetActiveWindow();
 if(!active || active==window || !IsWindowVisible(active) || IsIconic(active))return;
 GetClassName(active,name,sizeof(name));
 if(lstrcmp(name,"#32770")!=0)return;
 GetWindowRect(active,&r);x=Fit(left,r.left,r.right,320,8,320);y=Fit(top,r.top,r.bottom,200,4,56);
 if(x!=left || y!=top){Log("DIALOG",r.left,r.top,r.right,r.bottom);Pan(x,y);}
}
static HMENU Menu(void) {
 HMENU bar,p,m,e;bar=CreateMenu();p=CreatePopupMenu();m=CreatePopupMenu();e=CreatePopupMenu();
 AppendMenu(p,MF_STRING,LEFT,"&Left 8");AppendMenu(p,MF_STRING,RIGHT,"&Right 8");AppendMenu(p,MF_STRING,UP,"&Up 4");AppendMenu(p,MF_STRING,DOWN,"&Down 4");AppendMenu(p,MF_STRING,HOME,"&Home");AppendMenu(p,MF_STRING,QUIT,"E&xit");
 AppendMenu(m,MF_STRING,SOFT,"&Software");AppendMenu(m,MF_STRING,HARD,"&Hardware");
 AppendMenu(e,MF_STRING,EDGEON,"Edge &on");AppendMenu(e,MF_STRING,EDGEOFF,"Edge o&ff");AppendMenu(e,MF_STRING,FOLLOWON,"Dialog follow on");AppendMenu(e,MF_STRING,FOLLOWOFF,"Dialog follow off");
 AppendMenu(bar,MF_POPUP,(UINT)p,"&Pan");AppendMenu(bar,MF_POPUP,(UINT)m,"&Mode");AppendMenu(bar,MF_POPUP,(UINT)e,"&Options");return bar;
}
long FAR PASCAL Wnd(HWND w,UINT msg,WPARAM a,LPARAM b) {
 PAINTSTRUCT ps;HDC dc;char line[96];
 switch(msg){
 case WM_CREATE:SetTimer(w,1,100,0);return 0;
 case WM_KEYDOWN:case WM_SYSKEYDOWN:if(KeyMessage(a,b))return 0;break;
 case WM_TIMER:if(!closing && live){if(!Query()){live=edge=follow=0;Log("QUERY_ERROR",0,0,0,0);return 0;}Keyboard();Follow();Edge();}return 0;
 case WM_COMMAND:
  if(a!=QUIT && live && !Query()){live=edge=follow=0;Log("QUERY_ERROR",0,0,0,0);return 0;}
  switch(a){
   case LEFT:Pan(left-8,top);break;case RIGHT:Pan(left+8,top);break;case UP:Pan(left,top-4);break;case DOWN:Pan(left,top+4);break;
   case HOME:Pan(0,0);break;case SOFT:Mode(0);break;case HARD:Mode(1);break;
   case EDGEON:case EDGEOFF:edge=a==EDGEON;directionX=directionY=0;Log("EDGE",edge,500,0,0);InvalidateRect(w,0,FALSE);break;
   case FOLLOWON:case FOLLOWOFF:follow=a==FOLLOWON;Log("FOLLOW",follow,0,0,0);InvalidateRect(w,0,FALSE);break;
   case QUIT:PostMessage(w,WM_CLOSE,0,0L);break;
  }return 0;
 case WM_PAINT:
  dc=BeginPaint(w,&ps);TextOut(dc,4,4,"PRIVATE 640x256 / 320x200",26);TextOut(dc,4,20,"Ctrl+Alt+arrows: X8 Y4",22);TextOut(dc,4,36,"Home reset; H hardware; Q exit",29);TextOut(dc,4,52,"E edges 500ms; F dialog follow",29);
  wsprintf(line,"X%d Y%d  HW%d  Edge%d Follow%d Live%d",left,top,hardware,edge,follow,live);TextOut(dc,4,72,line,lstrlen(line));EndPaint(w,&ps);return 0;
 case WM_CLOSE:
  Stop();DestroyWindow(w);return 0;
 case WM_ENDSESSION:if(a)Stop();return 0;
 case WM_DESTROY:Stop();PostQuitMessage(0);return 0;
 }return DefWindowProc(w,msg,a,b);
}
int PASCAL WinMain(HINSTANCE instance,HINSTANCE previous,LPSTR command,int show) {
 WNDCLASS wc;FARPROC thunk;MSG msg;HINSTANCE driver;int value;
 display=GetDC(0);if(!display)return 1;driver=GetModuleHandle("DISPLAY");statsProc=(STATS)GetProcAddress(driver,(LPSTR)106L);
 if(GetDeviceCaps(display,HORZRES)!=640 || GetDeviceCaps(display,VERTRES)!=256 || !Query()){ReleaseDC(0,display);return 1;}
 value=0;live=Escape(display,ESC_MODE,2,(LPSTR)&value,0)>0;if(!live){ReleaseDC(0,display);return 1;}Query();
 logFile=_lcreat("XYCTL.LOG",0);Log("START",left,top,hardware,0);
 memset(&wc,0,sizeof(wc));thunk=MakeProcInstance((FARPROC)Wnd,instance);wc.lpfnWndProc=(WNDPROC)thunk;wc.hInstance=instance;wc.hCursor=LoadCursor(0,IDC_ARROW);wc.hbrBackground=(HBRUSH)(COLOR_WINDOW+1);wc.lpszClassName="XYControl";RegisterClass(&wc);
 window=CreateWindow("XYControl","XY control PRIVATE",WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX,12,12,288,132,0,Menu(),instance,0);
 if(!window){Cleanup();goto done;}ShowWindow(window,show);UpdateWindow(window);
 while(GetMessage(&msg,0,0,0)){TranslateMessage(&msg);DispatchMessage(&msg);}
done:
 if(logFile!=HFILE_ERROR)_lclose(logFile);FreeProcInstance(thunk);UnregisterClass("XYControl",instance);ReleaseDC(0,display);return 0;
}
