#define WINVER 0x0300
#include <windows.h>
#include <string.h>
#define ESC_XY 0x5860
#define ESC_MODE 0x5861
typedef int (FAR PASCAL *ROWS)(LPSTR,unsigned,unsigned);
typedef int (FAR PASCAL *STATS)(unsigned FAR *);
static HWND mainWnd;
static HCURSOR cursor,active;
static HFILE logFile;
static ROWS rowsProc;
static STATS statsProc;
static char buffer[3840],line[240];
static int failures,run;
static unsigned stats[8];
static int pan[6];
static void Log(LPSTR s) { _lwrite(logFile,s,lstrlen(s));_lclose(logFile);logFile=_lopen("C:\\XY.LOG",OF_WRITE);_llseek(logFile,0L,2); }
static void Check(LPSTR s,int ok) {
 wsprintf(line,"CHECK %s=%d\r\n",s,ok!=0);Log(line);if(!ok)failures++;
}
static void Pump(DWORD ms) {
 DWORD start;MSG msg;start=GetTickCount();
 while((DWORD)(GetTickCount()-start)<ms)while(PeekMessage(&msg,0,0,0,PM_REMOVE)){TranslateMessage(&msg);DispatchMessage(&msg);}
}
static void Pan(int x,int y) {
 HDC dc;int in[2];dc=GetDC(0);in[0]=x;in[1]=y;
 Check("ESC_XY",Escape(dc,ESC_XY,4,(LPSTR)in,(LPSTR)pan)>0);ReleaseDC(0,dc);
}
static void Mode(int m) {HDC dc;dc=GetDC(0);Check("ESC_MODE",Escape(dc,ESC_MODE,2,(LPSTR)&m,0)>0);ReleaseDC(0,dc);}
static COLORREF Color(int k) {int r,g,b;r=(k&4)?170:0;g=(k&2)?170:0;b=(k&1)?170:0;if(k&8){r+=85;g+=85;b+=85;}return RGB(r,g,b);}
static void Pattern(HDC dc) {
 int x,y;RECT r;HBRUSH b;
 for(y=0;y<256;y+=32)for(x=0;x<640;x+=80){
  r.left=x;r.top=y;r.right=x+80;r.bottom=y+32;
  b=CreateSolidBrush(GetNearestColor(dc,Color((x/80+2*(y/32))&15)));FillRect(dc,&r,b);DeleteObject(b);
 }
 TextOut(dc,4,190,"BAND 199/200",12);TextOut(dc,340,234,"LOWER RIGHT",11);
}
static void Snap(int id,int visible,int x,int y) {
 HFILE f;char name[24];unsigned first,count,n,off;char FAR *video;POINT point;
 active=visible?cursor:(HCURSOR)0;SetCursorPos(x,y);SetCursor(active);Pump(150);SetCursor(active);
 GetCursorPos(&point);x=point.x;y=point.y;Pan(-1,0);statsProc(stats);
 wsprintf(name,"C:\\S%03d.BIN",id);f=_lcreat(name,0);Check("SHADOW_FILE",f!=HFILE_ERROR);
 if(f!=HFILE_ERROR){for(first=0;first<256;first+=12){count=256-first;if(count>12)count=12;n=rowsProc(buffer,first,count);Check("ROWS_BYTES",n==count*320);Check("ROWS_WRITE",_lwrite(f,buffer,n)==n);}_lclose(f);}
 wsprintf(name,"C:\\V%03d.BIN",id);f=_lcreat(name,0);video=(char FAR *)MAKELONG(0,0xb800);
 if(f!=HFILE_ERROR){for(off=0;off<32768U;off+=8192U)_lwrite(f,video+off,8192);_lclose(f);}else Check("VIDEO_FILE",0);
 wsprintf(line,"STEP id=%d left=%d top=%d head=%u enabled=%u reason=%u hw=%u sw=%u bytes=%u cursor=%d x=%d y=%d\r\n",id,pan[0],pan[1],stats[2],stats[0],stats[3],stats[4],stats[5],stats[7],visible,x,y);Log(line);
 f=_lcreat("C:\\XYSTEP.TXT",0);_lwrite(f,line,lstrlen(line));_lclose(f);Pump(1200);
}
static void Raster(HDC dc) {
 int i;COLORREF want[8];HRGN clip;
 for(i=0;i<8;i++){want[i]=GetNearestColor(dc,Color(i+1));SetPixel(dc,50,196+i,want[i]);}
 for(i=0;i<8;i++)Check("PIXEL_BAND",GetPixel(dc,50,196+i)==want[i]);
 SetPixel(dc,639,255,Color(15));Check("PIXEL_LAST",GetPixel(dc,639,255)==GetNearestColor(dc,Color(15)));
 BitBlt(dc,50,198,1,8,dc,50,196,SRCCOPY);
 for(i=0;i<8;i++)Check("BLT_BACKWARD_BAND",GetPixel(dc,50,198+i)==want[i]);
 BitBlt(dc,50,194,1,8,dc,50,198,SRCCOPY);
 for(i=0;i<8;i++)Check("BLT_FORWARD_BAND",GetPixel(dc,50,194+i)==want[i]);
 clip=CreateRectRgn(300,196,380,206);SelectClipRgn(dc,clip);
 PatBlt(dc,280,190,120,30,WHITENESS);TextOut(dc,300,198,"TEXT CROSS",10);
 SelectClipRgn(dc,0);DeleteObject(clip);
 Check("CLIP_OUTSIDE",GetPixel(dc,299,196)!=GetNearestColor(dc,Color(15)));
 Check("CHUNK_REJECT",rowsProc(buffer,255,2)==0 && rowsProc(buffer,0,13)==0);
}
long FAR PASCAL Wnd(HWND w,UINT m,WPARAM a,LPARAM b) {
 PAINTSTRUCT ps;HDC dc;
 if(m==WM_SETCURSOR){SetCursor(active);return 1;}
 if(m==WM_PAINT){dc=BeginPaint(w,&ps);Pattern(dc);EndPaint(w,&ps);return 0;}
 return DefWindowProc(w,m,a,b);
}
int PASCAL WinMain(HINSTANCE instance,HINSTANCE previous,LPSTR command,int show) {
 HINSTANCE display;WNDCLASS wc;FARPROC thunk;HDC dc;HFILE f;int x,y,i;unsigned char am[64],xm[64];DWORD a,b;
 f=_lopen("C:\\XYRUN.TXT",OF_READ);run=f==HFILE_ERROR?1:2;if(f!=HFILE_ERROR)_lclose(f);
 if(run==1){f=_lcreat("C:\\XYRUN.TXT",0);_lwrite(f,"1",1);_lclose(f);logFile=_lcreat("C:\\XY.LOG",0);}else{logFile=_lopen("C:\\XY.LOG",OF_WRITE);_llseek(logFile,0L,2);}
 wsprintf(line,"START run=%d free=%lu largest=%lu\r\n",run,GetFreeSpace(0),GlobalCompact(0L));Log(line);
 Check("GEOMETRY",GetSystemMetrics(0)==640 && GetSystemMetrics(1)==256);
 display=GetModuleHandle("DISPLAY");rowsProc=(ROWS)GetProcAddress(display,(LPSTR)108L);statsProc=(STATS)GetProcAddress(display,(LPSTR)106L);
 Check("EXPORTS",rowsProc!=0 && statsProc!=0);if(!rowsProc || !statsProc)goto done;
 Pan(-1,0);Check("INITIAL",pan[0]==0 && pan[1]==0 && pan[4]==640 && pan[5]==256);statsProc(stats);Check("DEFAULT_SOFTWARE",stats[0]==0);
 memset(&wc,0,sizeof(wc));thunk=MakeProcInstance((FARPROC)Wnd,instance);wc.lpfnWndProc=(WNDPROC)thunk;wc.hInstance=instance;wc.lpszClassName="XYQA";wc.hbrBackground=(HBRUSH)(COLOR_WINDOW+1);RegisterClass(&wc);
 memset(am,255,sizeof(am));memset(xm,0,sizeof(xm));for(i=0;i<8;i++){am[i*4]=0;xm[i*4]=(unsigned char)(0x80>>i);}
 cursor=CreateCursor(instance,0,0,32,16,am,xm);active=0;
 mainWnd=CreateWindow("XYQA","PRIVATE XY segmentation proof",WS_POPUP,0,0,640,256,0,0,instance,0);Check("WINDOW",mainWnd!=0);ShowWindow(mainWnd,SW_SHOW);UpdateWindow(mainWnd);SetCursor(0);
 dc=GetDC(mainWnd);Raster(dc);ReleaseDC(mainWnd,dc);Snap(run==1?0:900,0,400,120);
 Mode(1);
 a=GetTickCount();for(y=4;y<=56;y+=4)Pan(0,y);b=GetTickCount();wsprintf(line,"COST vertical14=%lu\r\n",b-a);Log(line);Snap(run==1?1:901,0,400,120);
 if(run==1){
  a=GetTickCount();for(x=8;x<=320;x+=8)Pan(x,56);b=GetTickCount();wsprintf(line,"COST horizontal40=%lu\r\n",b-a);Log(line);Snap(2,0,500,180);
  for(i=1;i<=14;i++)Pan(320-i*8,56-i*4);Snap(3,1,pan[0]+316,pan[1]+197);
  Pan(0,56);for(i=1;i<=14;i++)Pan(i*8,56-i*4);Snap(4,1,pan[0]-2,pan[1]-2);
  Pan(320,56);Snap(5,1,639,255);Pan(312,52);Snap(6,0,500,100);
  Mode(2);Pan(304,48);Snap(7,0,500,100);Check("FAULT_SOFTWARE",stats[0]==0 && stats[3]==4 && stats[2]==0);
  Pan(0,0);Snap(8,0,50,50);
 }
 SetCursor(0);Mode(0);Pan(0,0);DestroyWindow(mainWnd);DestroyCursor(cursor);UnregisterClass("XYQA",instance);FreeProcInstance(thunk);
done:
 wsprintf(line,"END run=%d FAILURES=%d free=%lu largest=%lu\r\n",run,failures,GetFreeSpace(0),GlobalCompact(0L));Log(line);_lclose(logFile);ExitWindows(0,0);return 0;
}
