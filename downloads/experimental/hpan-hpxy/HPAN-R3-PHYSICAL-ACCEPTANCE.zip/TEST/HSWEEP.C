#define WINVER 0x0300
#include <windows.h>
#include <string.h>

#define IDM_HW         105
#define IDM_EDGE_ON    106
#define IDM_EDGE_OFF   107
#define TRACE_WINDOW   "HPANControl"
#define VIEW_WIDTH     320
#define TIMER_ID       1
#define TIMER_MS       100
#define HOLD_MS        3500
#define CASE_COUNT     7
#define WM_SET_PAN_DIAG (WM_USER + 40)

typedef struct {
    int left;
    int x;
    int y;
    int minimize;
    char *name;
} SWEEPCASE;

static SWEEPCASE g_cases[CASE_COUNT] = {
    { 160, 160,  90, 0, "L160 y90 normal" },
    { 160, 160, 180, 0, "L160 y180 normal" },
    { 160, 319, 180, 0, "L160 x319 screen edge" },
    { 160, 478, 180, 0, "L160 x478 before logical edge" },
    { 160, 479, 180, 0, "L160 x479 logical edge" },
    { 160, 480, 180, 0, "L160 x480 past logical edge" },
    { 160, 160,  90, 1, "L160 y90 minimized" }
};

static HWND g_window;
static HWND g_helper;
static HFILE g_log = HFILE_ERROR;
static int g_case;
static int g_phase;
static DWORD g_started;
static int g_helperReady;
static int g_cursorSet;
static int g_waitTicks;
static int g_finished;
static char g_caption[96];

static void WriteLine(char *line)
{
    int count;

    if (g_log == HFILE_ERROR)
        return;
    count = (int)lstrlen(line);
    _lwrite(g_log, line, (UINT)count);
}

static int QueryLeft(void)
{
    HDC dc;
    int input;
    int output[3];
    int result;

    dc = GetDC((HWND)0);
    if (!dc)
        return -1;
    input = 0xffff;
    output[0] = -1;
    output[1] = 0;
    output[2] = 0;
    result = Escape(dc, 0x5858, sizeof(int), (LPSTR)&input,
                    (LPSTR)output);
    ReleaseDC((HWND)0, dc);
    if (result <= 0 || output[0] < 0 || output[0] > 320 ||
        output[1] != VIEW_WIDTH || output[2] != 640)
        return -1;
    return output[0];
}

static int SetLogicalLeft(HWND helper, int left)
{
    if (left < 0)
        left = 0;
    if (left > 320)
        left = 320;
    return (int)SendMessage(helper, WM_SET_PAN_DIAG, left, 0L);
}

static void FinishSweep(HWND window)
{
    if (g_finished)
        return;
    g_finished = TRUE;
    KillTimer(window, TIMER_ID);
    if (g_helper && IsWindow(g_helper))
        SendMessage(g_helper, WM_CLOSE, 0, 0L);
    WriteLine("FINISH helper closed; trace flushed; exiting Windows.\r\n");
    if (g_log != HFILE_ERROR) {
        _lclose(g_log);
        g_log = HFILE_ERROR;
    }
    ExitWindows(0, 0);
}

static void BeginCase(void)
{
    SWEEPCASE *test;
    RECT rect;
    POINT point;
    char line[220];
    int left;
    int setResult;
    int screenWidth;
    int screenHeight;

    if (!g_helper || !IsWindow(g_helper)) {
        WriteLine("FAIL helper disappeared\r\n");
        g_phase = 3;
        return;
    }
    test = &g_cases[g_case];
    ShowWindow(g_helper, test->minimize ? SW_MINIMIZE : SW_RESTORE);
    SendMessage(g_helper, WM_COMMAND, IDM_EDGE_OFF, 0L);
    setResult = SetLogicalLeft(g_helper, test->left);
    left = QueryLeft();
    if (test->minimize)
        ShowWindow(g_helper, SW_MINIMIZE);
    SetCursorPos(test->x, test->y);
    GetCursorPos(&point);
    g_cursorSet = point.x == test->x && point.y == test->y;
    GetWindowRect(g_helper, &rect);
    screenWidth = GetSystemMetrics(0);
    screenHeight = GetSystemMetrics(1);
    wsprintf(line,
             "BEGIN case=%d name=%s screen=%d,%d wantLeft=%d gotLeft=%d wantXY=%d,%d gotXY=%d,%d helper=%d,%d,%d,%d minimized=%d cursorMatch=%d\r\n",
             g_case, (LPSTR)test->name, screenWidth, screenHeight,
             test->left, left, test->x, test->y, point.x, point.y,
             rect.left, rect.top, rect.right, rect.bottom,
             test->minimize, g_cursorSet);
    WriteLine(line);
    if (!setResult || left != test->left || point.x != test->x ||
        point.y != test->y ||
        screenWidth != 640 || screenHeight != 200 || !g_cursorSet) {
        WriteLine("FAIL setup not achieved; case not run.\r\n");
        g_phase = 3;
        return;
    }
    SendMessage(g_helper, WM_COMMAND, IDM_EDGE_ON, 0L);
    g_started = GetTickCount();
    g_phase = 1;
    wsprintf(g_caption, "Edge trace: case %d/%d %s", g_case + 1,
             CASE_COUNT, (LPSTR)test->name);
    SetWindowText(g_window, g_caption);
}

static void EndCase(void)
{
    SWEEPCASE *test;
    char line[128];
    int finalLeft;
    POINT point;
    DWORD elapsed;

    test = &g_cases[g_case];
    SendMessage(g_helper, WM_COMMAND, IDM_EDGE_OFF, 0L);
    GetCursorPos(&point);
    finalLeft = QueryLeft();
    elapsed = GetTickCount() - g_started;
    wsprintf(line,
             "END case=%d finalLeft=%d finalXY=%d,%d elapsed=%lu\r\n",
             g_case, finalLeft, point.x, point.y, elapsed);
    WriteLine(line);
    g_case++;
    if (g_case >= CASE_COUNT) {
        WriteLine("DONE; all edge cases collected.\r\n");
        g_phase = 3;
        SetWindowText(g_window, "Edge trace cases complete");
    } else {
        g_phase = 2;
        g_started = GetTickCount();
    }
}

long FAR PASCAL Wnd(HWND window, UINT message, WPARAM wParam,
                    LPARAM lParam)
{
    PAINTSTRUCT paint;
    HDC dc;

    switch (message) {
    case WM_CREATE:
        g_window = window;
        SetTimer(window, TIMER_ID, TIMER_MS, (FARPROC)0);
        return 0L;
    case WM_TIMER:
        if (g_phase == 3) {
            FinishSweep(window);
            return 0L;
        }
        if (!g_helperReady) {
            g_helper = FindWindow(TRACE_WINDOW, (LPSTR)0);
            if (g_helper) {
                g_helperReady = TRUE;
                WriteLine("READY SetCursorPos USER-coordinate fixture; not physical-mouse input.\r\n");
                SendMessage(g_helper, WM_COMMAND, IDM_HW, 0L);
                WriteLine("Requested hardware refill once for bounded pan setup.\r\n");
                g_phase = 0;
            } else {
                g_waitTicks++;
                if (g_waitTicks >= 100) {
                    WriteLine("FAIL HPANControl was not found after 10 seconds.\r\n");
                    g_phase = 3;
                }
            }
            return 0L;
        }
        if (g_phase == 0)
            BeginCase();
        else if (g_phase == 1 &&
                 (DWORD)(GetTickCount() - g_started) >= HOLD_MS)
            EndCase();
        else if (g_phase == 2 &&
                 (DWORD)(GetTickCount() - g_started) >= 300)
            g_phase = 0;
        else if (g_phase == 3)
            FinishSweep(window);
        return 0L;
    case WM_PAINT:
    {
        char *text;

        dc = BeginPaint(window, &paint);
        text = "Automates SetCursorPos cases; see HSWEEP.LOG";
        TextOut(dc, 8, 8, text, (int)lstrlen(text));
        text = "HCTL trace is written on close to HEDGE.LOG.";
        TextOut(dc, 8, 28, text, (int)lstrlen(text));
        EndPaint(window, &paint);
        return 0L;
    }
    case WM_CLOSE:
        KillTimer(window, TIMER_ID);
        if (g_log != HFILE_ERROR) {
            _lclose(g_log);
            g_log = HFILE_ERROR;
        }
        DestroyWindow(window);
        return 0L;
    case WM_DESTROY:
        PostQuitMessage(0);
        return 0L;
    }
    return DefWindowProc(window, message, wParam, lParam);
}

int PASCAL WinMain(HINSTANCE instance, HINSTANCE previous,
                   LPSTR commandLine, int showCommand)
{
    WNDCLASS windowClass;
    HWND window;
    MSG message;
    FARPROC thunk;
    UINT launchResult;

    previous = previous;
    commandLine = commandLine;
    memset(&windowClass, 0, sizeof(windowClass));
    g_log = _lcreat("HSWEEP.LOG", 0);
    WriteLine("HSWEEP start; cursor coordinates are USER injected.\r\n");
    if (GetSystemMetrics(0) != 640 || GetSystemMetrics(1) != 200) {
        WriteLine("FAIL fixture requires a 640x200 screen.\r\n");
        if (g_log != HFILE_ERROR)
            _lclose(g_log);
        return 0;
    }
    thunk = MakeProcInstance((FARPROC)Wnd, instance);
    if (!thunk) {
        if (g_log != HFILE_ERROR)
            _lclose(g_log);
        return 0;
    }
    windowClass.lpfnWndProc = (WNDPROC)thunk;
    windowClass.hInstance = instance;
    windowClass.hIcon = LoadIcon((HINSTANCE)0, IDI_APPLICATION);
    windowClass.hCursor = LoadCursor((HINSTANCE)0, IDC_ARROW);
    windowClass.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    windowClass.lpszClassName = "HSweepTrace";
    if (!RegisterClass(&windowClass)) {
        FreeProcInstance(thunk);
        if (g_log != HFILE_ERROR)
            _lclose(g_log);
        return 0;
    }
    window = CreateWindow("HSweepTrace", "Edge sweep fixture",
                          WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU,
                          340, 12, 260, 110,
                          (HWND)0, (HMENU)0, instance, (LPSTR)0);
    if (!window) {
        UnregisterClass("HSweepTrace", instance);
        FreeProcInstance(thunk);
        if (g_log != HFILE_ERROR)
            _lclose(g_log);
        return 0;
    }
    ShowWindow(window, showCommand);
    UpdateWindow(window);
    launchResult = WinExec("HTRC.EXE", SW_SHOW);
    if (launchResult <= 31) {
        WriteLine("FAIL WinExec HTRC.EXE failed; fixture stopped.\r\n");
        if (g_log != HFILE_ERROR) {
            _lclose(g_log);
            g_log = HFILE_ERROR;
        }
        KillTimer(window, TIMER_ID);
        DestroyWindow(window);
        UnregisterClass("HSweepTrace", instance);
        FreeProcInstance(thunk);
        return 1;
    }
    while (GetMessage(&message, (HWND)0, 0, 0)) {
        TranslateMessage(&message);
        DispatchMessage(&message);
    }
    UnregisterClass("HSweepTrace", instance);
    FreeProcInstance(thunk);
    return (int)message.wParam;
}
