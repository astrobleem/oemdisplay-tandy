from pathlib import Path
import sys,importlib.machinery,shutil,json,hashlib
from lease import lease,hidden,DOSBOX
W=Path(__file__).resolve().parent
sys.path.insert(0,str(W/'build-view/src/tandysw'))
P=W/'sweep-source/experiments/HPAN'
patcher=importlib.machinery.SourceFileLoader('hpatch',str(P/'HPATCH.PY')).load_module()
b=importlib.machinery.SourceFileLoader('hbuild',str(W/'build-view/src/tandysw/BUILD88.PY')).load_module()
prepare,run=b.baseline.prepare,b.bounded_run;state={}
def prep(repo,out):
    r,s=prepare(repo,out);state.update(renderer=r,resources=s);return r,s
def do(*a,**kw):
    if not state.get('patched'):
        patcher.patch(state['renderer']);state['patched']=True
    return run(*a,**kw)
b.baseline.prepare,b.bounded_run=prep,do
tag=sys.argv[1] if len(sys.argv)>1 else 'BUILD5'
hidden();sys.argv=['BUILD88.PY','--repo',str(W/'build-view'),'--dosbox',str(DOSBOX),'--out',str(W/tag),'--mode','320x200x16','--ui-profile','compact320']
with lease(W/(tag+'-LEASE.json')):b.main()
shutil.copyfile(W/tag/'TANDY88.DRV',W/tag/'HPAN.DRV')
rpath=W/tag/'RESULT.json';report=json.loads(rpath.read_text())
report.update(candidate='HPAN horizontal 640x200 logical /320x200 viewport PRIVATE',logical=[640,200,16],physical=[320,200,16],shadow_bytes=64000,hpan_patch='Applied AFTER baseline transforms; baseline audit descriptions do not prove preservation of replaced flush routines')
rpath.write_text(json.dumps(report,indent=2))
(W/tag/'HORIZONTAL.json').write_text(json.dumps(dict(logical=[640,200,16],viewport=[320,200,16],shadow_bytes=64000,max_offset=320,step=8,max_bank_offset=8159,hardware_default=False,hardware_tested=False,hardware_method='Exact8 preconversion into private800B; guarded commit and CRTC; other sizes retain R2',software_fallback=True,sha256=hashlib.sha256((W/tag/'HPAN.DRV').read_bytes()).hexdigest()),indent=2))
