#define WINVER 0x0300
#include <windows.h>
#include <string.h>

#define ESC_HPAN       0x5858
#define ESC_HMODE      0x5859
#define TIMER_ID       1
#define VIEW_WIDTH     320
#define PAN_MAX        320
#define STEP_LIMIT     8
#define STALL_LIMIT    8000L
#define LEG_LIMIT      45000L
#define IDM_LEFT       101
#define IDM_RIGHT      102
#define IDM_HOME       103
#define IDM_HW         105
#define IDM_EDGE_ON    106
#define IDM_EDGE_OFF   107

typedef int (FAR PASCAL *HPSTATS)(unsigned FAR *);
typedef int (FAR PASCAL *HPSHADOW)(void FAR *);

static HWND g_main;
static HWND g_helper;
static HINSTANCE g_instance;
static HCURSOR g_cursor;
static HCURSOR g_active;
static FARPROC g_wndThunk;
static HPSTATS g_statsProc;
static HPSHADOW g_shadowProc;
static HFILE g_log = HFILE_ERROR;
static unsigned g_stats[8];
static int g_run;
static int g_failures;
static int g_markerSerial;
static char g_line[240];

static void LogLine(char *text)
{
    if (g_log != HFILE_ERROR)
        _lwrite(g_log, text, (UINT)lstrlen(text));
}

static void Check(char *name, int passed)
{
    wsprintf(g_line, "CHECK run=%d %s=%d\r\n", g_run,
             (LPSTR)name, passed != 0);
    LogLine(g_line);
    if (!passed)
        g_failures++;
}

static void PumpFor(DWORD milliseconds)
{
    DWORD started;
    MSG message;

    started = GetTickCount();
    while ((DWORD)(GetTickCount() - started) < milliseconds) {
        while (PeekMessage(&message, (HWND)0, 0, 0, PM_REMOVE)) {
            TranslateMessage(&message);
            DispatchMessage(&message);
        }
    }
}

static int ReadStats(void)
{
    int i;

    if (!g_statsProc)
        return FALSE;
    for (i = 0; i < 8; i++)
        g_stats[i] = 0;
    g_statsProc(g_stats);
    return TRUE;
}

static int ReadPan(void)
{
    HDC dc;
    int input;
    int output[3];
    int result;

    dc = GetDC((HWND)0);
    if (!dc)
        return -1;
    input = -1;
    output[0] = -1;
    output[1] = 0;
    output[2] = 0;
    result = Escape(dc, ESC_HPAN, sizeof(int), (LPSTR)&input,
                    (LPSTR)output);
    ReleaseDC((HWND)0, dc);
    if (result <= 0 || output[0] < 0 || output[0] > PAN_MAX ||
        (output[0] & 7) != 0 || output[1] != VIEW_WIDTH ||
        output[2] != 640)
        return -1;
    return output[0];
}

static int SetMode(int mode)
{
    HDC dc;
    int input;
    int result;

    dc = GetDC((HWND)0);
    if (!dc)
        return FALSE;
    input = mode;
    result = Escape(dc, ESC_HMODE, sizeof(int), (LPSTR)&input,
                    (LPSTR)0);
    ReleaseDC((HWND)0, dc);
    return result > 0;
}

static int SendCommand(UINT command)
{
    if (!g_helper || !IsWindow(g_helper))
        return FALSE;
    SendMessage(g_helper, WM_COMMAND, command, 0L);
    return TRUE;
}

static int MoveByMenu(int direction, int count)
{
    int i;
    int before;
    int after;
    UINT command;

    command = direction > 0 ? IDM_RIGHT : IDM_LEFT;
    for (i = 0; i < count; i++) {
        before = ReadPan();
        if (before < 0 || !SendCommand(command))
            return FALSE;
        after = ReadPan();
        if (after != before + direction * STEP_LIMIT) {
            wsprintf(g_line,
                     "FAIL menu-step i=%d dir=%d before=%d after=%d\r\n",
                     i, direction, before, after);
            LogLine(g_line);
            g_failures++;
            return FALSE;
        }
        PumpFor(20);
    }
    return TRUE;
}

static COLORREF PaletteColor(int index)
{
    int red;
    int green;
    int blue;

    red = (index & 4) ? 170 : 0;
    green = (index & 2) ? 170 : 0;
    blue = (index & 1) ? 170 : 0;
    if (index & 8) {
        red += 85;
        green += 85;
        blue += 85;
    }
    return RGB(red, green, blue);
}

static void FillPattern(HDC dc, int x, int y, int width, int height,
                        int index)
{
    RECT rectangle;
    HBRUSH brush;

    rectangle.left = x;
    rectangle.top = y;
    rectangle.right = x + width;
    rectangle.bottom = y + height;
    brush = CreateSolidBrush(GetNearestColor(dc, PaletteColor(index & 15)));
    if (brush) {
        FillRect(dc, &rectangle, brush);
        DeleteObject(brush);
    }
}

static void PaintPattern(HDC dc)
{
    int x;
    int y;

    for (y = 0; y < 200; y += 20) {
        for (x = 0; x < 640; x += 40)
            FillPattern(dc, x, y, 40, 20, ((x / 40) ^ (y / 20)) & 15);
    }
    TextOut(dc, 2, 30, "LEFT x0", 7);
    TextOut(dc, 324, 65, "RIGHT x320", 10);
    TextOut(dc, 520, 170, "EDGE x640", 9);
}

static void SetTestCursor(int visible, int x, int y)
{
    g_active = visible ? g_cursor : (HCURSOR)0;
    SetCursorPos(x, y);
    SetCursor(g_active);
}

static void Snapshot(int id, int cursorVisible)
{
    HGLOBAL memory;
    LPSTR shadow;
    HFILE file;
    char name[24];
    char FAR *video;
    unsigned offset;
    POINT point;
    int left;

    if (g_helper && IsWindow(g_helper))
        SendMessage(g_helper, WM_COMMAND, IDM_EDGE_OFF, 0L);
    PumpFor(300);
    SetCursor(g_active);
    GetCursorPos(&point);
    ReadStats();
    left = ReadPan();
    memory = GlobalAlloc(GMEM_MOVEABLE, 64000L);
    Check("SNAP_ALLOC", memory != (HGLOBAL)0);
    if (!memory)
        return;
    shadow = (LPSTR)GlobalLock(memory);
    if (!shadow) {
        GlobalFree(memory);
        Check("SNAP_LOCK", FALSE);
        return;
    }
    Check("SHADOW_READ", g_shadowProc && g_shadowProc(shadow));
    wsprintf(name, "C:\\S%03d.BIN", id);
    file = _lcreat(name, 0);
    if (file != HFILE_ERROR) {
        _lwrite(file, shadow, 64000U);
        _lclose(file);
    } else {
        Check("SHADOW_FILE", FALSE);
    }
    GlobalUnlock(memory);
    GlobalFree(memory);

    video = (char FAR *)MAKELONG(0, 0xb800);
    wsprintf(name, "C:\\V%03d.BIN", id);
    file = _lcreat(name, 0);
    if (file != HFILE_ERROR) {
        for (offset = 0; offset < 32768U; offset += 8192U)
            _lwrite(file, video + offset, 8192);
        _lclose(file);
    } else {
        Check("VIDEO_FILE", FALSE);
    }

    wsprintf(g_line,
             "STEP id=%d left=%d head=%u enabled=%u reason=%u hw=%u sw=%u cols=%u bytes=%u cursor=%d x=%d y=%d\r\n",
             id, left, g_stats[2], g_stats[0], g_stats[3], g_stats[4],
             g_stats[5], g_stats[6], g_stats[7], cursorVisible,
             point.x, point.y);
    LogLine(g_line);
    file = _lcreat("C:\\HPSTEP.TXT", 0);
    if (file != HFILE_ERROR) {
        _lwrite(file, g_line, (UINT)lstrlen(g_line));
        _lclose(file);
    } else {
        Check("STEP_MARKER", FALSE);
    }
    g_markerSerial++;
    PumpFor(1600);
}

static void LogPanSample(char *leg, int left, int expectedDirection,
                         DWORD elapsed)
{
    POINT point;

    GetCursorPos(&point);
    wsprintf(g_line, "OBS %s left=%d dir=%d tick=%lu xy=%d,%d\r\n",
             (LPSTR)leg, left, expectedDirection, elapsed, point.x, point.y);
    LogLine(g_line);
}

static int RunEdgeLeg(char *name, int start, int target, int direction,
                      int cursorX, int cursorY, int snapshotId)
{
    DWORD legStarted;
    DWORD lastProgress;
    int previous;
    int current;
    int delta;
    int reached;

    previous = ReadPan();
    wsprintf(g_line, "LEG %s start=%d target=%d dir=%d got=%d xy=%d,%d\r\n",
             (LPSTR)name, start, target, direction, previous,
             cursorX, cursorY);
    LogLine(g_line);
    if (previous != start) {
        Check("LEG_START", FALSE);
        return FALSE;
    }
    SetCursor(NULL);
    SetCursorPos(cursorX, cursorY);
    SendCommand(IDM_EDGE_ON);
    legStarted = GetTickCount();
    lastProgress = legStarted;
    reached = FALSE;
    while ((DWORD)(GetTickCount() - legStarted) < LEG_LIMIT) {
        PumpFor(50);
        current = ReadPan();
        if (current < 0) {
            Check("LEG_QUERY", FALSE);
            break;
        }
        if (current != previous) {
            delta = current - previous;
            if (delta != direction * STEP_LIMIT) {
                wsprintf(g_line,
                         "FAIL LEG_STEP name=%s before=%d after=%d dir=%d\r\n",
                         (LPSTR)name, previous, current, direction);
                LogLine(g_line);
                g_failures++;
                break;
            }
            previous = current;
            lastProgress = GetTickCount();
            LogPanSample(name, current, direction,
                         (DWORD)(lastProgress - legStarted));
            if (current == target) {
                reached = TRUE;
                break;
            }
            if ((direction > 0 && current > target) ||
                (direction < 0 && current < target)) {
                Check("LEG_NO_OVERSHOOT", FALSE);
                break;
            }
        }
        if ((DWORD)(GetTickCount() - lastProgress) >= STALL_LIMIT) {
            wsprintf(g_line, "FAIL LEG_STALL name=%s left=%d ms=%lu\r\n",
                     (LPSTR)name, current,
                     (DWORD)(GetTickCount() - lastProgress));
            LogLine(g_line);
            g_failures++;
            break;
        }
    }
    if (!reached && (DWORD)(GetTickCount() - legStarted) >= LEG_LIMIT) {
        wsprintf(g_line, "FAIL LEG_TIMEOUT name=%s left=%d ms=%lu\r\n",
                 (LPSTR)name, ReadPan(),
                 (DWORD)(GetTickCount() - legStarted));
        LogLine(g_line);
        g_failures++;
    }
    SendCommand(IDM_EDGE_OFF);
    PumpFor(300);
    SetTestCursor(FALSE, 500, 180);
    Snapshot(snapshotId, FALSE);
    wsprintf(g_line, "LEGEND %s reached=%d left=%d\r\n",
             (LPSTR)name, reached, ReadPan());
    LogLine(g_line);
    return reached;
}

static int StartHelper(void)
{
    DWORD started;
    int launchResult;

    launchResult = WinExec("HCTL.EXE", SW_SHOW);
    Check("HELPER_EXEC", launchResult > 31);
    if (launchResult <= 31)
        return FALSE;
    started = GetTickCount();
    g_helper = (HWND)0;
    while ((DWORD)(GetTickCount() - started) < 10000L) {
        PumpFor(100);
        g_helper = FindWindow("HPANControl", (LPSTR)0);
        if (g_helper)
            break;
    }
    Check("HELPER_WINDOW", g_helper != (HWND)0);
    return g_helper != (HWND)0;
}

static int VerifyStartup(void)
{
    int left;
    int good;

    good = ReadStats();
    left = ReadPan();
    good = good && left == 0 && g_stats[0] == 0 &&
           g_stats[1] == 0 && g_stats[2] == 0;
    Check("INITIAL_DRIVER_OFF_HOME", good);
    return good;
}

static int SetupHardwareAndLeft(int left)
{
    int steps;
    int good;

    if (!SendCommand(IDM_EDGE_OFF))
        return FALSE;
    good = SendCommand(IDM_HW);
    PumpFor(250);
    ReadStats();
    Check("HARDWARE_MODE", good && g_stats[0] == 1);
    if (!good || g_stats[0] != 1)
        return FALSE;
    if (!SendCommand(IDM_HOME))
        return FALSE;
    steps = left / STEP_LIMIT;
    good = MoveByMenu(1, steps);
    Check("MENU_POSITION", good && ReadPan() == left);
    return good && ReadPan() == left;
}

static int SetupSoftwareLeft(int left)
{
    int steps;
    int good;

    if (!SendCommand(IDM_EDGE_OFF) || !SendCommand(IDM_HOME))
        return FALSE;
    steps = left / STEP_LIMIT;
    good = MoveByMenu(1, steps);
    Check("SOFTWARE_POSITION", good && ReadPan() == left);
    return good && ReadPan() == left;
}

static void DirtyOperations(void)
{
    HDC dc;

    dc = GetDC(g_main);
    if (!dc) {
        Check("DIRTY_DC", FALSE);
        return;
    }
    FillPattern(dc, 315, 58, 20, 20, 15);
    PatBlt(dc, 318, 61, 28, 21, DSTINVERT);
    TextOut(dc, 318, 84, "EDGE TEXT", 9);
    BitBlt(dc, 550, 110, 88, 38, dc, 310, 58, SRCCOPY);
    BitBlt(dc, 318, 120, 120, 40, dc, 326, 115, SRCINVERT);
    ReleaseDC(g_main, dc);
    Check("DIRTY_OPS", TRUE);
}

static void CursorAndDirtySuite(void)
{
    int left;

    if (ReadPan() == 160) {
        Check("SET_VIEW320", MoveByMenu(1, 20) && ReadPan() == 320);
    } else {
        Check("SET_VIEW320", SetupHardwareAndLeft(320));
    }
    SendCommand(IDM_EDGE_OFF);
    SetTestCursor(TRUE, 320, 0);
    Snapshot(120, TRUE);
    SetTestCursor(TRUE, 639, 199);
    Snapshot(121, TRUE);
    SetTestCursor(TRUE, 478, 99);
    Snapshot(122, TRUE);

    left = ReadPan();
    if (left == 320 && SendCommand(IDM_LEFT)) {
        PumpFor(300);
        Check("CURSOR_PAN_LEFT8", ReadPan() == 312);
        Snapshot(123, TRUE);
    } else {
        Check("CURSOR_PAN_LEFT8", FALSE);
    }
    if (ReadPan() == 312 && SendCommand(IDM_RIGHT)) {
        PumpFor(300);
        Check("CURSOR_PAN_RIGHT8", ReadPan() == 320);
        Snapshot(124, TRUE);
    } else {
        Check("CURSOR_PAN_RIGHT8", FALSE);
    }
    SetTestCursor(FALSE, 500, 180);
    DirtyOperations();
    Snapshot(125, FALSE);

    SetCursor(NULL);
    SetMode(2);
    SendCommand(IDM_LEFT);
    PumpFor(300);
    ReadStats();
    Check("FORCED_TIMEOUT_PAN_STEP", ReadPan() == 312);
    Check("FORCED_TIMEOUT_FALLBACK",
          g_stats[0] == 0 && g_stats[2] == 0 && g_stats[3] == 4 &&
          g_stats[7] == 32000);
    Snapshot(140, FALSE);
}

static void FirstRun(void)
{
    int current;
    int setup;

    Check("STARTUP_STATE", VerifyStartup());
    ReadStats();
    SetTestCursor(TRUE, 100, 90);
    Snapshot(100, TRUE);
    if (!StartHelper())
        return;

    setup = SetupHardwareAndLeft(0);
    Check("EDGE_HW_SETUP0", setup && ReadPan() == 0);
    if (setup) {
        SetCursor(NULL);
        RunEdgeLeg("full_out_y90", 0, 320, 1, 319, 90, 101);
        RunEdgeLeg("full_back_y90", 320, 0, -1, 320, 90, 102);
    }

    current = ReadPan();
    if (current >= 0) {
        SendCommand(IDM_HOME);
        PumpFor(100);
    }
    setup = SetupHardwareAndLeft(160);
    Check("EDGE_HW_SETUP160", setup && ReadPan() == 160);
    if (setup) {
        RunEdgeLeg("short_out_y180", 160, 224, 1, 479, 180, 103);
        RunEdgeLeg("short_back_y180", 224, 160, -1, 224, 180, 104);
        RunEdgeLeg("overshoot_out", 160, 176, 1, 639, 90, 105);
        RunEdgeLeg("overshoot_back", 176, 160, -1, 0, 90, 106);
    }

    CursorAndDirtySuite();
    if (g_helper && IsWindow(g_helper)) {
        SendMessage(g_helper, WM_CLOSE, 0, 0L);
        g_helper = (HWND)0;
        PumpFor(300);
        ReadStats();
        Check("HELPER_CLOSE_OFF_HOME",
              g_stats[0] == 0 && g_stats[2] == 0 && ReadPan() == 0);
    }
}

static void SecondRun(void)
{
    int good;

    Check("STARTUP_STATE", VerifyStartup());
    SetTestCursor(TRUE, 100, 180);
    Snapshot(900, TRUE);
    if (!StartHelper())
        return;
    ReadStats();
    Check("HELPER_DEFAULT_SOFTWARE", g_stats[0] == 0);
    good = SetupSoftwareLeft(160);
    Check("SECOND_SETUP160", good && ReadPan() == 160 && g_stats[0] == 0);
    if (good) {
        RunEdgeLeg("second_out", 160, 176, 1, 479, 180, 901);
        RunEdgeLeg("second_back", 176, 160, -1, 176, 180, 902);
    }
    if (g_helper && IsWindow(g_helper)) {
        SendMessage(g_helper, WM_CLOSE, 0, 0L);
        g_helper = (HWND)0;
        PumpFor(300);
        ReadStats();
        Check("HELPER_CLOSE_OFF_HOME",
              g_stats[0] == 0 && g_stats[2] == 0 && ReadPan() == 0);
    }
}

static void WriteDone(void)
{
    wsprintf(g_line, "RUN %d FAILURES=%d SNAPS=%d\r\n",
             g_run, g_failures, g_markerSerial);
    LogLine(g_line);
    if (g_log != HFILE_ERROR) {
        _lclose(g_log);
        g_log = HFILE_ERROR;
    }
}

LONG FAR PASCAL Wnd(HWND window, UINT message,
                           WPARAM wParam, LPARAM lParam)
{
    PAINTSTRUCT paint;

    switch (message) {
    case WM_SETCURSOR:
        SetCursor(g_active);
        return TRUE;
    case WM_PAINT:
        BeginPaint(window, &paint);
        if (window == g_main)
            PaintPattern(paint.hdc);
        EndPaint(window, &paint);
        return 0L;
    case WM_CLOSE:
        DestroyWindow(window);
        return 0L;
    case WM_DESTROY:
        PostQuitMessage(0);
        return 0L;
    }
    return DefWindowProc(window, message, wParam, lParam);
}

int PASCAL WinMain(HINSTANCE instance, HINSTANCE previous,
                   LPSTR commandLine, int showCommand)
{
    WNDCLASS windowClass;
    HINSTANCE display;
    HFILE marker;
    HFILE runFile;
    unsigned char andMask[64];
    unsigned char xorMask[64];
    int i;
    int screenGood;

    previous = previous;
    commandLine = commandLine;
    g_instance = instance;
    marker = _lopen("C:\\HEQRUN.TXT", OF_READ);
    if (marker == HFILE_ERROR) {
        g_run = 1;
        runFile = _lcreat("C:\\HEQRUN.TXT", 0);
        if (runFile != HFILE_ERROR) {
            _lwrite(runFile, "1", 1);
            _lclose(runFile);
        }
        g_log = _lcreat("C:\\HEQ.LOG", 0);
    } else {
        g_run = 2;
        _lclose(marker);
        g_log = _lopen("C:\\HEQ.LOG", OF_WRITE);
        if (g_log != HFILE_ERROR)
            _llseek(g_log, 0L, 2);
    }

    wsprintf(g_line, "START run=%d\r\n", g_run);
    LogLine(g_line);
    LogLine("INPUT=USER SetCursorPos; no physical mouse input asserted.\r\n");
    screenGood = GetSystemMetrics(0) == 640 &&
                 GetSystemMetrics(1) == 200;
    Check("GEOMETRY_640_200", screenGood);
    display = GetModuleHandle("DISPLAY");
    if (display) {
        g_statsProc = (HPSTATS)GetProcAddress(display, (LPSTR)106L);
        g_shadowProc = (HPSHADOW)GetProcAddress(display, (LPSTR)107L);
    }
    Check("DISPLAY_EXPORTS", g_statsProc != (HPSTATS)0 &&
          g_shadowProc != (HPSHADOW)0);
    if (!screenGood || !g_statsProc || !g_shadowProc) {
        WriteDone();
        ExitWindows(0, 0);
        return 1;
    }

    memset(&windowClass, 0, sizeof(windowClass));
    g_wndThunk = MakeProcInstance((FARPROC)Wnd, instance);
    if (!g_wndThunk) {
        Check("WND_THUNK", FALSE);
        WriteDone();
        ExitWindows(0, 0);
        return 1;
    }
    windowClass.lpfnWndProc = (WNDPROC)g_wndThunk;
    windowClass.hInstance = instance;
    windowClass.hIcon = LoadIcon((HINSTANCE)0, IDI_APPLICATION);
    windowClass.hCursor = LoadCursor((HINSTANCE)0, IDC_ARROW);
    windowClass.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    windowClass.lpszClassName = "HEDGEQA";
    if (!RegisterClass(&windowClass)) {
        Check("REGISTER_CLASS", FALSE);
        FreeProcInstance(g_wndThunk);
        WriteDone();
        ExitWindows(0, 0);
        return 1;
    }

    memset(andMask, 255, sizeof(andMask));
    memset(xorMask, 0, sizeof(xorMask));
    for (i = 0; i < 8; i++) {
        andMask[i * 4] = 0;
        xorMask[i * 4] = (unsigned char)(0x80 >> i);
    }
    g_cursor = CreateCursor(instance, 0, 0, 32, 16,
                            andMask, xorMask);
    g_active = g_cursor;
    g_main = CreateWindow("HEDGEQA", "Horizontal edge qualification",
                          WS_POPUP, 0, 0, 640, 200,
                          (HWND)0, (HMENU)0, instance, (LPSTR)0);
    if (!g_main) {
        Check("CREATE_WINDOW", FALSE);
        UnregisterClass("HEDGEQA", instance);
        FreeProcInstance(g_wndThunk);
        if (g_cursor)
            DestroyCursor(g_cursor);
        WriteDone();
        ExitWindows(0, 0);
        return 1;
    }
    ShowWindow(g_main, SW_SHOW);
    UpdateWindow(g_main);

    if (g_run == 1)
        FirstRun();
    else
        SecondRun();

    WriteDone();
    DestroyWindow(g_main);
    if (g_cursor)
        DestroyCursor(g_cursor);
    UnregisterClass("HEDGEQA", instance);
    FreeProcInstance(g_wndThunk);
    ExitWindows(0, 0);
    return 0;
}
