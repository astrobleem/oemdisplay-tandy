#define WINVER 0x0300
#include <windows.h>
#include <string.h>
typedef int (FAR PASCAL *WORDS)(unsigned FAR *);
typedef int (FAR PASCAL *SHADOW)(void FAR *);
static WORDS stats;static SHADOW shadow;
static HWND mainw;static HCURSOR cur,active;static HFILE logf;
static unsigned st[8];static int failures,runno;static char buf[240];
static int menu_phase,extra_mode;static HINSTANCE appinst;
static void snap(int id,int kind);
static void line(char *s){_lwrite(logf,s,lstrlen(s));_lclose(logf);logf=_lopen("C:\\HP.LOG",OF_WRITE);_llseek(logf,0L,2);}
static void check(char *s,int ok){wsprintf(buf,"CHECK %s=%d\r\n",(LPSTR)s,ok!=0);line(buf);if(!ok)failures++;}
static void hold(DWORD ms){DWORD t=GetTickCount();MSG m;while(GetTickCount()-t<ms){while(PeekMessage(&m,0,0,0,PM_REMOVE)){TranslateMessage(&m);DispatchMessage(&m);}}}
static int pan(int n){int out[3];HDC dc=GetDC(NULL);int r=Escape(dc,0x5858,2,(LPSTR)&n,(LPSTR)out);ReleaseDC(NULL,dc);return r>0?out[0]:-99;}
static void config(int n){HDC dc=GetDC(NULL);Escape(dc,0x5859,2,(LPSTR)&n,NULL);ReleaseDC(NULL,dc);stats(st);}
static COLORREF color(int i){int r=(i&4)?170:0,g=(i&2)?170:0,b=(i&1)?170:0;if(i&8){r+=85;g+=85;b+=85;}return RGB(r,g,b);}
static void fill(HDC dc,int x,int y,int w,int h,int c){RECT r;HBRUSH b;r.left=x;r.top=y;r.right=x+w;r.bottom=y+h;b=CreateSolidBrush(GetNearestColor(dc,color(c&15)));FillRect(dc,&r,b);DeleteObject(b);}
static void pattern(HDC dc){int x,y;for(y=0;y<200;y+=20)for(x=0;x<640;x+=40)fill(dc,x,y,40,20,((x/40)^(y/20))&15);TextOut(dc,2,30,"LEFT x0",7);TextOut(dc,324,65,"RIGHT x320",10);TextOut(dc,520,170,"EDGE x640",9);}
LONG FAR PASCAL Wnd(HWND w,UINT m,WPARAM wp,LPARAM lp){PAINTSTRUCT p;if(m==WM_TIMER&&wp==99){KillTimer(w,99);if(menu_phase){menu_phase=0;SetCursor(NULL);snap(310,0);SendMessage(w,WM_CANCELMODE,0,0L);}return 0;}if(m==WM_SETCURSOR){SetCursor(active);return TRUE;}if(m==WM_PAINT){BeginPaint(w,&p);if(w==mainw)pattern(p.hdc);EndPaint(w,&p);return 0;}return DefWindowProc(w,m,wp,lp);}
BOOL FAR PASCAL Dlg(HWND w,UINT m,WPARAM wp,LPARAM lp){RECT r;if(m==WM_INITDIALOG){SetWindowPos(w,NULL,310,35,200,100,SWP_NOZORDER);GetWindowRect(w,&r);wsprintf(buf,"DIALOG_RECT %d %d %d %d\r\n",r.left,r.top,r.right,r.bottom);line(buf);check("DIALOG_VISIBLE_EDGE",r.left==310&&r.top==35&&r.right==510&&r.bottom==135);CreateWindow("BUTTON","OK",WS_CHILD|WS_VISIBLE|BS_DEFPUSHBUTTON,8,8,70,18,w,(HMENU)IDOK,appinst,NULL);SetTimer(w,99,250,NULL);return TRUE;}if(m==WM_TIMER){KillTimer(w,99);ShowWindow(w,SW_SHOW);UpdateWindow(w);GetWindowRect(w,&r);check("DIALOG_STAYS_VISIBLE",IsWindowVisible(w)&&r.left<320&&r.right>320);SetCursor(NULL);snap(311,0);EndDialog(w,IDOK);return TRUE;}return FALSE;}
static void cursor(int kind,int x,int y){active=kind?cur:NULL;SetCursorPos(x,y);SetCursor(active);}
static void snap(int id,int kind){HGLOBAL h;LPSTR p;HFILE f;char n[24];POINT pt;int left;unsigned off;char FAR *v=(char FAR *)MAKELONG(0,0xb800);
 hold(250);
 stats(st);left=pan(-1);GetCursorPos(&pt);h=GlobalAlloc(GMEM_MOVEABLE,64000L);check("SNAP_ALLOC",h!=NULL);if(!h)return;p=(LPSTR)GlobalLock(h);shadow(p);
 wsprintf(n,"C:\\S%03d.BIN",id);f=_lcreat(n,0);_lwrite(f,p,64000U);_lclose(f);GlobalUnlock(h);GlobalFree(h);
 wsprintf(n,"C:\\V%03d.BIN",id);f=_lcreat(n,0);for(off=0;off<32768U;off+=8192)_lwrite(f,v+off,8192);_lclose(f);
 wsprintf(buf,"STEP id=%d left=%d head=%u enabled=%u reason=%u hw=%u sw=%u cols=%u bytes=%u cursor=%d x=%d y=%d\r\n",id,left,st[2],st[0],st[3],st[4],st[5],st[6],st[7],kind,pt.x,pt.y);line(buf);
 f=_lcreat("C:\\HPSTEP.TXT",0);_lwrite(f,buf,lstrlen(buf));_lclose(f);hold(1600);
}
static void bench(int mode){DWORD t;int i;config(0);pan(0);config(mode);t=GetTickCount();for(i=0;i<8;i++)pan((i&1)?0:8);wsprintf(buf,"BENCH mode=%d eight_0_8_ms=%lu\r\n",mode,GetTickCount()-t);line(buf);}
int PASCAL WinMain(HINSTANCE h,HINSTANCE prev,LPSTR cmd,int show){WNDCLASS c;FARPROC thunk,dlgthunk;HINSTANCE d;HFILE f;HDC dc;HWND other,edit,helper;HMENU menu,popup;unsigned char am[64],xm[64];int i;HGLOBAL tpl;LPSTR tp;RECT before,after;
 appinst=h;
 runno=1;f=_lopen("C:\\HPRUN.TXT",OF_READ);if(f!=HFILE_ERROR){runno=2;_lclose(f);}f=_lcreat("C:\\HPRUN.TXT",0);_lwrite(f,"1",1);_lclose(f);
 logf=runno==1?_lcreat("C:\\HP.LOG",0):_lopen("C:\\HP.LOG",OF_WRITE);if(runno==2)_llseek(logf,0L,2);
 check("REAL_MODE",!(GetWinFlags()&WF_PMODE));check("GEOMETRY_640_200",GetSystemMetrics(0)==640&&GetSystemMetrics(1)==200);
 d=GetModuleHandle("DISPLAY");stats=(WORDS)GetProcAddress(d,(LPSTR)106L);shadow=(SHADOW)GetProcAddress(d,(LPSTR)107L);if(!stats||!shadow)return 1;
 stats(st);check("DEFAULT_OFF_HEAD0",st[0]==0&&st[1]==0&&st[2]==0&&pan(-1)==0);
 memset(&c,0,sizeof(c));thunk=MakeProcInstance((FARPROC)Wnd,h);c.lpfnWndProc=(WNDPROC)thunk;c.hInstance=h;c.lpszClassName="HQA";RegisterClass(&c);
 memset(am,255,64);memset(xm,0,64);for(i=0;i<8;i++){am[i*4]=0;xm[i*4]=(unsigned char)(0x80>>i);}cur=CreateCursor(h,0,0,32,16,am,xm);
 mainw=CreateWindow("HQA","",WS_POPUP,0,0,640,200,NULL,NULL,h,NULL);ShowWindow(mainw,SW_SHOW);UpdateWindow(mainw);cursor(0,100,90);
 if(runno==2){snap(900,0);goto done;}
 extra_mode=GetProfileInt("HPanQA","Extra",0);if(extra_mode==2)goto keys_only;if(extra_mode==1)goto extra;
 snap(0,0);pan(160);snap(1,0);config(1);snap(2,0);
 for(i=168;i<=320;i+=8){pan(i);stats(st);check("RIGHT800",st[7]==800&&st[3]==0&&st[2]==i/4);if(i==168||i==248||i==320)snap(10+i/8,0);}
 for(i=312;i>=0;i-=8){pan(i);stats(st);check("LEFT800",st[7]==800&&st[3]==0&&st[2]==i/4);if(i==312||i==160||i==8||i==0)snap(100+i/8,0);}
 pan(320);stats(st);check("FULL_JUMP",st[7]==32000&&st[3]==3);snap(200,0);
 dc=GetDC(mainw);SetPixel(dc,639,199,RGB(255,255,255));check("RIGHTMOST_PIXEL",GetPixel(dc,639,199)==RGB(255,255,255));fill(dc,315,60,18,18,15);PatBlt(dc,318,62,24,20,DSTINVERT);TextOut(dc,318,83,"CLIP",4);BitBlt(dc,550,110,88,38,dc,310,60,SRCCOPY);BitBlt(dc,318,120,120,40,dc,326,115,SRCINVERT);ReleaseDC(mainw,dc);snap(201,0);
 cursor(1,320,0);snap(202,1);cursor(1,639,199);snap(203,1);cursor(1,478,99);pan(312);snap(204,1);pan(320);snap(205,1);cursor(0,400,90);snap(206,0);
 menu=CreateMenu();AppendMenu(menu,MF_STRING,101,"Edge menu");other=CreateWindow("HQA","EDGE WINDOW",WS_OVERLAPPEDWINDOW,295,15,235,140,NULL,menu,h,NULL);ShowWindow(other,SW_SHOW);UpdateWindow(other);edit=CreateWindow("EDIT","edge edit",WS_CHILD|WS_VISIBLE|WS_BORDER,3,3,150,22,other,(HMENU)1,h,NULL);snap(210,0);
 SetWindowPos(other,NULL,420,20,210,150,SWP_NOZORDER);snap(211,0);SetWindowPos(other,NULL,280,5,250,175,SWP_NOZORDER);snap(212,0);DestroyWindow(other);UpdateWindow(mainw);snap(213,0);
 config(2);pan(312);stats(st);check("FAULT_FALLBACK",st[0]==0&&st[2]==0&&st[3]==4&&st[7]==32000);snap(220,0);
 pan(-400);check("LOW_CLAMP",pan(-1)==0);pan(999);check("HIGH_CLAMP",pan(-1)==320);pan(319);check("ALIGN_DOWN",pan(-1)==312);snap(221,0);
 bench(0);bench(1);pan(320);snap(399,0);
 goto done;
extra:
 config(0);pan(0);check("HELPER_EXEC",WinExec("HCTL.EXE",SW_HIDE)>31);hold(700);helper=FindWindow("HPANControl",NULL);check("HELPER_WINDOW",helper!=NULL);
 if(helper){stats(st);check("HELPER_DEFAULT_OFF",st[0]==0);SendMessage(helper,WM_COMMAND,105,0L);SendMessage(helper,WM_COMMAND,102,0L);check("HELPER_RIGHT",pan(-1)==8);cursor(0,200,190);snap(300,0);
 SendMessage(helper,WM_COMMAND,101,0L);check("HELPER_LEFT",pan(-1)==0);SendMessage(helper,WM_COMMAND,106,0L);SetCursorPos(319,190);hold(750);check("HELPER_DWELL",pan(-1)==8);SendMessage(helper,WM_COMMAND,107,0L);cursor(0,200,180);snap(301,0);
 SendMessage(helper,WM_COMMAND,103,0L);f=_lcreat("C:\\HPKEYS.TXT",0);_lwrite(f,"READY",5);_lclose(f);hold(4000);check("HELPER_RAW_KEY",pan(-1)==8);cursor(0,200,190);snap(302,0);
 ShowWindow(helper,SW_SHOW);UpdateWindow(helper);cursor(0,500,190);snap(303,0);SendMessage(helper,WM_CLOSE,0,0L);hold(300);stats(st);check("HELPER_STOP_OFF_HOME",st[0]==0&&st[2]==0&&pan(-1)==0);check("HELPER_STOPPED",FindWindow("HPANControl",NULL)==NULL);snap(304,0);}
 goto edges;
keys_only:
 config(0);pan(0);check("KEY_HELPER_EXEC",WinExec("HCTL.EXE",SW_HIDE)>31);hold(700);helper=FindWindow("HPANControl",NULL);check("KEY_HELPER_WINDOW",helper!=NULL);
 if(helper){f=_lcreat("C:\\HPKEYH.TXT",0);_lwrite(f,"READY",5);_lclose(f);hold(3000);stats(st);check("RAW_HARDWARE_KEY",st[0]==1);cursor(0,200,190);snap(305,0);
 f=_lcreat("C:\\HPKEYS.TXT",0);_lwrite(f,"READY",5);_lclose(f);hold(3000);check("RAW_RIGHT_KEY",pan(-1)==8);f=_lcreat("C:\\HPKEYL.TXT",0);_lwrite(f,"READY",5);_lclose(f);hold(3000);check("RAW_LEFT_KEY",pan(-1)==0);SendMessage(helper,WM_COMMAND,102,0L);f=_lcreat("C:\\HPKEYHM.TXT",0);_lwrite(f,"READY",5);_lclose(f);hold(3000);check("RAW_HOME_KEY",pan(-1)==0);
 f=_lcreat("C:\\HPKEYQ.TXT",0);_lwrite(f,"READY",5);_lclose(f);hold(3000);stats(st);check("RAW_QUIT_KEY",st[0]==0&&pan(-1)==0&&FindWindow("HPANControl",NULL)==NULL);cursor(0,200,190);snap(306,0);}
edges:
 config(1);pan(320);popup=CreatePopupMenu();AppendMenu(popup,MF_STRING,101,"Menu edge item");menu=CreateMenu();AppendMenu(menu,MF_POPUP,(UINT)popup,"&Edge");other=CreateWindow("HQA","Menu and dialog at edge",WS_OVERLAPPEDWINDOW,295,15,250,145,NULL,menu,h,NULL);ShowWindow(other,SW_SHOW);UpdateWindow(other);cursor(0,630,190);menu_phase=1;SetTimer(other,99,250,NULL);SendMessage(other,WM_SYSCOMMAND,SC_KEYMENU,'E');check("MENU_CAPTURED",menu_phase==0);
 tpl=GlobalAlloc(GMEM_MOVEABLE|GMEM_ZEROINIT,64L);tp=GlobalLock(tpl);*((DWORD FAR*)tp)=WS_POPUP|WS_CAPTION|WS_SYSMENU|DS_MODALFRAME;tp[4]=0;*((short FAR*)(tp+5))=150;*((short FAR*)(tp+7))=5;*((short FAR*)(tp+9))=110;*((short FAR*)(tp+11))=50;tp[13]=0;tp[14]=0;lstrcpy(tp+15,"Edge dialog");GlobalUnlock(tpl);dlgthunk=MakeProcInstance((FARPROC)Dlg,h);DialogBoxIndirect(h,tpl,other,(DLGPROC)dlgthunk);FreeProcInstance(dlgthunk);GlobalFree(tpl);snap(312,0);
 /* Key mode also checks window move/size across the viewport edge. */
 SetActiveWindow(other);GetWindowRect(other,&before);f=_lcreat("C:\\HPDRAG.TXT",0);_lwrite(f,"READY",5);_lclose(f);hold(6000);GetWindowRect(other,&after);check("KEYBOARD_MOVE",after.left!=before.left||after.top!=before.top);cursor(0,630,190);snap(314,0);
 GetWindowRect(other,&before);f=_lcreat("C:\\HPSIZE.TXT",0);_lwrite(f,"READY",5);_lclose(f);hold(6000);GetWindowRect(other,&after);check("KEYBOARD_SIZE",after.right-after.left!=before.right-before.left||after.bottom-after.top!=before.bottom-before.top);cursor(0,630,190);snap(315,0);
edge_done:
 DestroyWindow(other);UpdateWindow(mainw);snap(313,0);pan(312);snap(399,0);
done:
 wsprintf(buf,"RUN %d FAILURES=%d\r\n",runno,failures);line(buf);_lclose(logf);DestroyWindow(mainw);DestroyCursor(cur);FreeProcInstance(thunk);ExitWindows(0,0);return 0;
}
