from pathlib import Path
import sys,json,struct,hashlib
W=Path(__file__).resolve().parent;name=sys.argv[1];assert name in ('NREPAINT2','NPAINT','NEDGEQA2','NSTBLANK','NEDGEKEY2')
O=W/name;m=json.loads((O/'MEDIA.json').read_text());disk=Path(m['disk']).resolve();assert disk.parent==O.resolve()
if name in ('NEDGEQA2','NSTBLANK','NEDGEKEY2'):
    assert json.loads((O/'LEASE.json').read_text()).get('released'), 'Check scratch FAT only after owned guest cleanup/release'
with disk.open('rb') as f:
    f.seek(m['offset']);boot=f.read(512);bps=struct.unpack_from('<H',boot,11)[0];reserved=struct.unpack_from('<H',boot,14)[0];count=boot[16];size=struct.unpack_from('<H',boot,22)[0]*bps
    copies=[]
    for i in range(count):f.seek(m['offset']+reserved*bps+i*size);copies.append(f.read(size))
r=dict(disk=str(disk),bytes_per_sector=bps,fat_copies=count,fat_size_bytes=size,all_fat_copies_equal=all(x==copies[0] for x in copies),sha256=[hashlib.sha256(x).hexdigest() for x in copies],scope='Read after owned guest stopped; scratch image only, no CF access.')
(O/'FAT-CHECK.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2));assert r['all_fat_copies_equal']
