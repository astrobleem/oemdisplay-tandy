from pathlib import Path
import numpy as np,json,hashlib
W=Path(__file__).resolve().parent;P=W/'sweep-source/experiments/HPAN'
rng=np.random.default_rng(170310);shadow=rng.integers(0,16,(200,640),dtype=np.uint8);video=np.full(32768,0xa5,dtype=np.uint8);checks=0
y=np.arange(200)[:,None];xb=np.arange(160)[None,:]
def fetch(left):
 b=video[(y%4)*8192+((left//2+160*(y//4)+xb)&8191)];r=np.empty((200,320),np.uint8);r[:,::2]=b>>4;r[:,1::2]=b&15;return r
def full(left):
 r=shadow[:,left:left+320];packed=(r[:,::2]<<4)|r[:,1::2];video[((y%4)*8192+160*(y//4)+left//2+xb).ravel()]=packed.ravel()
full(0);old=0;maxbank=0;alias_steps=0
for left in (list(range(8,321,8))+list(range(312,-1,-8)))*2:
 before=video.copy();x0=old+320 if left>old else left;strip=shadow[:,x0:x0+8];stage=((strip[:,::2]<<4)|strip[:,1::2]).copy()
 assert stage.nbytes==800 and np.array_equal(before,video)
 off=(y%4)*8192+160*(y//4)+x0//2+np.arange(4)[None,:];maxbank=max(maxbank,int(np.max(off%8192)))
 video[off.ravel()]=stage.ravel();assert np.array_equal(fetch(left),shadow[:,left:left+320]);checks+=1
 if not np.array_equal(fetch(old),shadow[:,old:old+320]):alias_steps+=1
 # Simulate ordinary GDI damage between commits, including future edge pixels.
 a=int(rng.integers(0,80))*8;b=min(640,a+8*int(rng.integers(1,12)));shadow[:,a:b]=rng.integers(0,16,(200,b-a),dtype=np.uint8);full(left);checks+=1;old=left
assert checks==320 and maxbank==8159 and alias_steps>0
r=dict(status='PASS',checks=checks,staged_steps=160,private_buffer_bytes=800,additional_driver_data_bytes=802,max_bank_byte=maxbank,old_view_aliases_demonstrated=alias_steps,scope='Independent packed-pixel staging/commit model with ordinary dirty updates; native Windows and physical behavior not proved.',hardware_tested=False)
(W/'STAGE-MODEL.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
