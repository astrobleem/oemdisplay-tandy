from pathlib import Path
import sys,json,subprocess,os,time,base64,re,struct
import numpy as np
from PIL import Image
W=Path(__file__).resolve().parent
sys.path.insert(0,r'C:\Users\chad\Documents\Codex\2026-10-14\task-16\deps-local')
sys.path.insert(0,r'E:\DOSMCP\mcp-server')
sys.path.insert(0,r'C:\Users\chad\Documents\Codex\2026-10-14\task-16')
from pyfatfs.PyFatFS import PyFatFS
from pyfatfs._exceptions import PyFATException
from src.gdbclient import GdbClient
from src.headless_input import HeadlessCtl
from hw_model import fetch,decode,PAL
from lease import lease,hidden
O=W/(sys.argv[1] if len(sys.argv)>1 else 'NSTBLANK');m=json.loads((O/'MEDIA.json').read_text())
g=ctl=p=None;error=None;records=[];events=[];seen=set();ready_seen=set();bps={};watch=None;watch_events=None;watch_case=None;done=False;dos=None
def readfiles():
    with PyFatFS(m['disk'],offset=m['offset'],read_only=True) as fs:
        return {n:fs.readbytes(n) for n in ['HTREADY.BIN','HTSTEP.TXT','HTDONE.TXT','HTRET.TXT','HTCASE.TXT'] if fs.exists(n)}
def shot(name):
    (O/(name+'.PNG')).write_bytes(base64.b64decode(ctl.capture_frame_png_b64()))
def tick():return int.from_bytes(g.read_memory(0x46c,4),'little')
def frame(files):
    step=files.get('HTSTEP.TXT',b'').decode(errors='replace')
    if 'STEP' not in step:return
    v={k:int(x) for k,x in re.findall(r'(\w+)=(-?\d+)',step)};i=v['id']
    if i in seen:return
    expected=[(8,0,0,1,32000),(16,0,0,1,32000),(16,1,4,1,32000),(24,1,6,0,800),(32,1,8,0,800),(24,1,6,0,800),(24,1,6,0,800),(24,1,6,0,800),(24,1,6,0,800),(32,0,0,4,32000),(0,0,0,1,32000),(0,0,0,1,32000)][i%100]
    assert tuple(v[k] for k in ['left','enabled','head','reason','bytes'])==expected,(i,'case state',v,expected)
    with PyFatFS(m['disk'],offset=m['offset'],read_only=True) as fs:
        s=fs.readbytes('S%03d.BIN'%i);video=fs.readbytes('V%03d.BIN'%i)
    a=np.frombuffer(s,dtype=np.uint8).reshape(200,4,80);b=np.unpackbits(a,axis=2);allpx=b[:,0,:]*4+b[:,1,:]*2+b[:,2,:]+b[:,3,:]*8;want=allpx[:,v['left']:v['left']+320]
    wrong=int(np.count_nonzero(fetch(video,v['head'])!=want));assert wrong==0,(i,'VRAM',wrong)
    # Let one complete scan finish after the final TextOut before monitor comparison.
    g.run_while(lambda:None,settle_seconds=.07,start_delay=.001)
    shot('FRAME%03d'%i);rgb=np.asarray(Image.open(O/('FRAME%03d.PNG'%i)).convert('RGB'));e,geom=decode(rgb,want,[8,38,2,1]);assert e==0,(i,'monitor',e,geom)
    (O/('S%03d.BIN'%i)).write_bytes(s);(O/('V%03d.BIN'%i)).write_bytes(video);Image.fromarray(PAL[want]).save(O/('VIEW%03d.PNG'%i))
    records.append(dict(**v,wrong=wrong,monitor_wrong=e,geometry=geom));seen.add(i);print('FRAME',i,'PASS',flush=True)
hidden()
with lease(O/'LEASE.json'),(O/'HOST.LOG').open('wb') as output:
    start=time.monotonic()
    try:
        p=subprocess.Popen([r'E:\DOSMCP\86Box\build\development\src\86Box.exe','-P',str(O),'-R',r'E:\x86box\roms','-N'],cwd=O,stdout=output,stderr=subprocess.STDOUT,env=dict(os.environ,QT_QPA_PLATFORM='offscreen',PATH=r'C:\msys64\ucrt64\bin;'+os.environ['PATH']))
        (O/'OWNED.json').write_text(json.dumps(dict(pid=p.pid,exe=r'E:\DOSMCP\86Box\build\development\src\86Box.exe')))
        for _ in range(20):
            try:g=GdbClient(timeout=3);g.connect();ctl=HeadlessCtl('127.0.0.1',12346);break
            except (OSError,ConnectionError):
                if g:g.close();g=None
                time.sleep(.2)
        else:raise RuntimeError('Control channels unavailable')
        while time.monotonic()-start<420:
            if p.poll() is not None:raise RuntimeError('Owned emulator exited')
            stop=g.cont_or_none(.18 if bps else .35)
            try:files=readfiles()
            except PyFATException:files={}
            case=files.get('HTCASE.TXT',b'').decode(errors='replace');match=re.search(r'id=(\d+)',case);caseid=int(match[1]) if match else -1
            ip=g.cs_ip_linear() if stop else -1
            if stop and ip in bps:
                name=bps[ip];events.append(dict(case=caseid,event=name,bda_ticks=tick(),host_elapsed=time.monotonic()-start))
                if name=='unblank_before' and caseid in (0,100):shot('BLACK%03d'%caseid)
                assert g._rsp('z1,%x,1'%ip)=='OK';g.step();assert g._rsp('Z1,%x,1'%ip)=='OK'
            elif stop and watch:
                ev=g.read_memory(watch_events,8*256);n=next((j for j in range(256) if struct.unpack_from('<H',ev,j*8+4)[0]==0),256)
                # Trace array is not cleared between cases; follow latest event by reading key.
                key=int.from_bytes(g.read_memory(watch,2),'little')
                if caseid in (0,100) and key in (21,23):
                    shot('PAINT%03d_%d'%(caseid,key));events.append(dict(case=caseid,event='helper_trace_'+str(key),bda_ticks=tick(),host_elapsed=time.monotonic()-start))
                if caseid not in (0,100) or key==23:
                    g.remove_watchpoint(watch,2);watch=None
                else:
                    g.remove_watchpoint(watch,2);g.step();g.set_watchpoint(watch,2)
            ready=files.get('HTREADY.BIN')
            if ready:
                v,cs,ko,ks,eo,es,_,_=struct.unpack('<8H',ready)
                if v not in ready_seen:
                    for a in list(bps):assert g._rsp('z1,%x,1'%a)=='OK'
                    bps={cs*16+0x296:'blank_after',cs*16+0x590:'conversion_done',cs*16+0x2a1:'unblank_before'}
                    for a in bps:assert g._rsp('Z1,%x,1'%a)=='OK'
                    if watch:g.remove_watchpoint(watch,2)
                    watch=ks*16+ko;watch_events=es*16+eo;g.set_watchpoint(watch,2)
                    ready_seen.add(v);(O/('READY%d.BIN'%v)).write_bytes(ready)
                    # Keep CPU running while F9 is pressed/released; breakpoints remain armed.
                    ctl.key(True,0x43)
                    # The next .18-second continue allows the waiting Windows task to see F9.
                    events.append(dict(case=-1,event='ready_'+str(v),bda_ticks=tick(),host_elapsed=time.monotonic()-start))
                    f9_release=time.monotonic()+.5
            if 'f9_release' in locals() and time.monotonic()>=f9_release:ctl.key(False,0x43);del f9_release
            try:frame(files)
            except PyFATException:pass
            (O/'EVENTS.json').write_text(json.dumps(events,indent=2))
            (O/'PROGRESS.json').write_text(json.dumps(records,indent=2))
            if 'HTRET.TXT' in files:
                g.run_while(lambda:None,settle_seconds=.2,start_delay=.01);shot('DOS')
                mode=g.read_memory(0x449,1)[0];page=g.read_memory(0x462,1)[0];off=int.from_bytes(g.read_memory(0x44e,2),'little');dos=dict(mode=mode,page=page,bda_offset=off);assert mode==3 and page==0 and off==0,dos;done=True;break
        else:raise TimeoutError('420 second owned-process watchdog')
    except Exception as e:error=repr(e);print('FAILED',error,flush=True)
    finally:
        if g:g.close()
        if ctl:ctl.close()
        if p and p.poll() is None:p.terminate()
        if p:
            try:p.wait(timeout=8)
            except subprocess.TimeoutExpired:p.kill();p.wait()
    with PyFatFS(m['disk'],offset=m['offset'],read_only=True) as fs:
        for n in fs.listdir('/'):
            if re.fullmatch(r'T\d{3}\.BIN|HT.*\.(?:TXT|LOG)|RESERVE\.TXT',n,re.I) and not fs.isdir(n):
                try:(O/n).write_bytes(fs.readbytes(n))
                except PyFATException:pass
        if fs.exists('CW/HCTL.LOG'):(O/'HCTL.LOG').write_bytes(fs.readbytes('CW/HCTL.LOG'))
    result=dict(status='PASS' if not error and done and set(range(12))|set(range(100,112))<=seen else 'FAIL',error=error,frames=records,events=events,dos=dos,seconds=time.monotonic()-start,hardware_tested=False,driver_sha256=m['driver_sha256'])
    (O/'RESULT.json').write_text(json.dumps(result,indent=2));print(result['status'],len(records),result['seconds'],flush=True)
