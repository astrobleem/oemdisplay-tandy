from pathlib import Path
import sys,json,os,subprocess,time,base64,re
W=Path(__file__).resolve().parent
sys.path.insert(0,r'C:\Users\chad\Documents\Codex\2026-10-14\task-16\deps-local');sys.path.insert(0,r'E:\DOSMCP\mcp-server')
from pyfatfs.PyFatFS import PyFatFS
from pyfatfs._exceptions import PyFATException
from src.gdbclient import GdbClient
from src.headless_input import HeadlessCtl
from lease import lease,hidden
O=W/(sys.argv[1] if len(sys.argv)>1 else 'NEDGEBASE');m=json.loads((O/'MEDIA.json').read_text());assert Path(m['disk']).resolve().parent==O.resolve()
p=g=ctl=None;error=None;done=False;dos=None;transients=0
hidden()
with lease(O/'LEASE.json'),(O/'HOST.LOG').open('wb') as log:
 start=time.monotonic()
 try:
  p=subprocess.Popen([r'E:\DOSMCP\86Box\build\development\src\86Box.exe','-P',str(O),'-R',r'E:\x86box\roms','-N'],cwd=O,stdout=log,stderr=subprocess.STDOUT,env=dict(os.environ,QT_QPA_PLATFORM='offscreen',PATH=r'C:\msys64\ucrt64\bin;'+os.environ['PATH']))
  (O/'OWNED.json').write_text(json.dumps(dict(pid=p.pid)))
  for _ in range(20):
   try:g=GdbClient(timeout=3);g.connect();ctl=HeadlessCtl('127.0.0.1',12346);break
   except (OSError,ConnectionError):
    if g:g.close();g=None
    time.sleep(.2)
  else:raise RuntimeError('Control channels unavailable')
  while time.monotonic()-start<300:
   if p.poll() is not None:raise RuntimeError('Owned guest exited')
   g.run_while(lambda:None,settle_seconds=.4,start_delay=.005)
   try:
    with PyFatFS(m['disk'],offset=m['offset'],read_only=True) as fs:returned=fs.exists('HERET.TXT')
   except PyFATException:transients+=1;continue
   if returned:
    g.run_while(lambda:None,settle_seconds=.3,start_delay=.005);dos=dict(mode=g.read_memory(0x449,1)[0],page=g.read_memory(0x462,1)[0],offset=int.from_bytes(g.read_memory(0x44e,2),'little'));assert dos==dict(mode=3,page=0,offset=0),dos;(O/'DOS.PNG').write_bytes(base64.b64decode(ctl.capture_frame_png_b64()));done=True;break
  else:raise TimeoutError('300-second baseline trace watchdog')
 except Exception as e:error=repr(e)
 finally:
  if g:g.close()
  if ctl:ctl.close()
  if p and p.poll() is None:p.terminate()
  if p:
   try:p.wait(timeout=8)
   except subprocess.TimeoutExpired:p.kill();p.wait()
 with PyFatFS(m['disk'],offset=m['offset'],read_only=True) as fs:
  for n in ['CW/HSWEEP.LOG','CW/HEDGE.LOG','CW/HCTL.LOG','HERET.TXT','RESERVE.TXT']:
   if fs.exists(n):
    try:(O/Path(n).name).write_bytes(fs.readbytes(n))
    except PyFATException:pass
 text=(O/'HSWEEP.LOG').read_text() if (O/'HSWEEP.LOG').exists() else ''
 ends={int(a):dict(left=int(b),x=int(c),y=int(d),elapsed=int(e)) for a,b,c,d,e in re.findall(r'END case=(\d+) finalLeft=(-?\d+) finalXY=(-?\d+),(-?\d+) elapsed=(\d+)',text)}
 r=dict(status='PASS' if not error and done and len(ends)==7 and 'FAIL' not in text else 'FAIL',error=error,cases=ends,dos=dos,seconds=time.monotonic()-start,transient_reads=transients,scope='Controlled Windows USER SetCursorPos/GetCursorPos trace, not physical mouse input',hardware_tested=False)
 (O/'RESULT.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
