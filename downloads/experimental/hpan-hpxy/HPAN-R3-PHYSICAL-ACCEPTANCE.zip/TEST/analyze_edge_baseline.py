from pathlib import Path
import json,re,sys
W=Path(__file__).resolve().parent;O=W/(sys.argv[1] if len(sys.argv)>1 else 'NEDGEBASE')
log=(O/'HSWEEP.LOG').read_text();trace=(O/'HEDGE.LOG').read_text()
r=json.loads((O/'RESULT.json').read_text());assert r['status']=='PASS',r
rows=[]
for line in trace.splitlines():
    m=re.fullmatch(r'T (\d+) (\d+) left=(-?\d+) xy=(-?\d+),(-?\d+) rect=(-?\d+),(-?\d+),(-?\d+),(-?\d+) dir=(-?\d+)>(-?\d+) since=(\d+) a=(-?\d+) b=(-?\d+)',line)
    if m:
        vals=list(map(int,m.groups()));rows.append(dict(zip(['tick','reason','left','x','y','l','t','r','b','old','new','since','a','v'],vals)))
assert len(rows)>20
cases={int(a):int(b) for a,b in re.findall(r'END case=(\d+) finalLeft=(\d+)',log)}
assert cases[0]==160,('helper-overlap not reproduced',cases)
assert cases[1]<160 and cases[6]<160,('left controls',cases)
assert cases[2]==160 and cases[3]==160,('interior',cases)
assert cases[4]>160 and cases[5]==168,('right and overshoot',cases)
suppressed=[x for x in rows if x['reason']==4 and x['left']==160 and x['x']==160 and x['y']==90]
assert suppressed and all(x['l']<=x['x']<x['r'] and x['t']<=x['y']<x['b'] for x in suppressed)
fires=[x for x in rows if x['reason']==10]
assert fires and all((x['tick']-x['since'])&0xffffffff>=500 for x in fires)
result=dict(status='PASS',native_coordinate_trace=True,cases=cases,helper_overlap_samples=len(suppressed),fire_samples=len(fires),min_fire_dwell_ms=min((x['tick']-x['since'])&0xffffffff for x in fires),
    conclusion='R2 suppresses left edge at y90 when that logical coordinate is inside helper; y180 and minimized helper controls pan left.',
    scope='Programmatic Windows USER cursor input; physical serial mouse was not injected',hardware_tested=False)
(O/'ANALYSIS.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
