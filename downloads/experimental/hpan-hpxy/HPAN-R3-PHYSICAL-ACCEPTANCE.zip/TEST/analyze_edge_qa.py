from pathlib import Path
import json,re,sys
W=Path(__file__).resolve().parent;O=W/(sys.argv[1] if len(sys.argv)>1 else 'NEDGEQA2')
r=json.loads((O/'RESULT.json').read_text());assert r['status']=='PASS',r
log=(O/'HEQ.LOG').read_text()
spec={'full_out_y90':(0,320,1),'full_back_y90':(320,0,-1),'short_out_y180':(160,224,1),'short_back_y180':(224,160,-1),'overshoot_out':(160,176,1),'overshoot_back':(176,160,-1),'second_out':(160,176,1),'second_back':(176,160,-1)}
legs={};total=0
for name,(start,end,direction) in spec.items():
    rows=[tuple(map(int,m)) for m in re.findall(r'OBS '+name+r' left=(\d+) dir=(-?\d+) tick=(\d+) xy=(-?\d+),(-?\d+)',log)]
    expected=list(range(start+direction*8,end+direction*8,direction*8))
    assert [x[0] for x in rows]==expected,(name,rows,expected)
    assert all(x[1]==direction and x[3]==x[0]+(319 if direction>0 else 0) for x in rows),(name,'cursor local position',rows)
    assert re.search(r'LEGEND '+name+' reached=1 left='+str(end),log)
    legs[name]=dict(steps=len(rows),final=end,last_ms=rows[-1][2]);total+=len(rows)
fires=[]
hardware_refills=0
for filename in ['HCTL-RUN1.LOG','HCTL.LOG']:
    text=(O/filename).read_text();assert 'STOP 1 1 0' in text,filename
    rows=[dict(zip(['tick','dwell','left','raw','edge','y','dir'],map(int,m))) for m in re.findall(r'EFIRE tick=(\d+) dwell=(\d+) left=(\d+) rawX=(-?\d+) edgeX=(-?\d+) y=(-?\d+) dir=(-?\d+)',text)]
    assert all(x['dwell']>=500 for x in rows)
    fires+=rows
    events=text.splitlines()
    for i,line in enumerate(events):
        if filename=='HCTL-RUN1.LOG' and line.startswith('EFIRE '):
            assert events[i+1].startswith('PAN ') and events[i+2].startswith('PSTAT ')
            before,after,result=map(int,events[i+1].split()[1:])
            head,reason,copied=map(int,events[i+2].split()[1:])
            assert abs(after-before)==8 and result>0 and head==after//4 and reason==0 and copied==800
            hardware_refills+=1
assert len(fires)==104,(len(fires),total)
clamps=[x for x in fires if x['raw']!=x['edge']]
assert any(x['raw']==639 and x['edge']==479 and x['dir']==1 for x in clamps)
assert any(x['raw']==0 and x['edge']==176 and x['dir']==-1 for x in clamps)
assert hardware_refills==100
result=dict(status='PASS',native_edge_steps=total,confirmed_hardware_edge_refills=hardware_refills,legs=legs,fire_records=len(fires),min_dwell_ms=min(x['dwell'] for x in fires),max_dwell_ms=max(x['dwell'] for x in fires),overshoot_clamps=clamps,exact_active_frames=len(r['frames']),dos_returns=len(r['dos_states']),hardware_tested=False,scope='Windows USER injected pointer; not physical serial mouse')
(O/'ANALYSIS.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
