#include <windows.h>
#include <string.h>

#define ESC_HPAN       0x5858
#define ESC_HMODE      0x5859
#define PAN_STEP       8
#define PAN_MAX        320
#define VIEW_WIDTH     320
#define VIEW_HEIGHT    200
#define LOG_MAX        512
#define TIMER_ID       1
#define TIMER_MS       100
#define EDGE_DWELL     500
#define STATE_TOP      78
#define STATE_BOTTOM   96
#define STATUS_TOP     96
#define STATUS_BOTTOM  114

#define IDM_LEFT       101
#define IDM_RIGHT      102
#define IDM_HOME       103
#define IDM_SW         104
#define IDM_HW         105
#define IDM_EDGE_ON    106
#define IDM_EDGE_OFF   107
#define IDM_EXIT       108

typedef unsigned (FAR PASCAL *HPSTATS)(unsigned FAR *);

static HWND g_window;
static HDC g_display;
static HFILE g_logFile = HFILE_ERROR;
static int g_logCount;
static int g_capable;
static int g_operational;
static int g_driverTouched;
static int g_left;
static int g_hardware;
static HPSTATS g_stats;
static int g_edge;
static int g_stopped;
static int g_closePending;
static int g_leftLatch;
static int g_rightLatch;
static int g_homeLatch;
static int g_hLatch;
static int g_eLatch;
static int g_qLatch;
static int g_edgeDirection;
static DWORD g_edgeSince;
static char g_status[96];

static void InvalidateState(void)
{
    RECT row;

    if (!g_window)
        return;
    row.left = 0;
    row.top = STATE_TOP;
    row.right = 280;
    row.bottom = STATE_BOTTOM;
    InvalidateRect(g_window, &row, FALSE);
}

static void InvalidateStatus(void)
{
    RECT row;

    if (!g_window)
        return;
    row.left = 0;
    row.top = STATUS_TOP;
    row.right = 280;
    row.bottom = STATUS_BOTTOM;
    InvalidateRect(g_window, &row, FALSE);
}

static int DamageTouches(LPRECT damage, int left, int top,
                         int right, int bottom)
{
    return damage->left < right && damage->right > left &&
           damage->top < bottom && damage->bottom > top;
}

static void DrawStaticLine(HDC dc, LPRECT damage, int y, LPSTR text)
{
    if (DamageTouches(damage, 0, y, 280, y + 18))
        TextOut(dc, 8, y, text, (int)lstrlen(text));
}

static int ReadStats(unsigned FAR *stats)
{
    int i;

    if (!g_stats)
        return FALSE;
    for (i = 0; i < 8; i++)
        stats[i] = 0;
    g_stats(stats);
    return TRUE;
}

static void LogRecord(LPSTR eventName, int a, int b, int c)
{
    char line[96];
    int count;

    if (g_logFile == HFILE_ERROR || g_logCount >= LOG_MAX)
        return;
    wsprintf(line, "%s %d %d %d\r\n", eventName, a, b, c);
    count = (int)lstrlen(line);
    if (_lwrite(g_logFile, line, (UINT)count) == count)
        g_logCount++;
}

/* One bounded record per fired dwell, from the USER timer only. */
static void LogEdge(int rawX, int edgeX, int y, int direction,
                    DWORD now, DWORD elapsed)
{
    char line[128];
    int count;

    if (g_logFile == HFILE_ERROR || g_logCount >= LOG_MAX)
        return;
    wsprintf(line,
             "EFIRE tick=%lu dwell=%lu left=%d rawX=%d edgeX=%d y=%d dir=%d\r\n",
             now, elapsed, g_left, rawX, edgeX, y, direction);
    count = (int)lstrlen(line);
    if (_lwrite(g_logFile, line, (UINT)count) == count)
        g_logCount++;
}

static void SetStatus(LPSTR text)
{
    if (lstrcmp(g_status, text) == 0)
        return;
    lstrcpy(g_status, text);
    InvalidateStatus();
}

static int EscapeSupported(int code)
{
    int request;

    request = code;
    return Escape(g_display, QUERYESCSUPPORT, sizeof(int),
                  (LPSTR)&request, (LPSTR)0) > 0;
}

static int GetPan(int *left)
{
    int input;
    int output[3];
    int result;

    input = 0xffff;
    output[0] = -1;
    output[1] = 0;
    output[2] = 0;
    result = Escape(g_display, ESC_HPAN, sizeof(int),
                    (LPSTR)&input, (LPSTR)output);
    if (result <= 0 || output[0] < 0 || output[0] > PAN_MAX ||
        (output[0] & 7) != 0 || output[1] != VIEW_WIDTH ||
        output[2] != 640)
        return FALSE;
    *left = output[0];
    return TRUE;
}

static int SetPan(int requested)
{
    int input;
    int output[3];
    int oldLeft;
    int result;
    POINT point;
    int movePointer;
    unsigned stats[8];
    int oldHardware;
    int statsAvailable;

    g_edgeDirection = 0; /* Manual commands restart the dwell. */
    if (!g_operational)
        return FALSE;
    if (requested < 0)
        requested = 0;
    if (requested > PAN_MAX)
        requested = PAN_MAX;
    requested = requested & 0xfff8;
    oldLeft = g_left;
    if (requested == oldLeft)
        return TRUE;

    movePointer = FALSE;
    GetCursorPos(&point);
    if (point.x >= oldLeft && point.x < oldLeft + VIEW_WIDTH &&
        point.y >= 0 && point.y < VIEW_HEIGHT)
        movePointer = TRUE;

    input = requested;
    output[0] = -1;
    output[1] = 0;
    output[2] = 0;
    result = Escape(g_display, ESC_HPAN, sizeof(int),
                    (LPSTR)&input, (LPSTR)output);
    if (result <= 0 || output[0] < 0 || output[0] > PAN_MAX ||
        (output[0] & 7) != 0 || output[1] != VIEW_WIDTH ||
        output[2] != 640) {
        g_operational = FALSE;
        SetStatus("Pan command failed; controls stopped. Exit to reset.");
        LogRecord("PANERR", requested, result, 0);
        return FALSE;
    }
    g_left = output[0];
    oldHardware = g_hardware;
    statsAvailable = ReadStats(stats);
    if (statsAvailable)
        g_hardware = stats[0] != 0;
    if (movePointer && g_left != oldLeft)
        SetCursorPos(point.x + g_left - oldLeft, point.y);
    LogRecord("PAN", oldLeft, g_left, result);
    if (statsAvailable)
        LogRecord("PSTAT", stats[2], stats[3], stats[7]);
    if (g_left != oldLeft || g_hardware != oldHardware)
        InvalidateState();
    SetStatus("Pan position updated.");
    return TRUE;
}

static void SetHardware(int enabled)
{
    int input;
    int result;
    unsigned stats[8];
    int confirmed;
    int oldHardware;
    char message[96];

    g_edgeDirection = 0;
    if (!g_operational)
        return;
    oldHardware = g_hardware;
    input = enabled ? 1 : 0;
    result = Escape(g_display, ESC_HMODE, sizeof(int),
                    (LPSTR)&input, (LPSTR)0);
    if (result > 0) {
        g_hardware = input;
        confirmed = ReadStats(stats);
        if (confirmed) {
            g_hardware = stats[0] != 0;
            if (g_hardware == input)
                wsprintf(message, "Hardware refill is %s.",
                         (LPSTR)(g_hardware ? "on" : "off"));
            else
                wsprintf(message, "Mode request fell back; actual %s.",
                         (LPSTR)(g_hardware ? "on" : "off"));
            LogRecord("MODE", input, g_hardware, result);
        } else {
            wsprintf(message, "%s mode requested; state unconfirmed.",
                     (LPSTR)(input ? "Hardware" : "Software"));
            LogRecord("MODE?", input, result, 0);
        }
    } else {
        SetStatus("Mode command failed.");
        LogRecord("MODEERR", input, result, 0);
        return;
    }
    if (oldHardware != g_hardware)
        InvalidateState();
    if (result > 0)
        SetStatus(message);
}

static void PanBy(int amount)
{
    SetPan(g_left + amount);
}

static void StopHelper(void)
{
    int input;
    int configResult;
    int panResult;
    int output[3];

    if (g_stopped)
        return;
    g_stopped = TRUE;
    g_closePending = TRUE;
    g_operational = FALSE;
    g_edge = FALSE;
    configResult = 0;
    panResult = 0;
    if (g_driverTouched && g_display) {
        input = 0;
        configResult = Escape(g_display, ESC_HMODE, sizeof(int),
                              (LPSTR)&input, (LPSTR)0);
        input = 0;
        output[0] = 0;
        output[1] = VIEW_WIDTH;
        output[2] = 640;
        panResult = Escape(g_display, ESC_HPAN, sizeof(int),
                           (LPSTR)&input, (LPSTR)output);
        LogRecord("STOP", configResult, panResult, 0);
    } else {
        LogRecord("STOP", 0, 0, 0);
    }
    if (g_logFile != HFILE_ERROR) {
        _lclose(g_logFile);
        g_logFile = HFILE_ERROR;
    }
}

static int Pressed(int key, int *latch)
{
    int down;

    down = (GetAsyncKeyState(key) & 0x8000) != 0;
    if (!down) {
        *latch = FALSE;
        return FALSE;
    }
    if (*latch)
        return FALSE;
    *latch = TRUE;
    return TRUE;
}

static void PollKeyboard(void)
{
    int controlDown;
    int altDown;
    int chord;
    int leftPressed;
    int rightPressed;
    int homePressed;
    int hPressed;
    int ePressed;
    int qPressed;

    controlDown = (GetAsyncKeyState(VK_CONTROL) & 0x8000) != 0;
    altDown = (GetAsyncKeyState(VK_MENU) & 0x8000) != 0;
    chord = controlDown && altDown;
    leftPressed = Pressed(VK_LEFT, &g_leftLatch);
    rightPressed = Pressed(VK_RIGHT, &g_rightLatch);
    homePressed = Pressed(VK_HOME, &g_homeLatch);
    hPressed = Pressed('H', &g_hLatch);
    ePressed = Pressed('E', &g_eLatch);
    qPressed = Pressed('Q', &g_qLatch);

    if (!chord)
        return;
    if (qPressed) {
        g_closePending = TRUE;
        if (g_window)
            PostMessage(g_window, WM_CLOSE, 0, 0L);
    } else if (leftPressed) {
        PanBy(-PAN_STEP);
    } else if (rightPressed) {
        PanBy(PAN_STEP);
    } else if (homePressed) {
        SetPan(0);
    } else if (hPressed) {
        SetHardware(!g_hardware);
    } else if (ePressed) {
        g_edge = !g_edge;
        g_edgeDirection = 0;
        InvalidateState();
        SetStatus(g_edge ? "Pointer edge pan is on (500 ms dwell)." :
                           "Pointer edge pan is off.");
        LogRecord("EDGE", g_edge, EDGE_DWELL, 0);
    }
}

static void PollEdge(void)
{
    POINT point;
    int direction;
    int localX;
    int edgeX;
    int rawX;
    int result;
    DWORD now;
    DWORD elapsed;

    if (!g_edge || !g_operational || g_stopped || g_closePending) {
        g_edgeDirection = 0;
        return;
    }
    GetCursorPos(&point);
    if (point.y < 0 || point.y >= VIEW_HEIGHT) {
        g_edgeDirection = 0;
        return;
    }
    /* USER coordinates span the 640px logical screen. The helper can
       overlap the visible left edge at nonzero origins; that edge must
       work just like the right edge while the user has enabled sweeping. */
    localX = point.x - g_left;
    direction = 0;
    if (localX <= 0 && g_left > 0)
        direction = -1;
    else if (localX >= VIEW_WIDTH - 1 && g_left < PAN_MAX)
        direction = 1;
    if (direction == 0) {
        g_edgeDirection = 0;
        return;
    }
    now = GetTickCount();
    if (direction != g_edgeDirection) {
        g_edgeDirection = direction;
        g_edgeSince = now;
        return;
    }
    elapsed = now - g_edgeSince;
    if (elapsed < (DWORD)EDGE_DWELL)
        return;

    /* A logical pointer beyond the viewport must first be put on its
       physical edge, so SetPan can preserve the pointer's local position.
       SetCursorPos has no return value in the Windows 3.0 SDK. */
    rawX = point.x;
    edgeX = g_left + (direction < 0 ? 0 : VIEW_WIDTH - 1);
    if (point.x != edgeX) {
        SetCursorPos(edgeX, point.y);
        GetCursorPos(&point);
        if (point.x != edgeX || point.y < 0 || point.y >= VIEW_HEIGHT) {
            g_edgeDirection = 0;
            return;
        }
    }
    LogEdge(rawX, edgeX, point.y, direction, now, elapsed);
    result = SetPan(g_left + direction * PAN_STEP);
    /* Rendering and the synchronous pan must finish before the next
       dwell starts. Never consume an already-expired timer backlog. */
    if (result && g_edge && g_operational && !g_closePending) {
        g_edgeDirection = direction;
        g_edgeSince = GetTickCount();
    }
}

static HMENU MakeMenu(void)
{
    HMENU bar;
    HMENU panMenu;
    HMENU modeMenu;
    HMENU edgeMenu;

    bar = CreateMenu();
    panMenu = CreatePopupMenu();
    modeMenu = CreatePopupMenu();
    edgeMenu = CreatePopupMenu();
    if (!bar || !panMenu || !modeMenu || !edgeMenu)
        return (HMENU)0;

    AppendMenu(panMenu, MF_STRING, IDM_LEFT, "Pan &left by 8");
    AppendMenu(panMenu, MF_STRING, IDM_RIGHT, "Pan &right by 8");
    AppendMenu(panMenu, MF_STRING, IDM_HOME, "Pan &home");
    AppendMenu(panMenu, MF_SEPARATOR, 0, (LPSTR)0);
    AppendMenu(panMenu, MF_STRING, IDM_EXIT, "E&xit");
    AppendMenu(modeMenu, MF_STRING, IDM_SW, "Software mode");
    AppendMenu(modeMenu, MF_STRING, IDM_HW, "Hardware refill mode");
    AppendMenu(edgeMenu, MF_STRING, IDM_EDGE_ON, "Pointer edge &on");
    AppendMenu(edgeMenu, MF_STRING, IDM_EDGE_OFF, "Pointer edge o&ff");
    AppendMenu(bar, MF_POPUP, (UINT)panMenu, "&Pan");
    AppendMenu(bar, MF_POPUP, (UINT)modeMenu, "&Mode");
    AppendMenu(bar, MF_POPUP, (UINT)edgeMenu, "&Pointer edge");
    return bar;
}

static void PaintWindow(HWND window)
{
    PAINTSTRUCT paint;
    HDC dc;
    char line[96];
    LPSTR text;
    RECT row;

    dc = BeginPaint(window, &paint);
    text = "640x200 logical; 320x200 viewport.";
    DrawStaticLine(dc, &paint.rcPaint, 6, text);
    text = "Ctrl+Alt+Left/Right: pan 8px.";
    DrawStaticLine(dc, &paint.rcPaint, 24, text);
    text = "Ctrl+Alt+Home: reset; H: hardware.";
    DrawStaticLine(dc, &paint.rcPaint, 42, text);
    text = "Ctrl+Alt+E: edge (500ms); Q: exit.";
    DrawStaticLine(dc, &paint.rcPaint, 60, text);
    if (DamageTouches(&paint.rcPaint, 0, STATE_TOP, 280, STATE_BOTTOM)) {
        row.left = 0;
        row.top = STATE_TOP;
        row.right = 280;
        row.bottom = STATE_BOTTOM;
        FillRect(dc, &row, (HBRUSH)(COLOR_WINDOW + 1));
        if (g_capable) {
            wsprintf(line, "Left %u / 320    Hardware %s    Edge %s",
                     g_left, (LPSTR)(g_hardware ? "on" : "off"),
                     (LPSTR)(g_edge ? "on" : "off"));
            TextOut(dc, 8, STATE_TOP, line, (int)lstrlen(line));
        } else {
            text = "Driver controls unavailable; no pan/mode command sent.";
            TextOut(dc, 8, STATE_TOP, text, (int)lstrlen(text));
        }
    }
    if (DamageTouches(&paint.rcPaint, 0, STATUS_TOP, 280, STATUS_BOTTOM)) {
        row.left = 0;
        row.top = STATUS_TOP;
        row.right = 280;
        row.bottom = STATUS_BOTTOM;
        FillRect(dc, &row, (HBRUSH)(COLOR_WINDOW + 1));
        TextOut(dc, 8, STATUS_TOP, g_status, (int)lstrlen(g_status));
    }
    EndPaint(window, &paint);
}

long FAR PASCAL Wnd(HWND window, UINT message, WPARAM wParam,
                    LPARAM lParam)
{
    switch (message) {
    case WM_CREATE:
        SetTimer(window, TIMER_ID, TIMER_MS, (FARPROC)0);
        return 0L;
    case WM_TIMER:
        PollKeyboard();
        PollEdge();
        return 0L;
    case WM_COMMAND:
        switch (wParam) {
        case IDM_LEFT:
            PanBy(-PAN_STEP);
            break;
        case IDM_RIGHT:
            PanBy(PAN_STEP);
            break;
        case IDM_HOME:
            SetPan(0);
            break;
        case IDM_SW:
            SetHardware(FALSE);
            break;
        case IDM_HW:
            SetHardware(TRUE);
            break;
        case IDM_EDGE_ON:
            if (!g_edge)
                InvalidateState();
            g_edge = TRUE;
            g_edgeDirection = 0;
            SetStatus("Pointer edge pan is on (500 ms dwell).");
            LogRecord("EDGE", g_edge, EDGE_DWELL, 0);
            break;
        case IDM_EDGE_OFF:
            if (g_edge)
                InvalidateState();
            g_edge = FALSE;
            g_edgeDirection = 0;
            SetStatus("Pointer edge pan is off.");
            LogRecord("EDGE", g_edge, EDGE_DWELL, 0);
            break;
        case IDM_EXIT:
            PostMessage(window, WM_CLOSE, 0, 0L);
            break;
        default:
            break;
        }
        return 0L;
    case WM_PAINT:
        PaintWindow(window);
        return 0L;
    case WM_CLOSE:
        StopHelper();
        DestroyWindow(window);
        return 0L;
    case WM_DESTROY:
        KillTimer(window, TIMER_ID);
        if (!g_stopped)
            StopHelper();
        PostQuitMessage(0);
        return 0L;
    }
    return DefWindowProc(window, message, wParam, lParam);
}

int PASCAL WinMain(HINSTANCE instance, HINSTANCE previous,
                   LPSTR commandLine, int showCommand)
{
    WNDCLASS windowClass;
    HWND window;
    HMENU menu;
    MSG message;
    int panCode;
    int modeCode;
    int width;
    int height;
    int initialLeft;
    FARPROC thunk;
    unsigned stats[8];
    HINSTANCE displayInstance;

    previous = previous;
    commandLine = commandLine;
    g_display = GetDC((HWND)0);
    if (!g_display) {
        lstrcpy(g_status, "Cannot open the display context.");
    } else {
        width = GetDeviceCaps(g_display, HORZRES);
        height = GetDeviceCaps(g_display, VERTRES);
        panCode = EscapeSupported(ESC_HPAN);
        modeCode = EscapeSupported(ESC_HMODE);
        if (width == 640 && height == 200 && panCode && modeCode &&
            GetPan(&initialLeft)) {
            g_capable = TRUE;
            g_left = initialLeft;
            g_driverTouched = TRUE;
            displayInstance = GetModuleHandle("DISPLAY");
            if (displayInstance)
                g_stats = (HPSTATS)GetProcAddress(displayInstance,
                                                    (LPSTR)106L);
            panCode = 0;
            if (Escape(g_display, ESC_HMODE, sizeof(int),
                       (LPSTR)&panCode, (LPSTR)0) > 0) {
                g_operational = TRUE;
                g_hardware = FALSE;
                if (ReadStats(stats)) {
                    g_hardware = stats[0] != 0;
                    wsprintf(g_status, "Started; hardware refill %s.",
                             (LPSTR)(g_hardware ? "on" : "off"));
                } else {
                    lstrcpy(g_status,
                            "Software mode requested; state unconfirmed.");
                }
            } else {
                lstrcpy(g_status, "Could not select software mode.");
            }
        } else {
            lstrcpy(g_status, "Requires 640x200 and HPAN display escapes.");
        }
    }

    g_logFile = _lcreat("HCTL.LOG", 0);
    if (g_logFile != HFILE_ERROR) {
        LogRecord("START", g_capable, g_left, 0);
        if (g_capable)
            LogRecord(g_operational ? "MODE" : "MODEERR", 0,
                      g_operational, 0);
    }

    thunk = MakeProcInstance((FARPROC)Wnd, instance);
    if (!thunk) {
        StopHelper();
        if (g_display)
            ReleaseDC((HWND)0, g_display);
        return 0;
    }
    windowClass.style = CS_HREDRAW | CS_VREDRAW;
    windowClass.lpfnWndProc = (WNDPROC)thunk;
    windowClass.cbClsExtra = 0;
    windowClass.cbWndExtra = 0;
    windowClass.hInstance = instance;
    windowClass.hIcon = LoadIcon((HINSTANCE)0, IDI_APPLICATION);
    windowClass.hCursor = LoadCursor((HINSTANCE)0, IDC_ARROW);
    windowClass.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    windowClass.lpszMenuName = (LPSTR)0;
    windowClass.lpszClassName = "HPANControl";
    if (!RegisterClass(&windowClass)) {
        FreeProcInstance(thunk);
        StopHelper();
        if (g_display)
            ReleaseDC((HWND)0, g_display);
        return 0;
    }

    menu = MakeMenu();
    if (!menu) {
        UnregisterClass("HPANControl", instance);
        FreeProcInstance(thunk);
        StopHelper();
        if (g_display)
            ReleaseDC((HWND)0, g_display);
        return 0;
    }
    window = CreateWindow("HPANControl", "HPAN control",
                          WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU |
                          WS_MINIMIZEBOX,
                          12, 12, 280, 150,
                          (HWND)0, menu, instance, (LPSTR)0);
    if (!window) {
        UnregisterClass("HPANControl", instance);
        FreeProcInstance(thunk);
        StopHelper();
        if (g_display)
            ReleaseDC((HWND)0, g_display);
        return 0;
    }
    g_window = window;
    ShowWindow(window, showCommand);
    UpdateWindow(window);

    while (GetMessage(&message, (HWND)0, 0, 0)) {
        TranslateMessage(&message);
        DispatchMessage(&message);
    }
    StopHelper();
    UnregisterClass("HPANControl", instance);
    FreeProcInstance(thunk);
    if (g_display)
        ReleaseDC((HWND)0, g_display);
    return (int)message.wParam;
}
