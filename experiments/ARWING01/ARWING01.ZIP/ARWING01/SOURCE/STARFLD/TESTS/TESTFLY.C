#include <assert.h>
#include <stdio.h>
#include "STFLY.H"
int main(void){FLY f;int i,j,w,active;unsigned oldfire;for(w=160;w<=640;w*=2){
 fly_init(&f,w,200);for(i=0;i<10000;i++){fly_step(&f,0,99,-99,3);assert(f.x>=2&&f.x+f.w<=w-2);assert(f.y>=30&&f.y+FLY_HEIGHT<=198);assert(!f.fired);}
 fly_init(&f,w,200);for(i=0;i<10000;i++){fly_step(&f,1,i%2?-32000:32000,i%2?-32000:32000,3);active=0;for(j=0;j<FLY_SHOTS;j++){active+=f.shots[j].active;assert(!f.shots[j].active||(f.shots[j].x>=2&&f.shots[j].x<w&&f.shots[j].y>=2&&f.shots[j].y<200));}assert(active<=4);assert(f.x>=2&&f.x+f.w<=w-2);assert(f.y>=30&&f.y+FLY_HEIGHT<=198);}
 assert(f.fired<=3334);oldfire=f.fired;for(i=0;i<100;i++)fly_step(&f,0,2,2,3);assert(f.fired==oldfire);for(j=0;j<FLY_SHOTS;j++)assert(!f.shots[j].active);
 fly_init(&f,w,200);assert(!f.fired&&!f.cooldown);for(i=0;i<10;i++){fly_step(&f,1,0,0,0);assert(f.pose==1&&f.x==(w-f.w)/2&&f.y==133);}
}puts("PASS: 60,330 model slices; 160/320/640; clamps, idle flight, center, held-fire cap, disconnect retirement, fresh restart");return 0;}
