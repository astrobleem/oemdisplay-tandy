#include "STFLY.H"
static int clamp(int n,int lo,int hi){return n<lo?lo:n>hi?hi:n;}
void fly_init(FLY *f,int width,int height){int i;
 f->width=width;f->height=height;f->w=width<240?16:width<480?32:64;
 f->scale=width<480?1:2;f->x=(width-f->w)/2;f->y=height*2/3;
 f->pose=1;f->autox=1;f->autoy=-1;f->phase=f->cooldown=0;
 f->fired=f->steps=0;for(i=0;i<FLY_SHOTS;i++)f->shots[i].active=0;
}
void fly_step(FLY *f,int joystick,int dx,int dy,int buttons){int i,vx,vy;
 f->steps++;f->phase=(f->phase+1)%4;
 if(joystick){vx=clamp(dx,-2,2);vy=clamp(dy,-2,2);}
 else{
  if(f->x<f->width/5)f->autox=1;
  if(f->x>f->width*4/5-f->w)f->autox=-1;
  if(f->y<f->height/2)f->autoy=1;
  if(f->y>f->height*3/4)f->autoy=-1;
  vx=f->autox;vy=f->phase?0:f->autoy;
 }
 f->x=clamp(f->x+vx*f->scale,2,f->width-f->w-2);
 f->y=clamp(f->y+vy,30,f->height-FLY_HEIGHT-2);
 f->pose=vx<0?0:vx>0?2:1;
 for(i=0;i<FLY_SHOTS;i++)if(f->shots[i].active){
  f->shots[i].y-=8;if(f->shots[i].y<2)f->shots[i].active=0;
 }
 if(f->cooldown)f->cooldown--;
 if(joystick&&buttons&&!f->cooldown){
  for(i=0;i<FLY_SHOTS;i++)if(!f->shots[i].active){
   f->shots[i].x=f->x+f->w/2;f->shots[i].y=f->y-3;
   f->shots[i].active=1;f->fired++;f->cooldown=3;break;
  }
 }
}
