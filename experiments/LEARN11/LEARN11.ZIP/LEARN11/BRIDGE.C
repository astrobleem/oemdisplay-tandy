/* Host fixture only. Verbatim engine and loader linked separately. */
#include "BASE/src/TANDI.H"
static TDB database;
static ENGINE engine;
int fixture_open(const char *path){return db_open(&database,path);}
void fixture_close(void){db_close();}
void fixture_reset(void){eng_reset(&engine,&database);}
int fixture_question(void){return eng_confident(&engine,&database)?-1:eng_choose(&engine,&database);}
int fixture_answer(int value){return eng_answer(&engine,&database,value);}
int fixture_best(void){return engine.best;}
int fixture_turn(void){return engine.turn;}
void fixture_reject(void){eng_reject(&engine,&database);}
unsigned long fixture_examined(void){return engine.examined;}
unsigned long fixture_seeks(void){return database.seeks;}
unsigned long fixture_bytes(void){return database.bytes;}
unsigned long fixture_engine_size(void){return (unsigned long)sizeof(engine);}
