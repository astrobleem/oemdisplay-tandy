/* Every displayed claim is derived from the actual unchanged engine/loader. */
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include "../src/OBSERVE.H"
static TDB d;static ENGINE e;static TDHISTORY h;static TDEXPLAIN x;
static U8 truth[TD_ROW],leader[TD_ROW],other[TD_ROW];
static const short delta[5][5]={
 {4,2,0,-4,-8},{2,2,0,-2,-4},{0,0,0,0,0},
 {-4,-2,0,2,2},{-8,-4,0,2,4}
};
static int ab(int v){return v<0?-v:v;}
int main(int argc,char **argv){
    int c,mode,i,j,q,a,v,w,known,flips,last,first;
    long ls,os;TDPOOL p;char target[40],ln[40],on[40],question[80];
    if(argc!=2||!db_open(&d,argv[1]))return 2;
    printf("kind,mode,target,leader,other,q,answer,leader_fact,other_fact,leader_delta,other_delta,difference,leading,eligible\n");
    for(mode=0;mode<2;mode++)for(c=0;c<(int)d.nc;c++){
        assert(db_row(&d,c,truth)&&db_name(&d,c,target));
        eng_reset(&e,&d);obs_reset(&h);known=flips=0;last=d.nc;
        while(!eng_confident(&e,&d)){
            q=eng_choose(&e,&d);if(q<0)break;
            a=db_value(truth,q);
            /* Exploratory policy only until Claude's exact harness arrives:
               invert first and fourth known answered facts (never UNKNOWN). */
            if(a!=2){known++;if(mode&&(known==1||known==4)){a=4-a;flips++;}}
            assert(obs_answer(&h,&e,&d,a));
            obs_pool(&e,&d,&p);
            if(p.leading>last)printf("rise,%d,%s,%s,%s,%d,%d,%d,%d,%d,%d,%d,%d,%d\n",
                mode,target,"","",e.turn,0,0,0,0,0,last,p.leading,p.eligible);
            last=p.leading;
        }
        assert(obs_explain(&h,&e,&d,&x)&&x.valid);
        assert(x.leader==e.best&&x.other==e.second&&x.count==e.turn);
        assert(db_row(&d,x.leader,leader)&&db_row(&d,x.other,other));
        assert(db_name(&d,x.leader,ln)&&db_name(&d,x.other,on));
        ls=os=0;
        for(i=0;i<h.count;i++){
            q=h.q[i];a=h.a[i];v=db_value(leader,q);w=db_value(other,q);
            ls+=delta[a][v];os+=delta[a][w];
        }
        assert(ls==x.leaderScore&&os==x.otherScore&&x.sum==ls-os);
        obs_pool(&e,&d,&p);
        printf("case,%d,%s,%s,%s,%d,%d,%d,%d,%ld,%ld,%ld,%d,%d\n",
               mode,target,ln,on,h.count,flips,e.best!=c,e.turn>=25,ls,os,x.sum,p.leading,p.eligible);
        for(i=0;i<x.count;i++){
            TDCLUE *k=&x.clue[i];first=0;
            for(j=0;j<h.count;j++)if(h.q[j]==k->q&&h.a[j]==k->answer)first++;
            assert(first==1);
            assert(k->leaderFact==db_value(leader,k->q));
            assert(k->otherFact==db_value(other,k->q));
            assert(k->leaderDelta==delta[k->answer][k->leaderFact]);
            assert(k->otherDelta==delta[k->answer][k->otherFact]);
            assert(k->difference==k->leaderDelta-k->otherDelta);
            if(i)assert(ab(x.clue[i-1].difference)>=ab(k->difference));
            assert(db_question(&d,k->q,question));
            /* Question text is retrieved by the reporting wrapper, no CSV quotes. */
            printf("clue,%d,%s,%s,%s,%d,%d,%d,%d,%d,%d,%d,%d,%d\n",
                mode,target,ln,on,k->q,k->answer,k->leaderFact,k->otherFact,
                k->leaderDelta,k->otherDelta,k->difference,p.leading,p.eligible);
        }
        /* Rejection excludes a candidate by explicit player action only. */
        eng_reject(&e,&d);obs_pool(&e,&d,&p);assert(p.eligible==(int)d.nc-1);
    }
    /* Complete history beyond 25, ending with every available question. */
    eng_reset(&e,&d);obs_reset(&h);
    for(i=0;i<(int)d.nq;i++){e.current=i;assert(obs_answer(&h,&e,&d,2));}
    assert(h.count==d.nq&&h.count>25);
    assert(obs_explain(&h,&e,&d,&x)&&x.count==d.nq&&x.sum==0);
    e.current=0;assert(!obs_answer(&h,&e,&d,4));assert(h.count==d.nq);
    h.a[0]=5;assert(!obs_explain(&h,&e,&d,&x));
    printf("history,0,,,,%d,,,,,,,,\n",d.nq);
    db_close();return 0;
}
