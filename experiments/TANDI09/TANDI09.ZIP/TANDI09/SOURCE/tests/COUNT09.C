#include <assert.h>
#include <stdio.h>
#include "OBSERVE.H"
static TDB d;static ENGINE e;static TDHISTORY h;static U8 row[TD_ROW];
int main(int argc,char **argv){int c,q,i,j,rejections,rises=0,before;TDPOOL p;
 assert(argc==2&&db_open(&d,argv[1]));
 for(c=0;c<(int)d.nc;c++){
  eng_reset(&e,&d);obs_reset(&h);obs_pool(&e,&d,&p);
  assert(p.eligible==d.nc&&p.leading==d.nc&&!h.count);
  eng_choose(&e,&d);assert(e.count==TD_SAMPLE&&p.leading>e.count);
  assert(db_row(&d,c,row));
  while(!eng_confident(&e,&d)){
   q=eng_choose(&e,&d);if(q<0)break;
   assert(obs_answer(&h,&e,&d,db_value(row,q)));
  }
  obs_pool(&e,&d,&p);rejections=0;
  while(e.best>=0){
   before=p.leading;i=e.best;eng_reject(&e,&d);rejections++;
   obs_pool(&e,&d,&p);
   assert(e.rejected[i]&&p.eligible==(int)d.nc-rejections);
   assert(p.leading>=0&&p.leading<=p.eligible);
   if(p.leading>before)rises++;
   if(e.best>=0){
    assert(!e.rejected[e.best]);eng_choose(&e,&d);
    assert(e.count<=p.leading&&e.count<=TD_SAMPLE);
    for(j=0;j<e.count;j++)assert(!e.rejected[e.sample[j]]&&
      e.score[e.sample[j]]>=p.cutoff);
   }
  }
  assert(rejections==d.nc&&!p.leading&&!p.eligible);
  eng_reset(&e,&d);obs_reset(&h);obs_pool(&e,&d,&p);
  assert(p.leading==d.nc&&p.eligible==d.nc&&!h.count&&!e.turn);
 }
 printf("PASS: %u real targets; %u complete rejection/reset traversals; %d score-window rises after rejection; sample is not count\n",d.nc,d.nc,rises);
 db_close();return 0;
}
