#include <assert.h>
#include <stdio.h>
#include "OBSERVE.H"
static TDB d;static ENGINE e;static TDHISTORY h;static TDEXPLAIN x;
int main(int argc,char **argv){int q,before;assert(argc==2&&db_open(&d,argv[1]));
 eng_reset(&e,&d);obs_reset(&h);
 for(q=0;q<256;q++){e.current=q;assert(obs_answer(&h,&e,&d,4));}
 assert(h.count==256&&e.turn==256&&obs_explain(&h,&e,&d,&x));
 assert(x.count==256&&x.sum==3072L&&x.leaderScore==1024&&x.otherScore==-2048);
 before=e.turn;e.current=0;assert(!obs_answer(&h,&e,&d,4)&&e.turn==before);
 h.count=257;assert(!obs_answer(&h,&e,&d,4));assert(!obs_explain(&h,&e,&d,&x));
 h.count=256;h.q[1]=h.q[0];assert(!obs_explain(&h,&e,&d,&x));
 obs_reset(&h);eng_reset(&e,&d);e.current=0;assert(!obs_answer(&h,&e,&d,5));assert(!h.count&&!e.turn);
 puts("PASS: all 256 questions retained; 3072 signed margin; overflow, duplicate and invalid input rejected");db_close();return 0;
}
