#define WINVER 0x0300
#include <windows.h>
#include <string.h>
#include "TANDI.H"
#include "ART.H"
#include "TDSOUND.H"
/* Full-screen client, no standard dialogs. All calculations are outside paint. */
static TDB db;
static ENGINE engine;
static HWND window;
static HINSTANCE instance;
static int screenw,screenh,mono,state,focus,debug,help,busy,testmode;
static int lookx,looky,eyeupdates,sx,colors,active=1,artblits;
static HDC artdc;
static HBITMAP artbmp,oldart;
static DWORD artms;
static int animframe=-1,animticks,idleticks,pending,timerok,animredraws,computeticks;
static int animcapture,animserial,tickinside,rejectphase,testreset,testwait;
static DWORD inputready,animcost,computepeak;
static void animpaint(HDC dc);
static void capture(char *path);
static void animset(int frame);
static void nextcompute(void);
static void next(void);
static int inputblocked(void){return busy||(LONG)(GetTickCount()-inputready)<0;}

static struct { BITMAPINFOHEADER h; RGBQUAD c[16]; } artinfo;
/* Driver logical RGB entries intentionally differ from RGBI display values.
   This preserves the source sheet's exact 0..15 hardware color indices. */
static unsigned char rgb[16][3]={{0,0,0},{0,0,128},{0,128,0},{0,128,128},
 {128,0,0},{128,0,128},{128,128,0},{128,128,128},{64,64,64},
 {0,0,255},{0,255,0},{0,255,255},{255,0,0},{255,0,255},
 {255,255,0},{255,255,255}};
static unsigned char monomap[16]={0,0,0,15,0,0,0,15,0,0,15,15,15,15,15,15};
static unsigned char lowmap[16]={0,0,10,10,12,12,12,15,0,0,10,10,12,12,15,15};
static int errors,teststep,wrongguess,finished,testtarget,verified,testinside;
static int wrapfail,wrapmax;
static RECT buttons[6];
static int ids[6],nb;
static char labels[6][24],question[80],name[40],line[100],dbpath[144];
static char debugline[10][80];
static DWORD loadms,answerms,selectms,freespace;
static HFILE logfile=-1;
static U8 truth[TD_ROW];
static char *answers[5]={"YES","PROBABLY","DON'T KNOW",
                             "PROBABLY NOT","NO"};
static void number(char *s,long n){
    char reverse[16];int i=0,j=0;unsigned long u;
    if(n<0){s[j++]='-';u=(unsigned long)(-n);}else u=n;
    do{reverse[i++]=(char)('0'+u%10);u/=10;}while(u);
    while(i)s[j++]=reverse[--i];s[j]=0;
}
static void metric(char *key,long n){
    char s[120],v[20];if(logfile==-1)return;
    number(v,n);lstrcpy(s,key);lstrcat(s,"=");lstrcat(s,v);
    lstrcat(s,"\r\n");_lwrite(logfile,s,lstrlen(s));
}
static void logtext(char *key,char *s){
    if(logfile==-1)return;_lwrite(logfile,key,lstrlen(key));
    _lwrite(logfile,"=",1);_lwrite(logfile,s,lstrlen(s));
    _lwrite(logfile,"\r\n",2);
}
static void text(HDC dc,int x,int y,char *s){TextOut(dc,x,y,s,lstrlen(s));}
static void box(HDC dc,int x,int y,int w,int h,COLORREF color){
    RECT r;HBRUSH b;r.left=x;r.top=y;r.right=x+w;r.bottom=y+h;
    b=CreateSolidBrush(color);FillRect(dc,&r,b);DeleteObject(b);
}
static void frame(HDC dc,int x,int y,int w,int h){
    HBRUSH old;old=SelectObject(dc,GetStockObject(NULL_BRUSH));
    Rectangle(dc,x,y,x+w,y+h);SelectObject(dc,old);
}
static void centered(HDC dc,int y,char *s){
    RECT r;r.left=4;r.right=screenw-4;r.top=y;r.bottom=y+14;
    DrawText(dc,s,-1,&r,DT_CENTER|DT_SINGLELINE|DT_NOPREFIX);
}
static int panelleft(void){return 104*sx;}
static void artfree(void){
    if(artdc){SelectObject(artdc,oldart);DeleteDC(artdc);artdc=0;}
    if(artbmp){DeleteObject(artbmp);artbmp=0;}
}
static int artinit(HDC dc){
    HBITMAP native,old,scaled;HDC source;int i,j;DWORD start;
    start=GetTickCount(); /* Static DIB header begins zeroed; initialized once. */
    artinfo.h.biSize=sizeof(BITMAPINFOHEADER);artinfo.h.biWidth=ART_W;
    artinfo.h.biHeight=ART_H;artinfo.h.biPlanes=1;
    artinfo.h.biBitCount=4;artinfo.h.biSizeImage=sizeof(artbits);
    artinfo.h.biClrUsed=16;
    for(i=0;i<16;i++){
        j=i;
        if(colors==2)j=monomap[i];
        if(colors==4)j=lowmap[i];
        artinfo.c[i].rgbRed=rgb[j][0];artinfo.c[i].rgbGreen=rgb[j][1];
        artinfo.c[i].rgbBlue=rgb[j][2];
    }
    native=CreateDIBitmap(dc,&artinfo.h,CBM_INIT,artbits,(BITMAPINFO FAR *)&artinfo,DIB_RGB_COLORS);
    if(!native)return 0;
    artdc=CreateCompatibleDC(dc);if(!artdc){DeleteObject(native);return 0;}
    artbmp=native;oldart=SelectObject(artdc,artbmp);
    if(sx==2){
        source=CreateCompatibleDC(dc);scaled=CreateCompatibleBitmap(dc,ART_W*2,ART_H);
        if(!source||!scaled){if(source)DeleteDC(source);if(scaled)DeleteObject(scaled);artfree();return 0;}
        old=SelectObject(source,scaled);SetStretchBltMode(source,COLORONCOLOR);
        if(!StretchBlt(source,0,0,ART_W*2,ART_H,artdc,0,0,ART_W,ART_H,SRCCOPY)){
            SelectObject(source,old);DeleteDC(source);DeleteObject(scaled);artfree();return 0;}
        SelectObject(source,old);DeleteDC(source);SelectObject(artdc,oldart);
        DeleteObject(native);artbmp=scaled;SelectObject(artdc,artbmp);
    }
    artms=GetTickCount()-start;return 1;
}
static void sprite(HDC dc,int x,int y,int w,int h,int ax,int ay){
    if(artdc)BitBlt(dc,x,y,w*sx,h,artdc,ax*sx,ay,SRCCOPY);
}
/* Measure every line ourselves: Win3 DrawText can clip an exact-fit word
   wrapped centered line. Spaces are never included in its centering width. */
static void wrapped(HDC dc,char *s,RECT *r){
    char row[100];int n,last,take,width,y=r->top,lines=0;TEXTMETRIC tm;
    GetTextMetrics(dc,&tm);
    while(*s){
        while(*s==' ')s++;if(!*s)break;
        n=0;last=0;
        while(s[n]&&n<98){
            row[n]=s[n];row[n+1]=0;
            width=LOWORD(GetTextExtent(dc,row,n+1));
            if(width>r->right-r->left)break;
            if(s[n]==' ')last=n;n++;
        }
        take=n;
        if(s[n]&&s[n]!=' '&&last)take=last;
        if(!take)take=1;
        n=take;while(n&&s[n-1]==' ')n--;
        for(width=0;width<n;width++)row[width]=s[width];row[n]=0;
        width=LOWORD(GetTextExtent(dc,row,n));
        if(width>r->right-r->left||y+tm.tmHeight>r->bottom){
            if(testmode)wrapfail++;
        }else TextOut(dc,r->left+(r->right-r->left-width)/2,y,row,n);
        y+=tm.tmHeight;lines++;s+=take;
    }
    if(lines>wrapmax)wrapmax=lines;
}
static void ticket(HDC dc,char *s,int y,int h){
    RECT r;int left=panelleft(),width=screenw-left-4*sx;
    box(dc,left,y,width,h,colors<16?RGB(255,255,255):RGB(255,255,0));
    box(dc,left+sx,y+1,width-2*sx,h-2,RGB(255,255,255));
    r.left=left+2*sx;r.right=screenw-6*sx;r.top=y+5;r.bottom=y+h-3;
    SetTextColor(dc,RGB(0,0,0));SetBkColor(dc,RGB(255,255,255));
    wrapped(dc,s,&r);
}
/* Native 3x6 pupil/shadow shapes, restricted to two white 7x9 patches. */
static void eyes(HDC dc){
    int x=6*sx,y=43;
    if(!artdc||state>1||animframe>=0)return;
    box(dc,x+39*sx,y+42,7*sx,9,RGB(255,255,255));
    box(dc,x+47*sx,y+42,7*sx,9,RGB(255,255,255));
    sprite(dc,x+(42+lookx)*sx,y+44+looky,3,6,42,44);
    sprite(dc,x+(49+lookx)*sx,y+44+looky,3,6,49,44);
}
static void look(int x,int y){
    int nx,ny,cx=52*sx;HDC dc;
    nx=(x-cx)/(40*sx);ny=(y-90)/35;
    if(nx>1)nx=1;if(nx<-1)nx=-1;
    if(ny>1)ny=1;if(ny<-1)ny=-1;
    if(nx==lookx&&ny==looky)return;
    lookx=nx;looky=ny;
    if(help||debug||state>1||!active||!artdc)return;
    dc=GetDC(window);eyes(dc);ReleaseDC(window,dc);eyeupdates++;
}
static void mascot(HDC dc){
    int pose=state==2?1:(state==3?2:0);
    sprite(dc,6*sx,43,96,120,0,pose*120);artblits++;
    eyes(dc);animpaint(dc);
}
/* Exact 24x18 face crops from the supplied PARTS sheet. */
static void animpaint(HDC dc){
    if(animframe>=0&&!help&&!debug)
        sprite(dc,41*sx,85,24,18,(animframe%4)*32,416+(animframe/4)*20);
}
static void animset(int frame){
    HDC dc;DWORD started;int pose;char path[30],digits[12];
    if(animframe==frame)return;animframe=frame;
    if(!active||help||debug||!artdc)return;
    started=GetTickCount();dc=GetDC(window);if(!dc)return;
    pose=state==2?1:(state==3?2:0);
    sprite(dc,41*sx,85,24,18,35,42+pose*120);
    eyes(dc);animpaint(dc);ReleaseDC(window,dc);animredraws++;
    started=GetTickCount()-started;if(started>animcost)animcost=started;
    if(testmode&&(teststep>0||testwait<40)&&animserial<120){
        lstrcpy(path,"C:\\AN");number(digits,animserial++);lstrcat(path,digits);lstrcat(path,".BIN");capture(path);
    }
}
static void addbutton(int id,char *label,int x,int y,int w,int h){
    RECT *r=&buttons[nb];r->left=x;r->top=y;r->right=x+w;r->bottom=y+h;
    ids[nb]=id;lstrcpy(labels[nb],label);nb++;
}
static void layout(void){
    int i,left=panelleft(),width=screenw-left-4*sx;nb=0;
    if(help||debug){
        if(debug==1)addbutton(91,"SHOW DEBUG",left,125,width,21);
        addbutton(90,"BACK [ESC]",left,163,width,16);
    }
    else if(state==0)addbutton(10,"BEGIN  [ENTER]",left,122,width,21);
    else if(state==1){
        left+=(width-164*sx)/2;width=164*sx;
        for(i=0;i<5;i++)addbutton(i,answers[i],left,88+18*i,width,16);
    }
    else if(state==2){
        addbutton(20,"YES!  [Y]",left,117,width,21);
        addbutton(21,"NO, TRY AGAIN [N]",left,144,width,21);
    }else if(state==3||(state==4&&!db.error))addbutton(10,"PLAY AGAIN",left,126,width,23);
    else if(state==5){
        addbutton(30,"CONTINUE GUESSING",left,121,width,21);
        addbutton(10,"RESTART",left,148,width,21);
    }
    addbutton(99,"EXIT",screenw-49,183,43,14);
    if(focus>=nb)focus=0;
}
static void draw(HWND w){
    PAINTSTRUCT ps;HDC dc;int i;RECT r;char temp[24];COLORREF gold;
    dc=BeginPaint(w,&ps);SetBkMode(dc,OPAQUE);
    SelectObject(dc,GetStockObject(SYSTEM_FIXED_FONT));
    box(dc,0,0,screenw,screenh,RGB(0,0,0));
    gold=colors<16?RGB(255,255,255):RGB(255,255,0);
    SetTextColor(dc,gold);SetBkColor(dc,RGB(0,0,0));
    if(artdc)sprite(dc,(screenw-126*sx)/2,4,126,16,0,360);
    else centered(dc,5,"TANDINATOR");
    centered(dc,22,help?"HOW TO CONSULT THE ORACLE":(debug?"DIAGNOSTICS - SPOILERS":"THE INCREDIBLE TANDY MIND READER"));
    box(dc,6*sx,35,screenw-12*sx,1,gold);
    box(dc,6*sx,179,screenw-12*sx,1,gold);
    SetTextColor(dc,RGB(255,255,255));
    if(debug||help){
        sprite(dc,screenw-55*sx,40,48,40,debug?48:0,376);
        if(debug==2){for(i=0;i<10;i++)text(dc,8*sx,43+i*11,debugline[i]);}
        else if(debug==1){
            text(dc,8*sx,87,"This shows likely names and scores.");
            text(dc,8*sx,103,"It may spoil the guessing game.");
        }
        else{
            text(dc,8*sx,45,"Think of someone in the roster.");
            text(dc,8*sx,61,"1 Yes  2 Probably  3 Don't know");
            text(dc,8*sx,74,"4 Probably not  5 No");
            text(dc,8*sx,90,"Tab changes focus. Enter chooses.");
            text(dc,8*sx,103,"F2 diagnostics. F3 sound.");
            text(dc,8*sx,119,"Use the version named in the roster.");
            text(dc,8*sx,132,"Unsure? Don't know is always fine.");
            text(dc,8*sx,145,"Esc closes help. Answers not saved.");
        }
    }else{
        r.left=6*sx;r.right=102*sx;r.top=43;r.bottom=163;
        if(RectVisible(dc,&r))mascot(dc);
        if(state==0){
            ticket(dc,"Think of a roster character. Use its named version.",45,64);
        }else if(state==1){
            ticket(dc,question,42,42);
            number(temp,engine.turn+1);lstrcpy(line,"Q ");lstrcat(line,temp);
            SetTextColor(dc,gold);SetBkColor(dc,RGB(0,0,0));text(dc,34*sx,168,line);
        }else if(state==2){
            ticket(dc,"I SUSPECT...",46,20);ticket(dc,name,70,38);
        }else if(state==3){
            ticket(dc,"THE TANDINATOR KNOWS ALL!",48,32);
            number(temp,engine.turn);lstrcpy(line,"Questions asked: ");lstrcat(line,temp);ticket(dc,line,84,27);
        }else if(state==4){
            ticket(dc,db.error?"Cannot read TANDY.DAT. Exit, replace it beside this EXE, then restart.":
                  "You have stumped the silicon oracle! Try another character.",45,65);
        }else if(state==5){
            ticket(dc,"25 questions used. Try another guess, or restart?",45,65);
        }
        if(!artdc){SetTextColor(dc,RGB(255,255,255));text(dc,8,85,"THE ORACLE");text(dc,8,100,"IS LISTENING");}
    }
    for(i=0;i<nb;i++){
        r=buttons[i];if(!RectVisible(dc,&r))continue;
        box(dc,r.left,r.top,r.right-r.left,r.bottom-r.top,gold);
        box(dc,r.left+sx,r.top+1,r.right-r.left-2*sx,r.bottom-r.top-2,RGB(255,255,255));
        SetTextColor(dc,RGB(0,0,0));SetBkColor(dc,RGB(255,255,255));
        r.top+=3;
        if(state==1&&!debug&&!help&&ids[i]>=0&&ids[i]<5){
            number(temp,ids[i]+1);text(dc,r.left+8*sx,r.top,temp);
            r.left+=24*sx;r.right-=8*sx;
        }
        DrawText(dc,labels[i],-1,&r,DT_CENTER|DT_SINGLELINE|DT_NOPREFIX);
        if(i==focus){r=buttons[i];InflateRect(&r,-2,-2);DrawFocusRect(dc,&r);}
    }
    SetTextColor(dc,RGB(255,255,255));SetBkColor(dc,RGB(0,0,0));
    text(dc,8,186,busy?"CONSULTING...":(TdSoundEnabled()?"F1 HELP F2 DEBUG F3 SOUND ON":"F1 HELP F2 DEBUG F3 SOUND OFF"));EndPaint(w,&ps);
}
static void refresh(void){layout();InvalidateRect(window,0,FALSE);UpdateWindow(window);}
static void busyfooter(void){
    HDC dc;dc=GetDC(window);
    SelectObject(dc,GetStockObject(SYSTEM_FIXED_FONT));
    SetTextColor(dc,RGB(255,255,255));SetBkColor(dc,RGB(0,0,0));
    box(dc,8,182,screenw-61,16,RGB(0,0,0));
    text(dc,8,186,"CONSULTING...");ReleaseDC(window,dc);
}
static void questionrefresh(int previousfocus){
    RECT r;layout();
    if(previousfocus>=0&&previousfocus<nb)InvalidateRect(window,&buttons[previousfocus],FALSE);
    InvalidateRect(window,&buttons[0],FALSE);
    r.left=panelleft();r.right=screenw-4*sx;r.top=42;r.bottom=84;
    InvalidateRect(window,&r,FALSE);
    r.left=6*sx;r.right=102*sx;r.top=164;r.bottom=177;
    InvalidateRect(window,&r,FALSE);
    r.left=8;r.right=screenw-53;r.top=182;r.bottom=199;
    InvalidateRect(window,&r,FALSE);UpdateWindow(window);
}
static void capture(char *path){
    HFILE f;f=_lcreat(path,0);if(f!=-1){
        _lwrite(f,(const void FAR *)0xb8000000L,32768U);_lclose(f);
    }
}
static void debugupdate(void){
    int i,j,b,used[5];char nm[40],num[20];
    for(i=0;i<5;i++){
        b=-1;for(j=0;j<(int)db.nc;j++){
            int k,skip=engine.rejected[j];for(k=0;k<i;k++)if(used[k]==j)skip=1;
            if(!skip&&(b<0||engine.score[j]>engine.score[b]))b=j;
        }
        used[i]=b;debugline[i][0]=0;
        if(b>=0){db_name(&db,b,nm);number(num,engine.score[b]);
            lstrcpy(debugline[i],nm);lstrcat(debugline[i],"  ");lstrcat(debugline[i],num);}
    }
    lstrcpy(debugline[5],"Split Y/N/U: ");number(num,engine.yesw);
    lstrcat(debugline[5],num);lstrcat(debugline[5],"/");number(num,engine.now);
    lstrcat(debugline[5],num);lstrcat(debugline[5],"/");number(num,engine.unknownw);
    lstrcat(debugline[5],num);
    lstrcpy(debugline[6],"Utility: ");number(num,engine.utility);lstrcat(debugline[6],num);
    lstrcpy(debugline[7],"Load/answer/select ms: ");number(num,loadms);
    lstrcat(debugline[7],num);lstrcat(debugline[7],"/");number(num,answerms);
    lstrcat(debugline[7],num);lstrcat(debugline[7],"/");number(num,selectms);
    lstrcat(debugline[7],num);
    lstrcpy(debugline[8],"Rows examined: ");number(num,engine.examined);lstrcat(debugline[8],num);
    lstrcpy(debugline[9],"Emulator timing; not physical 8088.");
}
static void nextcompute(void){
    DWORD start;int previous=state,previousfocus=focus;TdSoundStop(window);busy=1;busyfooter();start=GetTickCount();
    if(eng_confident(&engine,&db)){state=2;db_name(&db,engine.best,name);}
    else if(eng_choose(&engine,&db)<0){
        state=(engine.best<0||db.error)?4:2;
        if(state==2)db_name(&db,engine.best,name);
    }else {state=1;db_question(&db,engine.current,question);}
    selectms=GetTickCount()-start;metric("SELECT_MS",selectms);
    if(selectms>computepeak)computepeak=selectms;
    metric("SAMPLE",engine.count);metric("ROWS",engine.examined);
    if(db.error)state=4;busy=0;focus=0;pending=0;
    animset(-1);animticks=0;idleticks=0;
    inputready=GetTickCount()+220;
    if(state==2)animframe=1;
    if(state==4)TdSoundBegin(window,TD_SND_WRONG,GetTickCount());
    if(previous==1&&state==1&&engine.turn>0){
        previous=artblits;questionrefresh(previousfocus);
        metric("QUESTION_CABINET_UNTOUCHED",previous==artblits);
    }else refresh();
    inputready=GetTickCount()+220;
    if(state==2)TdSoundBegin(window,TD_SND_REVEAL,GetTickCount());
}
/* Responsive pre-compute phase; the unchanged engine itself is synchronous. */
static void next(void){
    if(!timerok){nextcompute();return;}
    busy=1;pending=1;animticks=0;idleticks=0;computeticks=rejectphase?5:3;busyfooter();
    animset(rejectphase?7:6);rejectphase=0;
}
static void animtick(void){
    static int reveal[5]={1,2,1,4,-1};
    static int victory[5]={3,4,3,4,3};
    if(!active||help||debug)return;
    TdSoundTick(window,GetTickCount());
    if(pending){
        animticks++;
        if(animticks==1)animset(8);
        else if(animticks==2)animset(9);
        else if(animticks>=computeticks){TdSoundStop(window);nextcompute();}
        return;
    }
    if(state==2||state==3){
        if(animticks<10){animticks++;if(!(animticks%2))
            animset(state==2?reveal[animticks/2-1]:victory[animticks/2-1]);}
    }else if(state<=1){
        idleticks++;
        if(idleticks==36)animset(0);
        if(idleticks>=38){animset(-1);idleticks=0;}
    }
}
static void act(int id){
    DWORD start;
    if(id==99){SendMessage(window,WM_CLOSE,0,0);return;}
    if(inputblocked())return;
    if(id==90){debug=help=0;refresh();return;}
    if(id==91&&debug==1){debug=2;debugupdate();focus=0;refresh();inputready=GetTickCount()+220;return;}
    if(id==30&&state==5){next();return;}
    if(id==10){
        if(db.error){state=4;refresh();return;}
        TdSoundStop(window);eng_reset(&engine,&db);state=1;next();return;
    }
    if(id>=0&&id<5&&state==1){
        TdSoundStop(window);start=GetTickCount();
        if(!eng_answer(&engine,&db,4-id))state=4;
        answerms=GetTickCount()-start;metric("ANSWER_MS",answerms);
        if(state!=4)next();else refresh();return;
    }
    if(state==2&&id==20){state=3;animticks=0;animframe=3;
        refresh();inputready=GetTickCount()+220;TdSoundBegin(window,TD_SND_VICTORY,GetTickCount());return;}
    if(state==2&&id==21){
        eng_reject(&engine,&db);
        if(engine.turn>=25){
            state=engine.best<0?4:5;busy=pending=0;animticks=0;animframe=-1;
            focus=0;refresh();inputready=GetTickCount()+220;
            TdSoundBegin(window,TD_SND_WRONG,GetTickCount());return;
        }
        rejectphase=1;TdSoundBegin(window,TD_SND_WRONG,GetTickCount());next();
    }
}
/* Deterministic fixture setup; inputs under test still use production handlers. */
static void testprepare(void){
    busy=pending=0;inputready=0;eng_reset(&engine,&db);state=1;
    nextcompute();inputready=0;
}
static void soundtest(void){
    WNDCLASS c;HWND peer;TDSNDSTAT before,after;int result;
    TdSoundStop(window);TdSoundGetStats(&before);
    c.style=0;c.lpfnWndProc=DefWindowProc;c.cbClsExtra=c.cbWndExtra=0;
    c.hInstance=instance;c.hIcon=0;c.hCursor=0;c.hbrBackground=0;
    c.lpszMenuName=0;c.lpszClassName="TandyStartupChime";
    if(RegisterClass(&c)){
        peer=CreateWindow(c.lpszClassName,"Busy test",WS_POPUP,0,0,0,0,0,0,instance,0);
        if(peer){result=TdSoundBegin(window,TD_SND_REVEAL,GetTickCount());
            TdSoundTick(window,GetTickCount());TdSoundGetStats(&after);
            metric("SOUND_BUSY_SILENT",result==TD_SND_BUSY&&after.portWrites==before.portWrites);
            DestroyWindow(peer);}
        UnregisterClass(c.lpszClassName,instance);
    }
    TdSoundEnable(0);TdSoundGetStats(&before);
    result=TdSoundBegin(window,TD_SND_VICTORY,GetTickCount());
    TdSoundTick(window,GetTickCount());TdSoundGetStats(&after);
    metric("SOUND_OFF_SILENT",result==TD_SND_DISABLED&&before.portWrites==after.portWrites);
    TdSoundEnable(1);
    result=TdSoundBegin(window,TD_SND_REVEAL,GetTickCount());TdSoundTick(window,GetTickCount());
    SendMessage(window,WM_ACTIVATEAPP,0,0);TdSoundGetStats(&after);
    metric("SOUND_FOCUS_RELEASE",result==TD_SND_STARTED&&!after.playing&&!FindWindow("TandyPSGTest",0));
    SendMessage(window,WM_ACTIVATEAPP,1,0);inputready=0;
}
static void layouttest(void){
    int i,j,bestq=0,bestn=0,maxq=0,maxn=0,turn,ok=1;char q[80],nm[40];
    HDC dc;RECT r;
    dc=GetDC(window);SelectObject(dc,GetStockObject(SYSTEM_FIXED_FONT));
    /* Same rectangles as tickets, but an empty clip avoids transient screens. */
    IntersectClipRect(dc,0,0,0,0);
    r.left=panelleft()+2*sx;r.right=screenw-6*sx;r.top=47;r.bottom=81;
    for(i=0;i<(int)db.nq;i++){
        db_question(&db,i,q);wrapped(dc,q,&r);
        if(lstrlen(q)>maxq){maxq=lstrlen(q);bestq=i;}
    }
    r.top=75;r.bottom=105;
    for(i=0;i<(int)db.nc;i++){
        db_name(&db,i,nm);wrapped(dc,nm,&r);
        if(lstrlen(nm)>maxn){maxn=lstrlen(nm);bestn=i;}
    }
    ReleaseDC(window,dc);
    metric("ALL_QUESTIONS_CHECKED",db.nq);metric("ALL_NAMES_CHECKED",db.nc);
    metric("WRAP_FAILURES",wrapfail);metric("MAX_TEXT_LINES",wrapmax);
    state=1;lstrcpy(question,"Is your character strongly associated with movies?");
    refresh();capture("C:\\CLIPFIX.BIN");
    db_question(&db,bestq,question);refresh();capture("C:\\LONGQ.BIN");
    state=2;db_name(&db,bestn,name);refresh();capture("C:\\LONGNAME.BIN");
    for(i=0;i<5;i++){
        testprepare();turn=engine.turn;SendMessage(window,WM_KEYDOWN,'1'+i,0);
        if(engine.turn!=turn+1)ok=0;
        for(j=0;j<2;j++){
            testprepare();turn=engine.turn;
            SendMessage(window,WM_LBUTTONDOWN,0,MAKELONG(
                j?buttons[i].right-1:buttons[i].left,
                j?buttons[i].bottom-1:buttons[i].top));
            if(engine.turn!=turn+1)ok=0;
        }
    }
    testprepare();turn=engine.turn;
    SendMessage(window,WM_LBUTTONDOWN,0,MAKELONG(buttons[0].left-1,buttons[0].top+5));
    if(engine.turn!=turn)ok=0;
    metric("FIVE_KEYS_TEN_CORNERS_OUTSIDE",ok);
    testprepare();turn=engine.turn;
    SendMessage(window,WM_KEYDOWN,VK_RETURN,0x40000000L);
    metric("HELD_KEY_IGNORED",engine.turn==turn);
    SendMessage(window,WM_KEYDOWN,VK_RETURN,0);
    turn=engine.turn;SendMessage(window,WM_KEYDOWN,VK_RETURN,0);
    SendMessage(window,WM_LBUTTONDOWN,0,MAKELONG(buttons[0].left+2,buttons[0].top+2));
    metric("BUSY_INPUT_IGNORED",engine.turn==turn&&pending);
    busy=pending=0;state=2;focus=0;animticks=10;inputready=0;refresh();
    SendMessage(window,WM_LBUTTONDOWN,0,MAKELONG(210*sx,130));
    SendMessage(window,WM_LBUTTONDOWN,0,MAKELONG(210*sx,130));
    SendMessage(window,WM_LBUTTONDBLCLK,0,MAKELONG(210*sx,130));
    metric("DOUBLE_CLICK_STAYS_SUCCESS",state==3);
    if(!ok||wrapfail)errors++;
    testprepare();
}
static void usabilitytest(void){
    int turn,leader,i;TDSNDSTAT soundstats;
    testprepare();turn=engine.turn;
    SendMessage(window,WM_KEYDOWN,VK_F1,0);
    SendMessage(window,WM_KEYDOWN,VK_ESCAPE,0);
    metric("ESC_HELP_PRESERVED",!help&&!debug&&engine.turn==turn&&IsWindow(window));
    inputready=0;SendMessage(window,WM_KEYDOWN,VK_F2,0);
    metric("DEBUG_WARNING_FIRST",debug==1&&ids[0]==91);capture("C:\\WARN.BIN");
    SendMessage(window,WM_KEYDOWN,VK_ESCAPE,0);metric("ESC_DEBUG_PRESERVED",!debug&&engine.turn==turn);
    inputready=0;SendMessage(window,WM_KEYDOWN,VK_F2,0);act(91);
    metric("DEBUG_EXPLICIT_REVEAL",debug==2);SendMessage(window,WM_KEYDOWN,VK_ESCAPE,0);
    testprepare();while(engine.turn<25){eng_choose(&engine,&db);eng_answer(&engine,&db,2);}
    nextcompute();inputready=0;leader=engine.best;act(21);
    metric("LIMIT_REJECTION_GATE",state==5&&!pending&&engine.rejected[leader]);capture("C:\\CONTINUE.BIN");
    leader=engine.best;turn=engine.turn;
    for(i=0;i<6;i++)animtick();
    metric("GATE_NO_AUTO_GUESS",state==5&&!pending&&engine.best==leader&&engine.turn==turn);
    inputready=0;act(30);nextcompute();
    metric("EXPLICIT_CONTINUE",state==2&&engine.turn==25&&engine.best==leader);
    inputready=0;act(21);inputready=0;act(10);
    metric("GATE_RESTART",state==1&&engine.turn==0);
    busy=pending=0;TdSoundStop(window);db.error=1;state=4;refresh();
    metric("BAD_DAT_EXIT_ONLY",nb==1&&ids[0]==99);capture("C:\\BADDB.BIN");
    db.error=0;testprepare();
}
static void testtick(void){
    int answer,i,turnsaved,statesaved,lx,ly;char nm[40],target[40];RECT damage;HWND peer;HDC testdc;
    if(inputblocked())return;
    if(db.error){
        metric("BAD_DAT_EXIT_ONLY",state==4&&nb==1&&ids[0]==99);
        capture("C:\\BADDB.BIN");metric("APP_ERROR",db.error);metric("ERRORS",1);metric("COMPLETE",1);
        KillTimer(window,1);SendMessage(window,WM_CLOSE,0,0);return;
    }
    if(testreset){testreset=0;act(10);return;}
    if((state==2||state==3)&&animticks<10)return;
    if(teststep==0&&testwait++<40)return;
    if(teststep==0){
        lx=lookx;ly=looky;lookx=looky=0;testdc=GetDC(window);eyes(testdc);
        capture("C:\\NATIVE.BIN");lookx=lx;looky=ly;eyes(testdc);ReleaseDC(window,testdc);
        capture("C:\\WELCOME.BIN");
        peer=CreateWindow("STATIC","TANDI focus check",WS_OVERLAPPEDWINDOW,
                          20,50,140,70,0,0,instance,0);
        if(peer){
            statesaved=state;turnsaved=engine.turn;ShowWindow(peer,SW_SHOW);UpdateWindow(peer);
            metric("FOCUS_OTHER_WINDOW",GetActiveWindow()==peer);
            SetActiveWindow(window);BringWindowToTop(window);UpdateWindow(window);
            SetActiveWindow(window);BringWindowToTop(window);DestroyWindow(peer);UpdateWindow(window);
            metric("FOCUS_RETURNED",GetActiveWindow()==window);
            metric("FOCUS_STATE_PRESERVED",state==statesaved&&engine.turn==turnsaved);
            capture("C:\\FOCUS.BIN");
        }
        damage.left=screenw-6;damage.top=100;
        damage.right=screenw-2;damage.bottom=120;
        InvalidateRect(window,&damage,FALSE);UpdateWindow(window);
        damage.left=100;damage.top=174;damage.right=125;damage.bottom=180;
        InvalidateRect(window,&damage,FALSE);UpdateWindow(window);
        capture("C:\\EXPOSE.BIN");
        look(0,0);capture("C:\\EYELEFT.BIN");
        look(screenw-1,screenh-1);capture("C:\\EYERIGHT.BIN");
        i=eyeupdates;look(screenw-1,screenh-1);
        metric("UNCHANGED_MOUSE_NO_REDRAW",i==eyeupdates);
        metric("EYE_REDRAWS",eyeupdates);
        GetProfileString("TANDINATOR","TestTarget","Mario",target,sizeof(target));
        for(i=0;i<(int)db.nc;i++){db_name(&db,i,nm);if(!lstrcmp(nm,target)){testtarget=i;break;}}
        metric("TARGET_FOUND",i<(int)db.nc);
        db_name(&db,testtarget,nm);logtext("TARGET_NAME",nm);
        db_row(&db,testtarget,truth);
        soundtest();inputready=0;SendMessage(window,WM_KEYDOWN,VK_F1,0);capture("C:\\HELP.BIN");
        SendMessage(window,WM_KEYDOWN,VK_F1,0);
        SendMessage(window,WM_KEYDOWN,VK_F2,0);
        SendMessage(window,WM_KEYDOWN,VK_F2,0);
        metric("OVERLAYS_PRESERVE_STATE",state==0&&engine.turn==0);
        SendMessage(window,WM_KEYDOWN,VK_TAB,0);
        metric("TAB_FOCUS_MOVED",focus==1);
        SendMessage(window,WM_KEYDOWN,VK_TAB,0);
        SendMessage(window,WM_KEYDOWN,VK_RETURN,0);layouttest();usabilitytest();teststep++;return;
    }
    if(state==1){
        if(!verified){capture("C:\\QUESTION.BIN");verified=1;}
        else if(verified==1&&engine.turn>0){
            capture("C:\\PARTIAL.BIN");refresh();
            capture("C:\\FULLDRAW.BIN");verified=2;
        }
        answer=db_value(truth,engine.current);
        if(engine.turn==0){
            SendMessage(window,WM_KEYDOWN,VK_TAB,0);
            SendMessage(window,WM_KEYDOWN,VK_TAB,0);
            i=4-answer;
            SendMessage(window,WM_LBUTTONDOWN,0,
                MAKELONG((buttons[i].left+buttons[i].right)/2,
                         (buttons[i].top+buttons[i].bottom)/2));
        }else SendMessage(window,WM_KEYDOWN,(WORD)('1'+4-answer),0);
        return;
    }
    if(state==2){
        logtext("GUESS",name);metric("QUESTIONS",engine.turn);
        capture("C:\\GUESS.BIN");
        if(engine.best==testtarget){
            if(!wrongguess){
                /* Exercise explicit rejection and prove another guess/question. */
                SendMessage(window,WM_KEYDOWN,'N',0);metric("REJECTION_CONTINUED",state==1||state==2);
                wrongguess=1;testreset=1;return;
            }
            SendMessage(window,WM_KEYDOWN,'Y',0);capture("C:\\SUCCESS.BIN");
            metric("TARGET_SUCCESS",state==3);finished=1;
        }else {act(21);if(++errors>10)finished=1;}
    }
    if(state==5){metric("TEST_CONTINUE_GATE",1);act(30);return;}
    if(state==4){metric("APP_ERROR",db.error);errors++;finished=1;}
    if(finished){
        TDSNDSTAT soundstats;
        if(inputblocked())return;
        TdSoundGetStats(&soundstats);
        metric("SOUND_STARTS_REVEAL",soundstats.starts[0]);
        metric("SOUND_STARTS_VICTORY",soundstats.starts[1]);
        metric("SOUND_STARTS_WRONG",soundstats.starts[2]);
        metric("SOUND_COMPLETE_REVEAL",soundstats.completions[0]);
        metric("SOUND_COMPLETE_VICTORY",soundstats.completions[1]);
        metric("SOUND_COMPLETE_WRONG",soundstats.completions[2]);
        metric("SOUND_BUSY_SKIPS",soundstats.busySkips);
        metric("SOUND_WRITES",soundstats.portWrites);
        metric("SOUND_LATE_ABORTS",soundstats.lateAborts);
        metric("SOUND_FAILURES",soundstats.failures);
        debug=2;debugupdate();refresh();capture("C:\\DEBUG.BIN");debug=0;
        if(state==3){
            refresh();
            SendMessage(window,WM_LBUTTONDOWN,0,
                MAKELONG((buttons[0].left+buttons[0].right)/2,
                         (buttons[0].top+buttons[0].bottom)/2));
            metric("MOUSE_REPLAY_STARTED",state==1&&engine.turn==0);
        }
        metric("ANIM_CAPTURES",animserial);metric("ANIM_REDRAWS",animredraws);metric("ANIM_MAX_MS",animcost);
        metric("COMPUTE_MAX_MS",computepeak);
        metric("DB_BYTES",db.bytes);metric("DB_SEEKS",db.seeks);
        metric("FREE_SPACE_AFTER",GetFreeSpace(0));
        metric("ERRORS",errors);metric("COMPLETE",1);
        KillTimer(window,1);
        i=GetProfileInt("TANDINATOR","TestExit",0);metric("EXIT_METHOD",i);
        if(i==1)SendMessage(window,WM_KEYDOWN,VK_ESCAPE,0);
        else if(i==2)SendMessage(window,WM_SYSCOMMAND,SC_CLOSE,0);
        else if(i==3)SendMessage(window,WM_LBUTTONDOWN,0,
            MAKELONG((buttons[nb-1].left+buttons[nb-1].right)/2,
                     (buttons[nb-1].top+buttons[nb-1].bottom)/2));
        else SendMessage(window,WM_CLOSE,0,0);
    }
}
LONG FAR PASCAL WndProc(HWND w,UINT msg,WORD wp,LONG lp){
    int i,x,y;
    if(msg==WM_KILLFOCUS||(msg==WM_ACTIVATE&&wp==0))TdSoundStop(window);
    if(msg==WM_QUERYENDSESSION){TdSoundStop(window);return 1;}
    if(msg==WM_ENDSESSION&&wp){TdSoundStop(window);return 0;}
    if(msg==WM_CLOSE)TdSoundStop(window);
    if(msg==WM_PAINT){draw(w);return 0;}
    if(msg==WM_TIMER){
        if(wp==2&&!tickinside){tickinside=1;animtick();tickinside=0;}
        if(wp==1&&testmode&&!testinside){testinside=1;testtick();testinside=0;}
        return 0;
    }
    if(msg==WM_ACTIVATEAPP){active=wp!=0;
        if(!active)TdSoundStop(window);else {inputready=GetTickCount()+220;refresh();}return 0;}
    if(msg==WM_MOUSEMOVE){look(LOWORD(lp),HIWORD(lp));return 0;}
    if(msg==WM_LBUTTONDOWN){
        x=LOWORD(lp);y=HIWORD(lp);
        if(x>=screenw-49&&x<screenw-6&&y>=183&&y<197){act(99);return 0;}
        if(inputblocked())return 0;
        for(i=0;i<nb;i++)if(x>=buttons[i].left&&x<buttons[i].right&&
           y>=buttons[i].top&&y<buttons[i].bottom){
            if(focus>=0&&focus<nb)InvalidateRect(w,&buttons[focus],FALSE);
            focus=i;act(ids[i]);break;
        }
        return 0;
    }
    if(msg==WM_KEYDOWN){
        if(lp&0x40000000L)return 0;
        if(wp==VK_F3){TdSoundEnable(!TdSoundEnabled());refresh();return 0;}
        if(wp==VK_ESCAPE){
            if(help||debug){help=debug=0;focus=0;refresh();inputready=GetTickCount()+220;return 0;}
            SendMessage(w,WM_CLOSE,0,0);return 0;
        }
        if(inputblocked())return 0;
        if(wp==VK_F1){TdSoundStop(window);help=!help;debug=0;focus=0;refresh();return 0;}
        if(wp==VK_F2){TdSoundStop(window);debug=debug?0:1;help=0;focus=0;refresh();return 0;}
        if(wp==VK_TAB){if(nb){
            InvalidateRect(w,&buttons[focus],FALSE);
            focus=(focus+(GetKeyState(VK_SHIFT)<0?nb-1:1))%nb;
            InvalidateRect(w,&buttons[focus],FALSE);UpdateWindow(w);
        }return 0;}
        if(wp==VK_RETURN||wp==VK_SPACE){if(nb)act(ids[focus]);return 0;}
        if(!debug&&!help&&state==1&&wp>='1'&&wp<='5'){act(wp-'1');return 0;}
        if(!debug&&!help&&state==2&&(wp=='Y'||wp=='N'))act(wp=='Y'?20:21);
        return 0;
    }
    if(msg==WM_DESTROY){KillTimer(window,2);TdSoundStop(window);artfree();db_close();if(logfile!=-1)_lclose(logfile);PostQuitMessage(0);return 0;}
    return DefWindowProc(w,msg,wp,lp);
}
int PASCAL WinMain(HANDLE inst,HANDLE prev,LPSTR cmd,int show){
    WNDCLASS c;MSG msg;HDC dc;DWORD start;int i,len;
    instance=inst;(void)prev;
    while(*cmd==' ')cmd++;
    testmode=(*cmd=='/'&&cmd[1]=='T')||GetProfileInt("TANDINATOR","Test",0);
    GetModuleFileName(inst,dbpath,sizeof(dbpath));len=lstrlen(dbpath);
    for(i=len-1;i>=0;i--)if(dbpath[i]=='\\'||dbpath[i]==':')break;
    lstrcpy(dbpath+i+1,"TANDY.DAT");
    freespace=GetFreeSpace(0);start=GetTickCount();db_open(&db,dbpath);
    loadms=GetTickCount()-start;if(db.error)state=4;
    if(testmode)logfile=_lcreat("C:\\TANDI.LOG",0);
    metric("WINFLAGS",GetWinFlags());metric("LOAD_MS",loadms);
    metric("ENGINE_BYTES",sizeof(engine));metric("DB_STRUCT_BYTES",sizeof(db));
    metric("FREE_SPACE_BEFORE",freespace);metric("CHARACTERS",db.nc);
    metric("QUESTIONS_AVAILABLE",db.nq);
    screenw=GetSystemMetrics(SM_CXSCREEN);screenh=GetSystemMetrics(SM_CYSCREEN);
    metric("WIDTH",screenw);metric("HEIGHT",screenh);
    c.style=CS_DBLCLKS;c.lpfnWndProc=WndProc;c.cbClsExtra=c.cbWndExtra=0;
    c.hInstance=inst;c.hIcon=0;c.hCursor=LoadCursor(0,IDC_ARROW);
    c.hbrBackground=GetStockObject(BLACK_BRUSH);c.lpszMenuName=0;
    c.lpszClassName="Tandinator02";if(!RegisterClass(&c))return 1;
    window=CreateWindow(c.lpszClassName,"TANDINATOR",WS_POPUP,0,0,
                        screenw,screenh,0,0,inst,0);
    if(!window){db_close();return 1;}
    sx=screenw>=640?2:1;
    dc=GetDC(window);colors=GetDeviceCaps(dc,NUMCOLORS);mono=colors==2;
    metric("ART_READY",artinit(dc));ReleaseDC(window,dc);
    metric("ART_INIT_MS",artms);metric("ART_DIB_BYTES",sizeof(artbits));
    metric("FREE_SPACE_ART",GetFreeSpace(0));
    layout();ShowWindow(window,show);UpdateWindow(window);
    timerok=SetTimer(window,2,100,0)!=0;
    metric("ANIM_TIMER_READY",timerok);metric("SOUND_READY",TdSoundInit(window,inst,timerok));refresh();
    if(testmode)SetTimer(window,1,100,0);
    while(GetMessage(&msg,0,0,0)){TranslateMessage(&msg);DispatchMessage(&msg);}
    TdSoundStop(window);KillTimer(window,2);return msg.wParam;
}
