/* Exhaustive bounded-state checks; no GUI or heap in shared runtime. */
#include <stdio.h>
#include <string.h>
#include "../src/TANDI.H"
static TDB db;
static struct { U32 before; ENGINE e; U32 after; } guarded;
static struct { U32 before; U8 row[TD_ROW]; U32 after; } row;
static struct { U32 before; U8 col[TD_COL]; U32 after; } col;
#define MARK 0x80880888UL
#define CHECK(x) do { if(!(x)){printf("FAIL line %d: %s\n",__LINE__,#x);return 1;} } while(0)
int main(int argc,char **argv){
    int a,q,c;long checks=0;ENGINE *e=&guarded.e;
    if(argc!=2)return 2;
    CHECK(db_open(&db,argv[1]));
    guarded.before=guarded.after=row.before=row.after=col.before=col.after=MARK;
    for(c=0;c<(int)db.nc;c++){CHECK(db_row(&db,c,row.row));CHECK(row.before==MARK&&row.after==MARK);checks++;}
    for(q=0;q<(int)db.nq;q++){CHECK(db_column(&db,q,col.col));CHECK(col.before==MARK&&col.after==MARK);checks++;}
    for(a=0;a<5;a++){
        eng_reset(e,&db);
        for(q=0;q<(int)db.nq;q++){
            e->current=q;CHECK(eng_answer(e,&db,a));
            CHECK(e->turn==q+1);CHECK(e->asked[q]);
            for(c=0;c<(int)db.nc;c++){CHECK(e->score[c]>=-8*(q+1)&&e->score[c]<=4*(q+1));checks++;}
            CHECK(!eng_answer(e,&db,a));
            CHECK(guarded.before==MARK&&guarded.after==MARK);
        }
        CHECK(eng_choose(e,&db)==-1);
        for(c=0;c<(int)db.nc;c++)eng_reject(e,&db);
        CHECK(e->best==-1&&e->second==-1);CHECK(eng_choose(e,&db)==-1);CHECK(!eng_confident(e,&db));
    }
    eng_reset(e,&db);CHECK(eng_choose(e,&db)>=0);CHECK(e->count<=TD_SAMPLE&&e->count>0);
    CHECK(guarded.before==MARK&&guarded.after==MARK);
    printf("Bounded-state checks passed: %ld; characters=%u questions=%u host_engine_bytes=%lu\n",checks,db.nc,db.nq,(unsigned long)sizeof(*e));
    db_close();return 0;
}
