/* Host-only interface to the verbatim C89 runtime engine for uncertainty tests. */
#include "../src/TANDI.H"
static TDB db;static ENGINE engine;
static unsigned long rng;
static unsigned next_rand(void){rng=(rng*1664525UL+1013904223UL)&0xffffffffUL;return (unsigned)((rng>>16)&65535UL);}
int sim_open(const char *path){return db_open(&db,path);}
void sim_close(void){db_close();}
/* answers is an independently supplied source row, not read from target. */
int sim_case(int target,const short *answers,int policy,unsigned seed,int *out){
    int q,a,tries=0,rank=0,i,altered=0,unknown=0,soft=0,flip=0;
    rng=seed;eng_reset(&engine,&db);
    for(;;){
        q=eng_confident(&engine,&db)?-1:eng_choose(&engine,&db);
        if(q<0){
            if(engine.best==target||engine.best<0||tries>=10)break;
            tries++;eng_reject(&engine,&db);continue;
        }
        a=answers[q];
        if(a<0||a>4)return 0;
        if(policy==1||policy==2){
            unsigned r=next_rand()%100;
            if(r<15){if(a!=2)unknown++;a=2;}
            else if(r<20&&policy==2){if(a!=2)flip++;a=4-a;}
            else if(r<45){if(a==0){a=1;soft++;}else if(a==4){a=3;soft++;}}
        }else if(policy>=100&&engine.turn==policy-100&&a!=2){a=4-a;flip++;}
        if(a!=answers[q])altered++;
        if(!eng_answer(&engine,&db,a))return 0;
    }
    for(i=0;i<(int)db.nc;i++)if(engine.score[i]>engine.score[target]||
        (engine.score[i]==engine.score[target]&&i<target))rank++;
    out[0]=engine.best==target;out[1]=engine.turn;out[2]=tries;out[3]=rank+1;
    out[4]=altered;out[5]=unknown;out[6]=soft;out[7]=flip;out[8]=engine.score[target];
    out[9]=engine.best<0?-1:engine.score[engine.best];
    return 1;
}
