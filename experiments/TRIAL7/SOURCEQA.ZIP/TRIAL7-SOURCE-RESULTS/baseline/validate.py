#!/usr/bin/env python3
"""Read-only validation and reporting of complete baseline runs.
Uses explicit physical VRAM layouts, no driver or rendering imports.
"""
from pathlib import Path
import json,re,statistics,hashlib,sys
from PIL import Image,ImageDraw
P=Path(__file__).resolve().parent
NAMES=['BORDER_1PX','BORDER_2PX','TEXT_AWAY','TEXT_OVER','DIB_16_AWAY','DIB_16_OVER','DIB_80_AWAY','DIB_FULL_OVER']
PROFILES={'160x200x16':(160,16,2,80),'320x200x16':(320,16,4,160),'320x200x4':(320,4,2,80),'640x200x4':(640,4,4,160),'640x200x2':(640,2,2,80)}
def parse(s):
 parts=re.split(r'(?m)^CASE=',s);meta=dict((k,int(v)) for k,v in re.findall(r'(?m)^(\w+)=(\d+)',parts[0]));rows=[]
 for part in parts[1:]:
  lines=part.splitlines();rows.append({'CASE':int(lines[0]),**{k:int(v) for k,v in re.findall(r'(?m)^(\w+)=(\d+)',part)}})
 return meta,rows

def decode(raw,profile):
 w,c,banks,pitch=profile;out=bytearray(w*200);bpp={16:4,4:2,2:1}[c]
 for y in range(200):
  base=(y%banks)*8192+(y//banks)*pitch
  for x in range(w):
   if w==640 and c==4:
    a=base+2*(x//8);v=((raw[a]>>(7-x%8))&1)|(((raw[a+1]>>(7-x%8))&1)<<1)
   else:v=raw[base+x//(8//bpp)]>>((8//bpp-1-x%(8//bpp))*bpp)&(c-1)
   out[y*w+x]=v
 return out

def validate(mode):
 p=P/mode;result=json.loads((p/'RESULT.json').read_text());g=p/'guest';meta,rows=parse(result['log']);w,c,banks,pitch=PROFILES[mode]
 checks={'run_complete':result['completed'],'dos_return':result['dos_return'].strip()=='RETURNED','real_mode_8086':meta['FLAGS']==64,'geometry':meta['WIDTH']==w and meta['HEIGHT']==200 and meta['COLORS']==c,'24_batches':len(rows)==24,'zero_failures':'FAILURES=0' in result['log'],'all_api_returns':all(r['GOOD']==r['CALLS'] for r in rows),'batches_at_least_1sec':all(r['MS']>=1000 for r in rows)}
 frames={n:(g/(n+'.BIN')).read_bytes() for n in ['PRE','DRAW','CLEAN','RESHOW']};checks['snapshot_lengths']=all(len(b)==24*32768 for b in frames.values());details=[]
 visible={a for y in range(200) for a in range((y%banks)*8192+(y//banks)*pitch,(y%banks)*8192+(y//banks)*pitch+pitch)};padding=set(range(banks*8192))-visible
 cleanrows=[]
 for i,r in enumerate(rows):
  raw={n:b[i*32768:(i+1)*32768] for n,b in frames.items()};decoded={n:decode(v,PROFILES[mode]) for n,v in raw.items()};base=decoded['CLEAN'];k=r['KIND'];cleanrows.append(raw['CLEAN']);diff=[j for j,(a,b) in enumerate(zip(decoded['DRAW'],base)) if a!=b];xs=[j%w for j in diff];ys=[j//w for j in diff]
  rec={'case':i,'kind':NAMES[k],'cursor_pixels':len(diff),'cursor_bbox':[min(xs),min(ys),max(xs),max(ys)] if diff else None,'cursor_visible':bool(diff),'cursor_restores_exactly':raw['DRAW']==raw['RESHOW'],'cursor_local':bool(diff) and min(xs)>=r['CURSOR_X']-2 and min(ys)>=r['CURSOR_Y']-2 and max(xs)<r['CURSOR_X']+32 and max(ys)<r['CURSOR_Y']+32,'bank_padding_preserved':all(raw['PRE'][a]==raw['CLEAN'][a] for a in padding),'only_black_white':set(base)<={0,c-1}}
  lit=[j for j,v in enumerate(base) if v];rec['lit_pixels']=len(lit);rec['drawing_present']=bool(lit)
  if lit:rec['drawing_bbox']=[min(j%w for j in lit),min(j//w for j in lit),max(j%w for j in lit),max(j//w for j in lit)]
  if k>=4:
   dw,dh=r['DIB_WIDTH'],r['DIB_HEIGHT'];expected=bytearray(w*200)
   for y in range(dh):
    for x in range(dw):expected[y*w+x]=(c-1) if (x//8+y//8)&1 else 0
   mismatches=[j for j,(a,b) in enumerate(zip(base,expected)) if a!=b];rec['dib_exact_all_pixels']=not mismatches;rec['mismatches']=len(mismatches)
  if k<2:
   # Device aspect metrics affect GDI wide-pen rasterization. This is
   # a bounded-workload check, not an independent wide-stroke oracle.
   box=rec.get('drawing_bbox');rec['border_within_pen_envelope']=bool(box) and 0<=box[0]<=2 and 0<=box[1]<=2 and 122<=box[2]<=124 and 73<=box[3]<=76
  if k in (2,3):rec['text_clip_bounds']=bool(lit) and all(4<=j%w<70 and 28<=j//w<38 for j in lit)
  details.append(rec)
 checks['cursor_visible_every_batch']=all(d['cursor_visible'] for d in details)
 checks['cursor_restore_every_batch']=all(d['cursor_restores_exactly'] for d in details)
 checks['cursor_local_every_batch']=all(d['cursor_local'] for d in details)
 checks['bank_padding_preserved']=all(d['bank_padding_preserved'] for d in details)
 checks['drawing_present']=all(d['drawing_present'] for d in details)
 checks['dib_exact_all_pixels']=all(d.get('dib_exact_all_pixels',True) for d in details)
 checks['border_within_pen_envelope']=all(d.get('border_within_pen_envelope',True) for d in details)
 checks['text_clip_bounds']=all(d.get('text_clip_bounds',True) for d in details)
 checks['text_cursor_clean_equal']=all(cleanrows[6+r]==cleanrows[9+r] for r in range(3))
 checks['dib_cursor_clean_equal']=all(cleanrows[12+r]==cleanrows[15+r] for r in range(3))
 checks['replicate_frames_equal']=all(cleanrows[k*3]==cleanrows[k*3+1]==cleanrows[k*3+2] for k in range(8))
 summary=[]
 for k,name in enumerate(NAMES):
  rr=[r for r in rows if r['KIND']==k];times=[r['MS']/r['CALLS'] for r in rr];summary.append({'case':name,'calls_per_batch':rr[0]['CALLS'],'batch_ms':[r['MS'] for r in rr],'median_ms_per_call':statistics.median(times),'min_ms_per_call':min(times),'max_ms_per_call':max(times),'calls_per_second':1000/statistics.median(times)})
 report={'mode':mode,'passed':all(checks.values()),'checks':checks,'timings':summary,'details':details,'driver_sha256':result['driver_sha256']};(p/'VALIDATION.json').write_text(json.dumps(report,indent=2))
 # Show one clean frame per path, nearest-neighbor rendering preserves raw pixels.
 canvas=Image.new('RGB',(max(640,w*2),8*240),(40,40,40));d=ImageDraw.Draw(canvas)
 for k in range(8):
  vals=decode(cleanrows[k*3],PROFILES[mode]);im=Image.frombytes('L',(w,200),bytes(int(x*255/(c-1)) for x in vals)).convert('RGB')
  d.text((4,k*240+4),NAMES[k],fill='white');canvas.paste(im,(4,k*240+24))
 canvas.save(p/'CONTACT-SHEET.png')
 return report
if __name__=='__main__':
 modes=sys.argv[1:] or [m for m in PROFILES if (P/m/'RESULT.json').exists()]
 allresults=[validate(m) for m in modes];(P/'SUMMARY.json').write_text(json.dumps(allresults,indent=2))
 for r in allresults:
  print(r['mode'],'PASS',r['passed'],'failed',[k for k,v in r['checks'].items() if not v]);print([(x['case'],round(x['median_ms_per_call'],3)) for x in r['timings']])
 sys.exit(0 if all(r['passed'] for r in allresults) else 1)
