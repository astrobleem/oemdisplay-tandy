#define WINVER 0x0300
#include <windows.h>
/* Baseline harness only. No driver instrumentation or patching. */
static HWND wnd;
static HDC dc;
static HFILE logf, pref, drawf, cleanf, shownf;
static HGLOBAL mem;
static unsigned char FAR *bits;
static struct {BITMAPINFOHEADER h; RGBQUAD c[16];} bi;
static RECT clip;
static HCURSOR arrow;
static HPEN pen,oldpen;
static HBRUSH oldbrush;
static int width,height,colors,done,failures,serial,kind,dw,dh,cx,cy;
static void note(char *key,LONG v) {
 char out[100],digits[16];int n=0,d=0;DWORD u;
 while(*key)out[n++]=*key++;out[n++]='=';
 if(v<0){out[n++]='-';u=(DWORD)(-v);}else u=(DWORD)v;
 do{digits[d++]=(char)('0'+u%10);u/=10;}while(u);
 while(d)out[n++]=digits[--d];out[n++]='\r';out[n++]='\n';
 if(_lwrite(logf,out,n)!=(UINT)n)failures++;
}
static void flushlog(void){_lclose(logf);logf=_lopen("C:\\BENCH.LOG",OF_WRITE);_llseek(logf,0L,2);}
static void snap(HFILE f){if(_lwrite(f,(const void FAR *)0xb8000000L,32768U)!=32768U)failures++;}
static void setcursor(void){SetCursor(arrow);SetCursorPos(cx,cy);}
static void clear(void){if(!PatBlt(dc,0,0,width,height,BLACKNESS))failures++;setcursor();}
static void setup(int k){int j,x,y,stride;unsigned int off;kind=k;
 pen=0;dw=0;dh=0;cx=width-15;cy=height-15;
 if(k<2){pen=CreatePen(PS_SOLID,k+1,RGB(255,255,255));oldpen=SelectObject(dc,pen);oldbrush=SelectObject(dc,GetStockObject(NULL_BRUSH));}
 if(k==2||k==3){SelectObject(dc,GetStockObject(SYSTEM_FONT));SetBkMode(dc,OPAQUE);SetBkColor(dc,RGB(0,0,0));SetTextColor(dc,RGB(255,255,255));clip.left=4;clip.top=28;clip.right=70;clip.bottom=38;if(k==3){cx=12;cy=30;}}
 if(k>=4){dw=(k<6)?16:((k==6)?80:width);dh=(k<6)?16:((k==6)?80:height);if(k==5){cx=8;cy=8;}
 bi.h.biSize=40;bi.h.biWidth=dw;bi.h.biHeight=dh;bi.h.biPlanes=1;bi.h.biBitCount=4;bi.h.biCompression=BI_RGB;stride=(dw+7)/8*4;bi.h.biSizeImage=(DWORD)stride*dh;bi.h.biClrUsed=16;bi.h.biClrImportant=0;
 for(j=0;j<16;j++){bi.c[j].rgbRed=(BYTE)(j*17);bi.c[j].rgbGreen=(BYTE)(j*17);bi.c[j].rgbBlue=(BYTE)(j*17);bi.c[j].rgbReserved=0;}
 for(y=0;y<dh;y++)for(x=0;x<stride;x++){off=(unsigned int)y*stride+x;bits[off]=(unsigned char)((((x*2)/8+(dh-1-y)/8)&1)?255:0);}
 }
 clear();
}
static int batch(int count){int i,ok=0,ret;for(i=0;i<count;i++){
 if(kind<2)ret=Rectangle(dc,2,2,123,74)!=0;
 else if(kind<4)ret=ExtTextOut(dc,8,30,ETO_CLIPPED,&clip,(i&1)?"Clock":"Start",5,0)!=0;
 else ret=SetDIBitsToDevice(dc,0,0,dw,dh,0,0,0,dh,bits,(BITMAPINFO FAR *)&bi,DIB_RGB_COLORS)==dh;
 ok+=ret;
 }return ok;}
static DWORD timed(int count,int *good){DWORD t,z;t=GetTickCount();do{z=GetTickCount();}while(z==t);t=z;*good=batch(count);return GetTickCount()-t;}
static void one(int k){int count=32,ok,r;DWORD dt;setup(k);
 do{dt=timed(count,&ok);if(ok!=count)failures++;if(dt<220)count*=2;}while(dt<220&&count<8192);
 if(dt)count=(int)(((DWORD)count*2200L+dt-1)/dt);
 if(count<2)count=2;if(count>8192)count=8192;if(count&1)count++;
 for(r=0;r<3;r++){clear();snap(pref);dt=timed(count,&ok);snap(drawf);ShowCursor(FALSE);snap(cleanf);ShowCursor(TRUE);snap(shownf);
 note("CASE",serial++);note("KIND",k);note("REP",r);note("CALLS",count);note("GOOD",ok);note("MS",dt);note("DIB_WIDTH",dw);note("DIB_HEIGHT",dh);note("CURSOR_X",cx);note("CURSOR_Y",cy);if(ok!=count)failures++;flushlog();}
 if(pen){SelectObject(dc,oldpen);SelectObject(dc,oldbrush);DeleteObject(pen);}
}
static void run(HWND w){int k,ret;dc=GetDC(w);width=GetDeviceCaps(dc,HORZRES);height=GetDeviceCaps(dc,VERTRES);colors=GetDeviceCaps(dc,NUMCOLORS);
 logf=_lcreat("C:\\BENCH.LOG",0);pref=_lcreat("C:\\PRE.BIN",0);drawf=_lcreat("C:\\DRAW.BIN",0);cleanf=_lcreat("C:\\CLEAN.BIN",0);shownf=_lcreat("C:\\RESHOW.BIN",0);
 note("VERSION",3);note("FLAGS",GetWinFlags());note("WIDTH",width);note("HEIGHT",height);note("COLORS",colors);note("BATCHES",3);note("TARGET_MS",2200);
 mem=GlobalAlloc(GMEM_FIXED,(DWORD)width*height/2);bits=(unsigned char FAR *)GlobalLock(mem);
 if(!bits){note("ALLOCATION_FAILED",1);failures++;}else{
 arrow=LoadCursor(0,IDC_ARROW);do{ret=ShowCursor(FALSE);}while(ret>=0);ShowCursor(TRUE);SetCursor(arrow);
 for(k=0;k<8;k++)one(k);GlobalUnlock(mem);GlobalFree(mem);
 }
 note("FAILURES",failures);note("COMPLETE",1);_lclose(pref);_lclose(drawf);_lclose(cleanf);_lclose(shownf);_lclose(logf);ReleaseDC(w,dc);PostMessage(w,WM_CLOSE,0,0);
}
LONG FAR PASCAL WndProc(HWND w,UINT m,WORD p,LONG l){if(m==WM_TIMER){KillTimer(w,1);if(!done){done=1;run(w);}return 0;}if(m==WM_DESTROY){PostQuitMessage(0);return 0;}return DefWindowProc(w,m,p,l);}
int PASCAL WinMain(HANDLE inst,HANDLE prev,LPSTR cmd,int show){WNDCLASS c;MSG m;c.style=0;c.lpfnWndProc=WndProc;c.cbClsExtra=c.cbWndExtra=0;c.hInstance=inst;c.hIcon=0;c.hCursor=LoadCursor(0,IDC_ARROW);c.hbrBackground=GetStockObject(BLACK_BRUSH);c.lpszMenuName=0;c.lpszClassName="TR5BaselineV3";RegisterClass(&c);wnd=CreateWindow("TR5BaselineV3","TR5 baseline",WS_POPUP,0,0,GetSystemMetrics(SM_CXSCREEN),GetSystemMetrics(SM_CYSCREEN),0,0,inst,0);ShowWindow(wnd,show);UpdateWindow(wnd);SetTimer(wnd,1,100,0);while(GetMessage(&m,0,0,0)){TranslateMessage(&m);DispatchMessage(&m);}return m.wParam;}
