"""Produce an allowlisted binary-free QA evidence directory for delivery."""
from pathlib import Path
import json,hashlib,shutil
P=Path(__file__).resolve().parents[1];Q=P/'qa';E=P/'QA-EXPORT';E.mkdir(exist_ok=True)
s=json.loads((Q/'SUMMARY.JSON').read_text());assert s['passed'] and s['dos_cases']==76 and s['host_cases']==143
allowed=['FROZEN.JSON','APPROVED.JSON','PINS.json','UPSTREAM.JSON','PRESERVE.JSON','CODEDIFF.JSON','HOSTTEST.JSON','HOSTMORE.JSON','IDENTITY.JSON','DOSCASES.JSON','DOSTEST.JSON','PKGCHECK.JSON','SUMMARY.JSON','GCC.LOG','SHAQA.LOG','DOSPROG.LOG','REPRO.TXT','NOTES.TXT','SHAQA.C','makepkg.py','buildhelper.py','runhost.py','testhost.py','extra_host.py','identity_host.py','prepdos.py','prepidentity.py','rundos.py','checkpkg.py','summarize.py','exportqa.py','finishqa.py']
for n in allowed:shutil.copyfile(Q/n,E/n)
B=E/'build';B.mkdir(exist_ok=True)
for n in ['BUILD.BAT','BUILD.CNF','BUILD.LOG','HOST.LOG','CPU.TXT','LATERCPU.TXT','MEMORY.TXT']:shutil.copyfile(Q/'build'/n,B/n)
T=E/'dos';T.mkdir(exist_ok=True)
for r in json.loads((Q/'DOSTEST.JSON').read_text())['results']:
 d=T/r['case'];d.mkdir(exist_ok=True)
 for n in ['CPU.TXT','LATERCPU.TXT','MEMORY.TXT','TEST.LOG']:shutil.copyfile(Q/'dos'/r['case']/n,d/n)
 shutil.copyfile(Q/'dos'/(r['case']+'.CNF'),d/'RUN.CNF')
assert not any(p.is_symlink() or p.suffix.upper() in ['.EXE','.COM','.DRV','.OBJ','.MAP','.LST','.LIB','.FON','.BIN'] for p in E.rglob('*'))
files={str(p.relative_to(E)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(E.rglob('*')) if p.is_file() and p.name!='FILES.JSON'}
(E/'FILES.JSON').write_text(json.dumps(files,indent=2));print('Exported',len(files)+1,'QA evidence text/source files, no binaries/tools/OS media.')
