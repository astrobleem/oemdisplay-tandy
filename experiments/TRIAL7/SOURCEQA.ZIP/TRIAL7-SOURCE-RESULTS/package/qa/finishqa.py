"""Finalize reports only after every functional and identity test passes."""
from pathlib import Path
import subprocess,json,hashlib
P=Path(__file__).resolve().parents[1];Q=P/'qa';D=P/'TRIAL7'
def wr(p,s):p.write_bytes(s.replace('\r\n','\n').replace('\n','\r\n').encode())
# Validate exact source/helper bytes, CPU/memory probes and every result first.
subprocess.run(['python3',str(Q/'summarize.py')],check=True,stdout=subprocess.DEVNULL)
wr(D/'TESTS.TXT','''TRIAL7 VALIDATION SCOPE - 2026-10-05
===================================
PASS: 143 host cases, 76 real DOS cases, 3 SHA-256 known answers.

All five modes passed apply, byte-exact backup, byte-exact restore,
repeat-apply refusal, and repeated restore. Full snapshots checked that
configuration, WINXT source drivers/helpers and unrelated files stayed
unchanged. Original/test bytes are verified with embedded SHA-256 pins;
the existing exact TSCHECK helper compares copied bytes.

The 113 original host and 61 original DOS regression cases were rerun.
Added coverage: 30 host and 15 DOS exact-TR6/old-marker rejection cases.
TRIAL7 accepts only exact TR5 input; restore any applied TR6 first with
its own DIBTR6 kit and saved backup. Unknown or cross-trial inputs refuse.

Host fault injection covered interruption during backup, target and restore
copies, plus commit checkpoints. A partial backup leaves the installed
original intact and refuses restore. A valid saved backup can restore a
present partial target. Corrupt backups/markers, unknown candidates,
wrong arguments/paths/modes, pending shell journals and missing inputs
were refused without unintended changes. Missing targets deliberately
require manual inspection. Shipped TR5 files are never restore fallbacks.

DOS tests executed actual APPLY/RESTORE wrappers and final T7SAFE.EXE in
isolated DOSBox-X fixtures: Tandy, normal 640 KB, strict 8088-compatible
8086_prefetch; no FPU/XMS/EMS/UMB. All 76 cases checked CPU probes and
624 KB conventional memory, 592 KB free. Two completed final cases used
fixed 1000000 cycles; the remaining 74 used established fixed 200000.
All disabled sound/MIDI. These are functional safety tests, with no
timing-sensitive assertions or driver-performance claims. The source and helper bytes were unchanged.
Both Windows-detection branches used synthetic INT 2F status replies,
not a running Windows DOS box. No physical Tandy, CF or power-loss test
was performed. Keep a separate storage backup and plain-DOS boot route.

SHA-256 known answers: empty input, abc, one million a characters.
Helper build: Microsoft C 6 /AS /G0 /W3 /Os and LINK4 5.01.17; no warnings.
The helper itself was built under the same strict CPU/normal-memory
configuration, at fixed 200000 cycles. No toolchain or OS input is shipped.
Driver performance and all-mode qualification are reported separately.
Machine-readable results and reproducible tests accompany the separate
source/results archive. Required WindowsXT helpers are not bundled here.
''')
wr(Q/'NOTES.TXT','''TRIAL7 packaging validation notes - 2026-10-05
============================================
The new runtime kit is TRIAL7. Its driver inputs are exact frozen combined
builds recorded in APPROVED.JSON and PINS.json. Final parent confirmation
of all-mode driver qualification and exact pins is recorded in APPROVED.JSON
and FROZEN.JSON, then independently checked against every staged payload.
No existing TR5/TR6 artifact was replaced: all 26 preservation hashes pass.

T7SAFE changes only root/name/marker and host-test namespace from the prior
first-party DIBSAFE source; CODEDIFF.JSON verifies unchanged control flow
after normalizing those deliberate substitutions. PINS.H contains exact
TRIAL7 candidate and TR5 original identities. The guard accepts exact TR5
only, rather than adding multiple possible restore identities. Apply saves
and verifies the actual installed original before replacement. Restore
uses that saved original, with no fallback to shipped reference bytes.

The kit is one-shot and operates on one already active mode. It preserves
original driver bytes, backup and USED.TAG after restore. An interrupted
backup leaves the original target intact and refuses restore. A present
partial target can be restored with a valid marker and backup. A missing
target, altered mode/marker/backup, unknown helpers or layout, and pending
shell recovery refuse for inspection. Default paths are C:\\WINXT and
C:\\WINDOWS; the new independent kit root is C:\\TRIAL7. Applied TR6 must
first be restored through the existing DIBTR6 kit and its saved backup.

Final production source passed 143 host tests (88 + 25 + 30 new identity
cases), and three SHA-256 known answers. Final DOS EXE/wrappers passed 76
cases (61 regressions + 15 new identity cases), with byte snapshots,
source/helper equality and strict CPU/memory verification for every case.
Exact TR6 installed/candidate bytes and authentic-format old DIBTR6 markers
are refused on all five modes. Host tests additionally substitute TR6 in
WINXT originals, shipped references and saved backups.

The final helper build used fixed 200000 cycles. The first two final
DOS cases used fixed 1000000 cycles; after they completed, the remaining
74 returned to established fixed 200000 after the higher clock produced
slower functional-test elapsed durations. All disabled sound/MIDI. Completed runs were preserved;
CPU, memory, helper bytes and every assertion were unchanged. Every
emulator operation used blocking flock and released the lock between cases. Driver benchmarks remain
separate; host elapsed values are QA observations only.

An earlier provisional 640x200x2 candidate was superseded before release.
Its 143 host cases and 11 completed DOS cases, including the earlier clock/
audio configuration changes, are retained privately under PROVISIONAL.
They are not counted as final evidence. All 143 host and all 76 DOS tests
were rerun from fresh fixtures after updating the 6402 pin and rebuilding
the helper; final source/helper equality is checked in every DOS case.

All builds/tests used Tandy, normal 640 KB, 8086_prefetch, no FPU/EMS/XMS/UMB.
Each DOS probe reported 624 KB conventional, 592 KB free, with expected
strict CPU probe signatures. Windows-detection tests use synthetic INT 2F
responses; no actual running Windows DOS-box refusal was tested. There
was no physical Tandy, CF/storage installation, or real power-loss test.

PKGCHECK.JSON verifies the exact runtime allowlist, all payload pins, CRLF,
DOS 8.3 paths, wrapper line lengths, original/build source equality, helper
binary equality, and an empty backup/absent marker in the shipped kit.
MANIFEST.SHA inventories all runtime payloads other than itself. Source,
QA JSON and logs are evidence; no toolchain, OS/media, existing helper,
object, library, or guest-fixture binary belongs in the deliverable.

QA-EXPORT is an allowlisted copy of QA text/source evidence only. For
reproduction, copy that evidence to a directory named qa beside TRIAL7,
provide the exact private inputs listed in REPRO.TXT, and update local
input paths as necessary. Do not rerun tests against a user installation.
''')
subprocess.run(['python3',str(Q/'checkpkg.py')],check=True)
subprocess.run(['python3',str(Q/'summarize.py')],check=True,stdout=subprocess.DEVNULL)
s=json.loads((Q/'SUMMARY.JSON').read_text());a=json.loads((Q/'APPROVED.JSON').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report='''TRIAL7 PRIVATE ROLLBACK KIT - PACKAGE QA\n=======================================\nPASS: 143 host cases, 76 DOS cases, and 3 SHA-256 known answers.\nAll 113/61 prior regression cases rerun; 30/15 new cross-trial identity\ncases added. All five modes passed apply, saved-byte backup, exact restore,\nrepeat-apply refusal and repeat restore. All 26 old artifact hashes match.\n\nNew kit: package/TRIAL7, installed only by the user at C:\\TRIAL7.\nExact TR5-only baseline at C:\\WINXT with Windows at C:\\WINDOWS.\nOne-shot, one already active mode; no INI, shell, font, launcher, Setup,\nWINXT-original or existing-backup edits. Unknown layouts/identities refuse.\nIf TR6 is applied, first RESTORE through its original DIBTR6 kit and backup.\nApply saves the installed original before any replacement; restore uses\nonly that saved, verified original, never a shipped substitute. Keep the\nbackup and marker. Present partial targets can recover; missing targets\nor corrupt backups/markers require inspection. Keep a separate storage\nbackup and working plain-DOS boot route.\n\nStrict functional QA: Tandy / 8086_prefetch / normal 640 KB, no FPU, EMS,\nXMS or UMB; all 76 cases verified CPU probes and 624 KB conventional,\n592 KB free. Final helper build used fixed 200000 cycles. The first two\nfinal DOS cases used fixed 1000000; the remaining 74 used fixed 200000.\nAll disabled sound/MIDI. Earlier provisional results are excluded. These\nare functional checks with no timing claims. Windows\ndetection used synthetic replies. No physical Tandy, CF, or power-loss\nvalidation; no user computer or physical storage was changed.\n\n'''
report+=f"Runtime inventory: {s['runtime_files']} files, {s['runtime_bytes']} bytes.\nHelper T7SAFE.EXE: {s['helper_bytes']} bytes, SHA-256\n{s['helper_sha256']}\nRuntime MANIFEST.SHA SHA-256:\n{sha(D/'MANIFEST.SHA')}\n\n"
report+='Detailed results: package/qa/SUMMARY.JSON, DOSTEST.JSON, HOSTTEST.JSON,\nHOSTMORE.JSON, IDENTITY.JSON, PKGCHECK.JSON; deliverable-safe source/log\ncopy: package/QA-EXPORT. Runtime excludes tools, OS/media and shared inputs.\n'
report+='\nFinal all-mode qualification/pins: '+('confirmed by parent.\n' if a['final_qualification_confirmed'] else 'pending parent confirmation;\nfunctional package QA complete, delivery remains gated.\n')
wr(P.parent/'PACKAGE-REPORT.TXT',report)
subprocess.run(['python3',str(Q/'exportqa.py')],check=True)
print('Completed functional QA report and safe evidence export.')
