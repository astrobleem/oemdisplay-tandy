#define main dibmain
#include "../TRIAL7/SOURCE/T7SAFE.C"
#undef main
int main(void) {
 char result[65]; unsigned i;
 hashinit();total=0;hashfinal(result);if(strcmp(result,"e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")) return 1;
 hashinit();hashbyte('a');hashbyte('b');hashbyte('c');total=3;hashfinal(result);if(strcmp(result,"ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad")) return 2;
 hashinit();for(i=0;i<1000;i++) {unsigned j;for(j=0;j<1000;j++) hashbyte('a');}total=1000000;hashfinal(result);if(strcmp(result,"cdc76e5c9914fb9281a1c7e284d73e67f1809a48a497200e046d39ccc7112cd0")) return 3;
 puts("SHA256 empty, abc, million-a known answers: PASS");return 0;
}
