from pathlib import Path
import subprocess,json
P=Path(__file__).resolve().parents[1];Q=P/'qa';D=P/'TRIAL7'
with (Q/'GCC.LOG').open('w') as f:
 subprocess.run(['gcc','-x','c','-std=gnu99','-O2','-DHOST_TEST','-Wall','-Wextra','-Wno-misleading-indentation','-o',str(Q/'t7safe-host'),str(D/'SOURCE/T7SAFE.C')],stdout=f,stderr=subprocess.STDOUT,check=True)
assert not (Q/'GCC.LOG').read_text().strip(),(Q/'GCC.LOG').read_text()
subprocess.run(['gcc','-x','c','-std=gnu99','-O2','-DHOST_TEST','-o',str(Q/'shaqa-host'),str(Q/'SHAQA.C')],check=True)
with (Q/'SHAQA.LOG').open('w') as f:subprocess.run([str(Q/'shaqa-host')],stdout=f,stderr=subprocess.STDOUT,check=True)
for n in ['testhost.py','extra_host.py','identity_host.py']:subprocess.run(['python3',str(Q/n)],check=True)
print('PASS all 143 host cases and three SHA-256 known answers')
