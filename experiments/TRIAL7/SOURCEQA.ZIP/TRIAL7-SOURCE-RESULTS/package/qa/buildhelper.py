"""Build the first-party guard in strict8088/normal640KB; no tools enter kit."""
from pathlib import Path
import os,shutil,subprocess,fcntl,hashlib,json
P=Path(__file__).resolve().parents[1];Q=P/'qa';D=P/'TRIAL7';B=Q/'build'
for n in ['T7SAFE.C','PINS.H']:shutil.copyfile(D/'SOURCE'/n,B/n)
for n in ['CPUCHECK.COM','LATERCPU.COM']:shutil.copyfile(Path('/workspace/shared/windows30/round05-c')/n,B/n)
# Reset output only in the private QA build directory.
for n in ['BUILD.TAG','BUILD.LOG','T7SAFE.EXE','T7SAFE.OBJ','T7SAFE.MAP']:
 if (B/n).exists():(B/n).unlink()
s=(B/'BUILD.BAT').read_text();s=s.replace('CPUCHECK > CPU.TXT\nLATERCPU > LATERCPU.TXT\nMEM > MEMORY.TXT\n','');s=s.replace('@ECHO OFF\n','@ECHO OFF\nCPUCHECK > CPU.TXT\nLATERCPU > LATERCPU.TXT\nMEM > MEMORY.TXT\n',1)
(B/'BUILD.BAT').write_bytes(s.replace('\n','\r\n').encode())
conf='[sdl]\noutput=surface\n[dosbox]\nmachine=tandy\nmemsize=0\nmemsizekb=640\nallow more than 640kb base memory=false\n[cpu]\ncore=normal\ncputype=8086_prefetch\ncycles=fixed 200000\nfpu=false\n[dos]\nxms=false\nems=false\numb=false\n[autoexec]\nmount C "'+str(B)+'"\nC:\nBUILD.BAT\n'
(B/'BUILD.CNF').write_text(conf)
env=os.environ.copy();env.update(SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy')
with (P.parent/'emulator.lock').open('w') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 with (B/'HOST.LOG').open('w') as log:r=subprocess.run(['/workspace/shared/dosbox-x/run','-nopromptfolder','-conf',str(B/'BUILD.CNF')],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
assert r.returncode==0 and (B/'BUILD.TAG').read_text().strip()=='BUILD_OK'
assert 'warning' not in (B/'BUILD.LOG').read_text().lower(),(B/'BUILD.LOG').read_text()
assert (B/'CPU.TXT').read_text().strip()=='FLAGS high=F000 PUSH SP delta=FFFE 1<<32=0000'
assert (B/'LATERCPU.TXT').read_text().strip()=='PUSHA SPdelta=0000 PUSHimm SPdelta=0000 C0 shift=0001 66prefix AX=0001 INT6=0000'
assert '592K' in (B/'MEMORY.TXT').read_text()
shutil.copyfile(B/'T7SAFE.EXE',D/'T7SAFE.EXE')
print('Built T7SAFE.EXE', (D/'T7SAFE.EXE').stat().st_size,hashlib.sha256((D/'T7SAFE.EXE').read_bytes()).hexdigest())
