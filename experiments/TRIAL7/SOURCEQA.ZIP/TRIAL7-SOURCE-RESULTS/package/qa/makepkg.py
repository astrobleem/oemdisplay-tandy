"""Stage only parent-authorized exact TRIAL7 payloads and exact original identity pins."""
from pathlib import Path
import hashlib,json,shutil
P=Path(__file__).resolve().parents[1];R=P.parent;Q=P/'qa';D=P/'TRIAL7';OLD=R.parent/'dib-opt-20261005'
sha=lambda b:hashlib.sha256(b).hexdigest()
# This file records explicit parent permission to stage/QA the frozen build.
# Delivery additionally requires final_qualification_confirmed=true.
approved=json.loads((Q/'APPROVED.JSON').read_text())
assert approved['staging_authorized_by_parent'] is True
ref=json.loads((R/'REFERENCE-PINS.json').read_text())
rows=[];payloads=[]
modecode={'160x200x16':('16016','TR51616.DRV'),'320x200x16':('32016','TR53216.DRV'),'320x200x4':('3204','TR53204.DRV'),'640x200x4':('6404','TR56404.DRV'),'640x200x2':('6402','TR56402.DRV')}
assert set(approved['modes'])==set(modecode)
for mode,(code,name) in modecode.items():
 old=(OLD/'references'/name).read_bytes();a=approved['modes'][mode]
 driver=R/a.get('driver_path',str(Path('builds/combined')/mode/ref[mode]['driver']))
 assert R.resolve() in driver.resolve().parents
 new=driver.read_bytes()
 assert sha(old)==ref[mode]['tr5']
 assert sha(new)==a['sha256'] and len(new)==a['bytes'],mode
 assert sha(new) not in [ref[mode]['tr5'],ref[mode]['tr6']],mode
 rows.append([code,name,len(old),sha(old),len(new),sha(new)])
 payloads += [(D/'TR5'/name,old),(D/'NEW'/name,new)]
text='/* Exact SHA-256 pins for the exact TRIAL7 test and TR5 originals. */\nstatic Mode modes[] = {\n'
for r in rows:text+='    {"%s","%s",%dUL,"%s",%dUL,"%s"},\n'%tuple(r)
text+='};\n'
up={r['name']:r for r in json.loads((Q/'UPSTREAM.JSON').read_text())['checks']}
for name,var in [('SHELLSEL.EXE','shell'),('TSCHECK.EXE','check')]:
 b=(Q/'helpers'/name).read_bytes();assert len(b)==up[name]['size'] and sha(b)==up[name]['sha256']
 text+='static unsigned long '+var+'_size='+str(len(b))+'UL;\nstatic char *'+var+'_hash="'+sha(b)+'";\n'
for p,b in payloads:p.write_bytes(b)
(D/'SOURCE/PINS.H').write_bytes(text.replace('\n','\r\n').encode())
(Q/'PINS.json').write_text(json.dumps(rows,indent=2))
print('Staged all five exact frozen-build TRIAL7 drivers and TR5 identity references.')
