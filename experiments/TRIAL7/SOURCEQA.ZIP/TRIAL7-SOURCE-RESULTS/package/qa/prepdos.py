from pathlib import Path
import shutil,json,struct
P=Path(__file__).resolve().parents[1];Q=P/'qa';D=P/'TRIAL7';T=Q/'dos';T.mkdir(exist_ok=True)
rows=json.loads((Q/'PINS.json').read_text());cases=[]
def wr(p,s):
 if p.name=='RUN.BAT':
  s=s.replace('@ECHO OFF\n','@ECHO OFF\nC:\\CPUCHECK > C:\\CPU.TXT\nC:\\LATERCPU > C:\\LATERCPU.TXT\nMEM > C:\\MEMORY.TXT\n',1)
  s='\n'.join(('COMMAND /C '+line[5:]+' >> C:\\TEST.LOG') if line.startswith('CALL ') else line for line in s.split('\n'))
 p.write_bytes(s.replace('\n','\r\n').encode())
def guest(label,r):
 g=T/label
 if g.exists():shutil.rmtree(g)
 g.mkdir();shutil.copytree(D,g/'TRIAL7');(g/'WINDOWS/SYSTEM').mkdir(parents=True);(g/'WINXT').mkdir()
 for n in ['CPUCHECK.COM','LATERCPU.COM']:shutil.copyfile(Path('/workspace/shared/windows30/round05-c')/n,g/n)
 for n in ['SHELLSEL.EXE','TSCHECK.EXE']:shutil.copyfile(Q/'helpers'/n,g/'WINXT'/n)
 for rr in rows:
  shutil.copyfile(D/'TR5'/rr[1],g/'WINXT'/rr[1]);shutil.copyfile(D/'TR5'/rr[1],g/'WINDOWS/SYSTEM'/rr[1])
 shutil.copyfile('/workspace/shared/windows30/round05-c/WINDOWS/WIN.COM',g/'WINDOWS/WIN.COM')
 wr(g/'WINDOWS/SYSTEM.INI','[boot]\nshell=PROGMAN.EXE\ndisplay.drv='+r[1]+'\n');wr(g/'WINDOWS/WIN.INI','[windows]\nrun=\nload=\n');wr(g/'CONFIG.SYS','FILES=30\n');wr(g/'AUTOEXEC.BAT','@ECHO OFF\n');return g
for r in rows:
 mode,name=r[:2];g=guest('happy-'+mode,r)
 b='@ECHO OFF\nCD \\TRIAL7\nCALL APPLY '+mode+' YES\nCOPY /B C:\\WINDOWS\\SYSTEM\\'+name+' C:\\AFTER.DRV > NUL\nCALL APPLY '+mode+' YES\nCALL RESTORE '+mode+' YES\nCALL RESTORE '+mode+' YES\nCALL APPLY '+mode+' YES\nECHO DONE > C:\\DONE.TAG\n'
 wr(g/'RUN.BAT',b);cases.append(dict(case='happy-'+mode,mode=mode,name=name,kind='happy'))
r=rows[1];mode,name=r[:2]
refuse=['bad-yes','bad-mode','extra-arg','wrong-cwd','missing-helper','bad-helper','unknown-target','wrong-active','duplicate-display','duplicate-boot','missing-candidate','modified-candidate','modified-reference','modified-winxt','existing-backup','bad-backup','used-marker','pending-jrn','pending-new','pending-old','pending-rst','missing-backup-dir','readonly-target','restore-no-marker','windows1600','windows4680']
for case in refuse:
 g=guest(case,r);args=mode+' YES';cmd='CALL APPLY ';pre='';t=g/'WINDOWS/SYSTEM'/name
 if case=='bad-yes':args=mode+' NO'
 if case=='bad-mode':args='bogus YES'
 if case=='extra-arg':args+=' C:\\OTHER'
 if case=='wrong-cwd':pre='CD \\\n';cmd='CALL C:\\TRIAL7\\APPLY '
 if case=='missing-helper':(g/'WINXT/SHELLSEL.EXE').unlink()
 if case=='bad-helper':(g/'WINXT/TSCHECK.EXE').write_bytes(b'bad')
 if case=='unknown-target':t.write_bytes(b'unknown')
 if case=='wrong-active':wr(g/'WINDOWS/SYSTEM.INI','[boot]\nshell=PROGMAN.EXE\ndisplay.drv=CGA.DRV\n')
 if case=='duplicate-display':
  p=g/'WINDOWS/SYSTEM.INI';p.write_bytes(p.read_bytes()+b'display.drv=TR53216.DRV\r\n')
 if case=='duplicate-boot':
  p=g/'WINDOWS/SYSTEM.INI';p.write_bytes(p.read_bytes()+b'[boot]\r\n')
 if case=='missing-candidate':(g/'TRIAL7/NEW'/name).unlink()
 if case=='modified-candidate':
  p=g/'TRIAL7/NEW'/name;d=bytearray(p.read_bytes());d[1000]^=1;p.write_bytes(d)
 if case=='modified-reference':(g/'TRIAL7/TR5'/name).write_bytes(b'bad')
 if case=='modified-winxt':(g/'WINXT'/name).write_bytes(b'bad')
 if case in ['existing-backup','bad-backup']:(g/'TRIAL7/BACKUP'/name).write_bytes((D/'TR5'/name).read_bytes() if case=='existing-backup' else b'bad')
 if case=='used-marker':(g/'TRIAL7/USED.TAG').write_bytes(b'previous')
 if case.startswith('pending-'):(g/'WINDOWS'/('TSHELL.'+case[-3:].upper())).write_bytes(b'pending')
 if case=='missing-backup-dir':shutil.rmtree(g/'TRIAL7/BACKUP')
 if case=='readonly-target':pre='ATTRIB +R C:\\WINDOWS\\SYSTEM\\'+name+'\n'
 if case=='restore-no-marker':cmd='CALL RESTORE '
 if case.startswith('windows'):
  # Synthetic INT 2F Windows status for each independent guard branch.
  # COM installs one hook then stays resident using DOS function 31h.
  b=bytearray.fromhex('0e1fb82f35cd21891e00008c060000ba0000b82f25cd21ba0000b80031cd21')
  handler=0x100+len(b);func=0x1600 if case=='windows1600' else 0x4680
  b+=b'\x3d'+struct.pack('<H',func)+b'\x75\x03'+(b'\xb0\x03' if func==0x1600 else b'\x31\xc0')+b'\xcf'
  old=0x100+len(b)+5;b+=b'\x2e\xff\x2e'+struct.pack('<H',old)+b'\0\0\0\0'
  struct.pack_into('<H',b,9,old);struct.pack_into('<H',b,13,old+2);struct.pack_into('<H',b,16,handler);struct.pack_into('<H',b,24,(0x100+len(b)+15)//16)
  (g/'WINMOCK.COM').write_bytes(b);pre='C:\\WINMOCK.COM\n'
 wr(g/'RUN.BAT','@ECHO OFF\nCD \\TRIAL7\n'+pre+cmd+args+'\nECHO DONE > C:\\DONE.TAG\n');cases.append(dict(case=case,mode=mode,name=name,kind='refuse'))
for r in rows:
 mode,name=r[:2]
 for corrupt in ['partial-target','empty-target','no-candidate','bad-backup','bad-marker','missing-target']:
  label=corrupt+'-'+mode;g=guest(label,r)
  b='@ECHO OFF\nCD \\TRIAL7\nCALL APPLY '+mode+' YES\n'
  if corrupt=='partial-target':b+='COPY /B C:\\WINXT\\TSCHECK.EXE C:\\WINDOWS\\SYSTEM\\'+name+' > NUL\n'
  if corrupt=='empty-target':b+='TYPE NUL > C:\\WINDOWS\\SYSTEM\\'+name+'\n'
  if corrupt=='no-candidate':b+='DEL C:\\TRIAL7\\NEW\\'+name+'\n'
  if corrupt=='bad-backup':b+='ECHO BROKEN > C:\\TRIAL7\\BACKUP\\'+name+'\n'
  if corrupt=='bad-marker':b+='ECHO BROKEN > C:\\TRIAL7\\USED.TAG\n'
  if corrupt=='missing-target':b+='DEL C:\\WINDOWS\\SYSTEM\\'+name+'\n'
  b+='CALL RESTORE '+mode+' YES\nECHO DONE > C:\\DONE.TAG\n';wr(g/'RUN.BAT',b);cases.append(dict(case=label,mode=mode,name=name,kind=corrupt))
(Q/'DOSCASES.JSON').write_text(json.dumps(cases,indent=2));print('Prepared',len(cases),'DOS cases')
