from pathlib import Path
import shutil,os,subprocess,json,hashlib,time,fcntl
P=Path(__file__).resolve().parents[1];Q=P/'qa';D=P/'TRIAL7';T=Q/'dos'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def snap(g):return {str(p.relative_to(g)):sha(p) for p in g.rglob('*') if p.is_file()}
rows=json.loads((Q/'PINS.json').read_text());cases=json.loads((Q/'DOSCASES.JSON').read_text());results=json.loads((Q/'DOSTEST.JSON').read_text())['results'] if (Q/'DOSTEST.JSON').exists() else []
done={r['case'] for r in results}
lock=(P.parent/'emulator.lock').open('w');
for idx,c in enumerate(cases):
 if c['case'] in done: continue
 if (Q/'PAUSE').exists(): print('PAUSED before',c['case'],flush=True);break
 g=T/c['case'];shutil.copyfile(D/'T7SAFE.EXE',g/'TRIAL7/T7SAFE.EXE');before=snap(g)
 conf='[sdl]\noutput=surface\n[dosbox]\nmachine=tandy\nmemsize=0\nmemsizekb=640\nallow more than 640kb base memory=false\n[cpu]\ncore=normal\ncputype=8086_prefetch\ncycles=fixed 200000\nfpu=false\n[dos]\nxms=false\nems=false\numb=false\n[mixer]\nnosound=true\n[midi]\nmididevice=none\n[autoexec]\nmount C "'+str(g)+'"\nC:\nCALL RUN.BAT\nEXIT\n'
 cnf=T/(c['case']+'.CNF');cnf.write_text(conf);env=os.environ.copy();env.update(SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy')
 fcntl.flock(lock,fcntl.LOCK_EX)
 if (Q/'PAUSE').exists():
  fcntl.flock(lock,fcntl.LOCK_UN);print('PAUSED before',c['case'],flush=True);break
 start=time.monotonic()
 with (T/(c['case']+'.HOST')).open('w') as f:pr=subprocess.run(['/workspace/shared/dosbox-x/run','-nopromptfolder','-conf',str(cnf)],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=120)
 fcntl.flock(lock,fcntl.LOCK_UN)
 log=(g/'TEST.LOG').read_text(errors='replace');assert (g/'DONE.TAG').is_file(),(c,log);assert pr.returncode==0
 after=snap(g);target='WINDOWS/SYSTEM/'+c['name'];backup='TRIAL7/BACKUP/'+c['name'];kind=c['kind'];orig=sha(D/'TR5'/c['name']);new=sha(D/'NEW'/c['name'])
 changed={k for k in before if after.get(k)!=before[k]};added=set(after)-set(before);expectedadd={'TEST.LOG','DONE.TAG','CPU.TXT','LATERCPU.TXT','MEMORY.TXT'}
 if kind=='happy':
  assert after[target]==after[backup]==orig,(c,log);assert after['AFTER.DRV']==new;assert log.count('APPLY VERIFIED.')==1,(c,log);assert log.count('RESTORE VERIFIED.')==2,(c,log);assert log.count('already been used')==2,(c,log);assert not changed,(c,changed);expectedadd|={'TRIAL7/USED.TAG',backup,'AFTER.DRV'}
 elif kind=='refuse':
  assert not changed,(c,changed,log);assert 'APPLY VERIFIED.' not in log and 'RESTORE VERIFIED.' not in log;assert ('TRIAL7:' in log or (c['case'] in ['bad-yes','extra-arg'] and 'Use APPLY mode YES' in log)),(c,log)
 elif kind in ['partial-target','empty-target','no-candidate']:
  assert after[target]==after[backup]==orig,(c,log);assert log.count('APPLY VERIFIED.')==1 and log.count('RESTORE VERIFIED.')==1,(c,log);assert changed==({'TRIAL7/NEW/'+c['name']} if kind=='no-candidate' else set()),(c,changed);expectedadd|={'TRIAL7/USED.TAG',backup}
 elif kind in ['bad-backup','bad-marker','missing-target']:
  assert 'RESTORE VERIFIED.' not in log and 'TRIAL7:' in log,(c,log);assert changed=={target},(c,changed);assert after.get(target)==(None if kind=='missing-target' else new),(c,log);expectedadd|={'TRIAL7/USED.TAG',backup}
 assert added==expectedadd,(c,added,expectedadd)
 results.append(dict(**c,passed=True,host_seconds=round(time.monotonic()-start,3),output=log,changed=sorted(changed),added=sorted(added)))
 (Q/'DOSTEST.JSON').write_text(json.dumps({'passed':len(results),'total':len(cases),'results':results},indent=2));print('PASS',idx+1,'/',len(cases),c['case'],round(time.monotonic()-start,2),flush=True)
print('ALL DOS TESTS PASS' if len(results)==len(cases) else 'DOS QA PAUSED',len(results),flush=True)

if len(results)!=len(cases):raise SystemExit(75)
