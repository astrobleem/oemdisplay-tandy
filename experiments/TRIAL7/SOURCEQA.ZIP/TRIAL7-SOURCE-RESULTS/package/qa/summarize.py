from pathlib import Path
import json,hashlib,re
P=Path(__file__).resolve().parents[1];Q=P/'qa';D=P/'TRIAL7'
dos=json.loads((Q/'DOSTEST.JSON').read_text());assert dos['passed']==dos['total']==76
host=json.loads((Q/'HOSTTEST.JSON').read_text());more=json.loads((Q/'HOSTMORE.JSON').read_text());assert host['passed']==88 and more['passed']==25
identity=json.loads((Q/'IDENTITY.JSON').read_text());assert identity['passed']==30
expected={'bad-yes':'Use APPLY mode YES','bad-mode':'Unknown mode.','extra-arg':'Use APPLY mode YES','wrong-cwd':'Run from C:\\TRIAL7 only.','missing-helper':'Required file is missing','bad-helper':'Pinned file length mismatch.','unknown-target':'Pinned file length mismatch.','wrong-active':'Selected mode is not the active Windows display.','duplicate-display':'Need one unambiguous active [boot] display.drv.','duplicate-boot':'SHELLSEL safety check failed','missing-candidate':'Required file is missing','modified-candidate':'Pinned file SHA-256 mismatch.','modified-reference':'Pinned file length mismatch.','modified-winxt':'Pinned file length mismatch.','existing-backup':'Existing backup found.','bad-backup':'Existing backup found.','used-marker':'This kit has already been used.','missing-backup-dir':'Required default-layout directory is missing.','readonly-target':'Required file is missing or has unsupported attributes.','restore-no-marker':'Required file is missing','windows1600':'Exit Windows completely first.','windows4680':'Exit Windows completely first.'}
for mode in ['16016','32016','3204','6404','6402']:
 for kind in ['tr6-installed','tr6-candidate']:expected[kind+'-'+mode]='Pinned file length mismatch.'
for suffix in ['jrn','new','old','rst']:expected['pending-'+suffix]='Pending shell recovery.'
metrics=[]
for r in dos['results']:
 g=Q/'dos'/r['case'];cnf=Q/'dos'/(r['case']+'.CNF');c=cnf.read_text();assert all(s in c for s in ['memsize=0','memsizekb=640','allow more than 640kb base memory=false','cputype=8086_prefetch','fpu=false','xms=false','ems=false','umb=false'])
 cycles=int(re.search(r'^cycles=fixed (\d+)$',c,re.M).group(1));assert cycles in [200000,1000000]
 cpu=(g/'CPU.TXT').read_text().strip();later=(g/'LATERCPU.TXT').read_text().strip();mem=(g/'MEMORY.TXT').read_text();assert cpu=='FLAGS high=F000 PUSH SP delta=FFFE 1<<32=0000';assert later=='PUSHA SPdelta=0000 PUSHimm SPdelta=0000 C0 shift=0001 66prefix AX=0001 INT6=0000';assert re.search(r'Conventional\s+624K\s+32K\s+592K',mem)
 for n in ['T7SAFE.EXE','APPLY.BAT','RESTORE.BAT','SOURCE/T7SAFE.C','SOURCE/PINS.H']:assert (g/'TRIAL7'/n).read_bytes()==(D/n).read_bytes(),(r['case'],n)
 if r['kind']=='refuse':assert expected[r['case']] in r['output'],r
 if r['kind']=='bad-backup':assert 'Pinned file length mismatch.' in r['output']
 if r['kind']=='bad-marker':assert 'Trial marker incomplete, changed, or for another mode.' in r['output']
 if r['kind']=='missing-target':assert 'Target is missing; retain files for manual recovery.' in r['output']
 metrics.append(dict(case=r['case'],host_seconds=r['host_seconds'],audio_disabled=('nosound=true' in c and 'mididevice=none' in c),functional_cycles=cycles,cpu=cpu,later_cpu=later,config_sha256=hashlib.sha256(cnf.read_bytes()).hexdigest()))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
summary={'passed':True,'runtime_directory':'TRIAL7','runtime_files':20,'runtime_bytes':sum(p.stat().st_size for p in D.rglob('*') if p.is_file()),'dos_cases':76,'host_cases':143,'new_identity_host_cases':30,'new_identity_dos_cases':15,'sha256_known_answers':3,'driver_modes':5,'helper_bytes':(D/'T7SAFE.EXE').stat().st_size,'helper_sha256':sha(D/'T7SAFE.EXE'),'source_sha256':sha(D/'SOURCE/T7SAFE.C'),'real_dos_profile':{'machine':'tandy','memory_kb':640,'cpu':'8086_prefetch','cycles':{'1000000':2,'200000':74},'fpu':False,'xms':False,'ems':False,'umb':False},'strict_profile_cpu_memory_checks':76,'timing_scope':'Final functional QA only: two completed cases used fixed 1000000, remaining 74 used fixed 200000; all disabled sound/MIDI and helper build used 200000. Elapsed times are neither driver benchmarks nor physical-machine durations','total_final_dos_case_seconds':round(sum(r['host_seconds'] for r in dos['results']),3),'per_case':metrics,'limits':['No physical Tandy/CF/power-loss validation','Windows-detection refusal uses synthetic INT 2F replies, not a running Windows DOS box','Default-layout exact-pinned TR5 WindowsXT installation only; restore TR6 with its own kit first','One-shot one-active-mode kit; backup and marker retained','Arbitrarily missing target is refused; present partial copy can be restored']}
preserve=json.loads((Q/'PRESERVE.JSON').read_text());assert all(Path(p).is_file() and sha(Path(p))==h for p,h in preserve.items())
assert sum(r['functional_cycles']==1000000 for r in metrics)==2 and sum(r['functional_cycles']==200000 for r in metrics)==74
assert all(r['audio_disabled'] for r in metrics)
summary['audio_configuration']={'disabled_guard_only':76}
summary['old_artifacts_unchanged']=len(preserve)
summary['helper_build_config_sha256']=sha(Q/'build/BUILD.CNF')
summary['sha256_known_answer_output']=(Q/'SHAQA.LOG').read_text().strip()
summary['approved_driver_pins']=json.loads((Q/'APPROVED.JSON').read_text())
(Q/'SUMMARY.JSON').write_text(json.dumps(summary,indent=2));print(json.dumps({k:v for k,v in summary.items() if k!='per_case'},indent=2))
