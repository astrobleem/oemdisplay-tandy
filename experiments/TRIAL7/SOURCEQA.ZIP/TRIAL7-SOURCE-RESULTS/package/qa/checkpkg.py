from pathlib import Path
import hashlib,json,re
P=Path(__file__).resolve().parents[1];D=P/'TRIAL7';Q=P/'qa';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=json.loads((Q/'PINS.json').read_text())
expected={'APPLY.BAT','RESTORE.BAT','README.TXT','TESTS.TXT','T7SAFE.EXE','BACKUP/KEEP.TXT','SOURCE/T7SAFE.C','SOURCE/PINS.H','SOURCE/BUILD.BAT'}
for r in rows:
 for d in ['TR5','NEW']:expected.add(d+'/'+r[1])
actual={str(p.relative_to(D)) for p in D.rglob('*') if p.is_file() and p.name!='MANIFEST.SHA'}
assert actual==expected,(actual-expected,expected-actual)
for n in actual:
 p=D/n
 for component in Path(n).parts:assert re.fullmatch(r'[A-Z0-9_]{1,8}(\.[A-Z0-9_]{1,3})?',component),component
 if p.suffix in ['.BAT','.TXT','.C','.H']:
  b=p.read_bytes();assert b'\n' not in b.replace(b'\r\n',b''),n;assert b'\r' not in b.replace(b'\r\n',b''),n
 if p.suffix=='.BAT':assert max(len(l) for l in p.read_bytes().splitlines())<=126,n
for r in rows:
 for d,s,h in [('TR5',r[2],r[3]),('NEW',r[4],r[5])]:assert (D/d/r[1]).stat().st_size==s and sha(D/d/r[1])==h
assert (D/'SOURCE/T7SAFE.C').read_bytes()==(Q/'build/T7SAFE.C').read_bytes()
assert (D/'SOURCE/PINS.H').read_bytes()==(Q/'build/PINS.H').read_bytes()
assert (D/'T7SAFE.EXE').read_bytes()==(Q/'build/T7SAFE.EXE').read_bytes()
assert not list((D/'BACKUP').glob('*.DRV')) and not (D/'USED.TAG').exists()
manifest=''.join(sha(D/n)+'  '+n.replace('/','\\')+'\r\n' for n in sorted(actual));(D/'MANIFEST.SHA').write_bytes(manifest.encode())
files={str(p.relative_to(D)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(D.rglob('*')) if p.is_file()}
(Q/'PKGCHECK.JSON').write_text(json.dumps({'passed':True,'file_count':len(files),'bytes':sum(v['bytes'] for v in files.values()),'files':files,'runtime_excludes':['OS files','compiler executables','helper executables from WINXT','object files','maps','guest fixtures']},indent=2));print('PASS package',len(files),'files',sum(v['bytes'] for v in files.values()),'bytes')
