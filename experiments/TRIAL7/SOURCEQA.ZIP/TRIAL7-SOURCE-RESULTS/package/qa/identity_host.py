# Exercise old-trial identity rejection with the exact production host helper.
exec(open(__file__.replace('identity_host.py','testhost.py')).read().split('for r in rows:')[0])
ref=json.loads((P.parent/'REFERENCE-PINS.json').read_text())
refs={m.replace('x200x',''):v for m,v in ref.items()}
extra=[]
for r in rows:
 mode,name=r[:2];tr6=(P.parent/'references'/refs[mode]['tr6_file']).read_bytes()
 assert hashlib.sha256(tr6).hexdigest()==refs[mode]['tr6']
 for kind in ['tr6-installed','tr6-winxt','tr6-reference','tr6-candidate','tr6-backup','tr6-marker']:
  g=guest('identity-'+kind+'-'+mode,r);args=['APPLY',mode,'YES']
  if kind in ['tr6-backup','tr6-marker']:
   assert run(g,args).returncode==0;args=['RESTORE',mode,'YES']
  targets={'tr6-installed':g/'WINDOWS/SYSTEM'/name,'tr6-winxt':g/'WINXT'/name,'tr6-reference':g/'TRIAL7/TR5'/name,'tr6-candidate':g/'TRIAL7/NEW'/name,'tr6-backup':g/'TRIAL7/BACKUP'/name,'tr6-marker':g/'TRIAL7/USED.TAG'}
  targets[kind].write_bytes(('DIBTR6 one-shot trial\r\n'+name+'\r\n').encode() if kind=='tr6-marker' else tr6)
  before=snapshot(g);x=run(g,args);assert x.returncode==1,(kind,mode,x.stdout);assert snapshot(g)==before,(kind,mode)
  extra.append(dict(case=kind,mode=mode,passed=True,refused_without_mutation=True,reason=x.stdout.strip()))
(Q/'IDENTITY.JSON').write_text(json.dumps({'passed':len(extra),'results':extra},indent=2));print('PASS',len(extra),'TR7 identity host cases')
