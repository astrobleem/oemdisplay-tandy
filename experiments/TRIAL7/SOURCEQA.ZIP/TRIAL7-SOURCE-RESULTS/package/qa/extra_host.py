# Reuse the exact production host build and private fixture constructors.
exec(open(__file__.replace('extra_host.py','testhost.py')).read().split('for r in rows:')[0])
extra=[]
for r in rows:
 mode,name=r[:2]
 for kind in ['restore-short','restore-crash','restore-missing','restore-changed-same-size','restore-without-new']:
  g=guest('extra-'+kind+'-'+mode,r);assert run(g,['APPLY',mode,'YES']).returncode==0
  t=g/'WINDOWS/SYSTEM'/name;b=g/'TRIAL7/BACKUP'/name;orig=(D/'TR5'/name).read_bytes()
  if kind=='restore-short':
   assert run(g,['RESTORE',mode,'YES'],{'TR7_SHORT':'2'}).returncode==1;assert b.read_bytes()==orig;assert run(g,['RESTORE',mode,'YES']).returncode==0;assert t.read_bytes()==orig
  if kind=='restore-crash':
   assert run(g,['RESTORE',mode,'YES'],{'TR7_CRASH':'1'}).returncode==99;assert b.read_bytes()==orig;assert run(g,['RESTORE',mode,'YES']).returncode==0;assert t.read_bytes()==orig
  if kind=='restore-missing':
   t.unlink();before=snapshot(g);assert run(g,['RESTORE',mode,'YES']).returncode==1;assert before==snapshot(g)
  if kind=='restore-changed-same-size':
   d=bytearray(b.read_bytes());d[1000]^=1;b.write_bytes(d);before=snapshot(g);assert run(g,['RESTORE',mode,'YES']).returncode==1;assert before==snapshot(g)
  if kind=='restore-without-new':
   shutil.rmtree(g/'TRIAL7/NEW');assert run(g,['RESTORE',mode,'YES']).returncode==0;assert t.read_bytes()==orig
  extra.append(dict(case=kind,mode=mode,passed=True))
(Q/'HOSTMORE.JSON').write_text(json.dumps({'passed':len(extra),'results':extra},indent=2));print('PASS',len(extra),'extra host cases')
