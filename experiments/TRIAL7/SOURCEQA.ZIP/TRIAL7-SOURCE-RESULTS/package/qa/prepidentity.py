# Append identity cases to the prepared 61-case DOS regression suite.
exec(open(__file__.replace('prepidentity.py','prepdos.py')).read().split('for r in rows:')[0])
cases=json.loads((Q/'DOSCASES.JSON').read_text());assert len(cases)==61
ref=json.loads((P.parent/'REFERENCE-PINS.json').read_text());refs={m.replace('x200x',''):v for m,v in ref.items()}
for r in rows:
 mode,name=r[:2];tr6=(P.parent/'references'/refs[mode]['tr6_file']).read_bytes()
 for kind in ['tr6-installed','tr6-candidate','tr6-marker']:
  label=kind+'-'+mode;g=guest(label,r);b='@ECHO OFF\nCD \\TRIAL7\n'
  if kind=='tr6-installed':(g/'WINDOWS/SYSTEM'/name).write_bytes(tr6)
  if kind=='tr6-candidate':(g/'TRIAL7/NEW'/name).write_bytes(tr6)
  if kind=='tr6-marker':
   # Ship an old-trial marker only in the isolated QA fixture, then substitute
   # it after a real successful APPLY. A legacy marker must not authorize RESTORE.
   wr(g/'OLD.TAG','DIBTR6 one-shot trial\n'+name+'\n')
   b+='CALL APPLY '+mode+' YES\nCOPY /B C:\\OLD.TAG C:\\TRIAL7\\USED.TAG > NUL\nCALL RESTORE '+mode+' YES\n'
  else:b+='CALL APPLY '+mode+' YES\n'
  b+='ECHO DONE > C:\\DONE.TAG\n';wr(g/'RUN.BAT',b)
  cases.append(dict(case=label,mode=mode,name=name,kind='bad-marker' if kind=='tr6-marker' else 'refuse'))
(Q/'DOSCASES.JSON').write_text(json.dumps(cases,indent=2));print('Prepared',len(cases),'DOS cases including TR7 identity coverage')
