from pathlib import Path
import os,shutil,subprocess,json,hashlib
P=Path(__file__).resolve().parents[1];Q=P/'qa';D=P/'TRIAL7';H=Q/'host';H.mkdir(exist_ok=True)
rows=json.loads((Q/'PINS.json').read_text());results=[]
def sh(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def snapshot(g):return {str(p.relative_to(g)):sh(p) for p in g.rglob('*') if p.is_file()}
def guest(label,r):
 g=H/label
 if g.exists():shutil.rmtree(g)
 g.mkdir();shutil.copytree(D,g/'TRIAL7');(g/'WINDOWS/SYSTEM').mkdir(parents=True);(g/'WINXT').mkdir()
 for name in ['SHELLSEL.EXE','TSCHECK.EXE']:shutil.copyfile(Q/'helpers'/name,g/'WINXT'/name)
 for rr in rows:shutil.copyfile(D/'TR5'/rr[1],g/'WINXT'/rr[1]);shutil.copyfile(D/'TR5'/rr[1],g/'WINDOWS/SYSTEM'/rr[1])
 shutil.copyfile('/workspace/shared/windows30/round05-c/WINDOWS/WIN.COM',g/'WINDOWS/WIN.COM')
 (g/'WINDOWS/SYSTEM.INI').write_bytes(('[boot]\r\nshell=PROGMAN.EXE\r\ndisplay.drv='+r[1]+'\r\n').encode())
 (g/'WINDOWS/WIN.INI').write_bytes(b'[windows]\r\nrun=\r\nload=\r\n');(g/'CONFIG.SYS').write_bytes(b'FILES=30\r\n');(g/'AUTOEXEC.BAT').write_bytes(b'@ECHO OFF\r\n')
 return g
def run(g,args,env={}):
 e=os.environ.copy();e.update(TR7_ROOT=str(g));e.update(env);return subprocess.run([str(Q/'t7safe-host')]+args,env=e,capture_output=True,text=True)
def record(label,**kw):results.append(dict(case=label,**kw))
for r in rows:
 mode,name=r[:2];g=guest('happy-'+mode,r);orig=snapshot(g);t=g/'WINDOWS/SYSTEM'/name;b=g/'TRIAL7/BACKUP'/name
 x=run(g,['APPLY',mode,'YES']);assert x.returncode==0,x.stderr;assert t.read_bytes()==(D/'NEW'/name).read_bytes();assert b.read_bytes()==(D/'TR5'/name).read_bytes()
 stable=snapshot(g);x=run(g,['APPLY',mode,'YES']);assert x.returncode==1 and snapshot(g)==stable
 x=run(g,['RESTORE',mode,'YES']);assert x.returncode==0,x.stderr;assert t.read_bytes()==(D/'TR5'/name).read_bytes()
 stable=snapshot(g);x=run(g,['RESTORE',mode,'YES']);assert x.returncode==0 and snapshot(g)==stable
 x=run(g,['APPLY',mode,'YES']);assert x.returncode==1 and snapshot(g)==stable
 assert all(snapshot(g)[k]==v for k,v in orig.items())
 record('happy-'+mode,apply=True,restore=True,reapply_refused=True,idempotent_restore=True,all_original_files_unchanged=True)
 # Corrupt target after proven apply (equivalent to interrupted target write).
 for stage in [0,1,3000,27000]:
  g=guest('recover-'+mode+'-'+str(stage),r);assert run(g,['APPLY',mode,'YES']).returncode==0
  t=g/'WINDOWS/SYSTEM'/name;t.write_bytes((D/'NEW'/name).read_bytes()[:stage]);x=run(g,['RESTORE',mode,'YES']);assert x.returncode==0,x.stderr;assert t.read_bytes()==(D/'TR5'/name).read_bytes();record('recover-'+mode+'-'+str(stage),restored=True)
 for step in [1,2,3,4]:
  g=guest('crash-'+mode+'-'+str(step),r);t=g/'WINDOWS/SYSTEM'/name;x=run(g,['APPLY',mode,'YES'],{'TR7_CRASH':str(step)});assert x.returncode==99
  x=run(g,['RESTORE',mode,'YES']);assert x.returncode==(1 if step==1 else 0),x.stderr
  assert t.read_bytes()==(D/'TR5'/name).read_bytes();record('crash-'+mode+'-'+str(step),returncode=x.returncode,original_intact=True)
 for which in [1,2]:
  g=guest('short-'+mode+'-'+str(which),r);t=g/'WINDOWS/SYSTEM'/name;x=run(g,['APPLY',mode,'YES'],{'TR7_SHORT':str(which)});assert x.returncode==1
  x=run(g,['RESTORE',mode,'YES']);assert x.returncode==(1 if which==1 else 0),x.stderr;assert t.read_bytes()==(D/'TR5'/name).read_bytes();record('short-'+mode+'-'+str(which),original_intact=True)
# Mutation-free refusals cover validation before marker/backup creation.
r=rows[1];mode,name=r[:2]
cases=['bad-yes','bad-mode','extra-arg','missing-arg','bad-operation','wrong-cwd','missing-helpers','bad-helper','missing-target','unknown-target','wrong-active','duplicate-display','duplicate-boot','nul-ini','missing-candidate','truncated-candidate','modified-candidate','modified-reference','modified-winxt','existing-backup','bad-backup','used-marker','pending-jrn','pending-new','pending-old','pending-rst','missing-backup-dir','readonly-target','restore-no-marker','restore-no-backup','restore-bad-marker','restore-bad-backup','restore-wrong-mode']
for case in cases:
 g=guest(case,r);args=['APPLY',mode,'YES'];env={};t=g/'WINDOWS/SYSTEM'/name
 if case.startswith('restore-') and case not in ['restore-no-marker']:
  assert run(g,args).returncode==0
  args=['RESTORE',mode,'YES']
 if case=='bad-yes':args[-1]='NO'
 if case=='bad-mode':args[1]='bogus'
 if case=='extra-arg':args+=['C:\\OTHER']
 if case=='missing-arg':args=args[:2]
 if case=='bad-operation':args[0]='BOGUS'
 if case=='wrong-cwd':env['TR7_CWD']='C:\\OTHER'
 if case=='missing-helpers':(g/'WINXT/SHELLSEL.EXE').unlink()
 if case=='bad-helper':(g/'WINXT/TSCHECK.EXE').write_bytes(b'bad')
 if case=='missing-target':t.unlink()
 if case=='unknown-target':t.write_bytes(b'unknown')
 if case=='wrong-active':(g/'WINDOWS/SYSTEM.INI').write_bytes(b'[boot]\r\nshell=PROGMAN.EXE\r\ndisplay.drv=CGA.DRV\r\n')
 if case=='duplicate-display':
  p=g/'WINDOWS/SYSTEM.INI';p.write_bytes(p.read_bytes()+b'display.drv=TR53216.DRV\r\n')
 if case=='duplicate-boot':
  p=g/'WINDOWS/SYSTEM.INI';p.write_bytes(p.read_bytes()+b'[boot]\r\n')
 if case=='nul-ini':
  p=g/'WINDOWS/SYSTEM.INI';p.write_bytes(p.read_bytes()+b'\0')
 if case=='missing-candidate':(g/'TRIAL7/NEW'/name).unlink()
 if case=='truncated-candidate':(g/'TRIAL7/NEW'/name).write_bytes(b'x')
 if case=='modified-candidate':
  p=g/'TRIAL7/NEW'/name;data=bytearray(p.read_bytes());data[2000]^=1;p.write_bytes(data)
 if case=='modified-reference':(g/'TRIAL7/TR5'/name).write_bytes(b'bad')
 if case=='modified-winxt':(g/'WINXT'/name).write_bytes(b'bad')
 if case in ['existing-backup','bad-backup']:(g/'TRIAL7/BACKUP'/name).write_bytes((D/'TR5'/name).read_bytes() if case=='existing-backup' else b'bad')
 if case=='used-marker':(g/'TRIAL7/USED.TAG').write_bytes(b'previous')
 if case.startswith('pending-'):(g/'WINDOWS'/('TSHELL.'+case[-3:].upper())).write_bytes(b'pending')
 if case=='missing-backup-dir':shutil.rmtree(g/'TRIAL7/BACKUP')
 if case=='readonly-target':t.chmod(0o444)
 if case=='restore-no-marker':args=['RESTORE',mode,'YES']
 if case=='restore-no-backup':(g/'TRIAL7/BACKUP'/name).unlink()
 if case=='restore-bad-marker':(g/'TRIAL7/USED.TAG').write_bytes(b'bad')
 if case=='restore-bad-backup':(g/'TRIAL7/BACKUP'/name).write_bytes(b'bad')
 if case=='restore-wrong-mode':args[1]='16016'
 before=snapshot(g);x=run(g,args,env);assert x.returncode!=0,(case,x.stdout,x.stderr);assert snapshot(g)==before,case;record(case,refused_without_mutation=True,returncode=x.returncode,reason=(x.stdout+x.stderr).strip())
(Q/'HOSTTEST.JSON').write_text(json.dumps({'passed':len(results),'results':results},indent=2));print('PASS',len(results),'host cases')
