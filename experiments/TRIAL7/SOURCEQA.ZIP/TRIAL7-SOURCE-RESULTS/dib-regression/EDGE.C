#define WINVER 0x0300
#include <windows.h>
#define DW 37
#define DH 11
#define GEOMS 12
#define CASES 58
/* First-party regression only: no driver instrumentation or timed loop. */
struct INFO { BITMAPINFOHEADER h; RGBQUAD c[256]; };
struct CASE { int dx,dy,w,h,sx,sy,start,scans,cl,ct,cr,cb,clip,bad; };
static struct INFO bi,saved;
static BYTE bits[4096],original[4096];
static HDC dc;
static HWND wnd;
static HCURSOR arrow;
static HFILE logf,pref,drawf,cleanf,shownf;
static int width,height,colors,done,failures;
static void note(char *key,LONG v) {
 char out[100],digits[16];int n=0,d=0;DWORD u;
 while(*key)out[n++]=*key++;out[n++]='=';
 if(v<0){out[n++]='-';u=(DWORD)(-v);}else u=(DWORD)v;
 do{digits[d++]=(char)('0'+u%10);u/=10;}while(u);
 while(d)out[n++]=digits[--d];out[n++]='\r';out[n++]='\n';
 if(_lwrite(logf,out,n)!=(UINT)n)failures++;
}
static void flushlog(void){_lclose(logf);logf=_lopen("C:\\EDGE.LOG",OF_WRITE);_llseek(logf,0L,2);}
static void snap(HFILE f){if(_lwrite(f,(const void FAR *)0xb8000000L,32768U)!=32768U)failures++;}
static int lit(int x,int y){return (((x*3+y*5)^(x/7))&3)!=0;}
static int initbits(int depth) {
 int x,y,i,stride,n;BYTE *p=(BYTE *)&bi;BYTE v;
 for(i=0;i<sizeof(bi);i++)p[i]=0;
 bi.h.biSize=40L;bi.h.biWidth=DW;bi.h.biHeight=DH;
 bi.h.biPlanes=1;bi.h.biBitCount=depth;bi.h.biCompression=BI_RGB;
 stride=((DW*depth+31)/32)*4;bi.h.biSizeImage=(DWORD)stride*DH;
 n=depth==1?2:depth==4?16:256;
 if(depth!=24)for(i=0;i<n;i++){
  v=(BYTE)(i==n-1?255:0);bi.c[i].rgbBlue=v;bi.c[i].rgbGreen=v;bi.c[i].rgbRed=v;
 }
 for(i=0;i<4096;i++)bits[i]=0xa5;
 for(y=0;y<DH;y++)for(x=0;x<DW;x++){
  i=y*stride;v=(BYTE)(lit(x,DH-1-y)?255:0);
  if(depth==1){if(x%8==0)bits[i+x/8]=0;if(v)bits[i+x/8]|=(BYTE)(128>>(x%8));}
  else if(depth==4){if(x&1)bits[i+x/2]|=(BYTE)(v&15);else bits[i+x/2]=(BYTE)(v&240);}
  else if(depth==8)bits[i+x]=v;
  else {i+=x*3;bits[i]=bits[i+1]=bits[i+2]=v;}
 }
 return stride;
}
static void setup(struct CASE *p,int n) {
 p->dx=13;p->dy=17;p->w=DW;p->h=DH;p->sx=p->sy=p->start=0;
 p->scans=DH;p->cl=p->ct=0;p->cr=width;p->cb=height;p->clip=p->bad=0;
 switch(n){
 case 1:p->dx=-5;p->dy=31;break;
 case 2:p->dx=43;p->dy=-4;break;
 case 3:p->dx=width-13;p->dy=49;break;
 case 4:p->dx=31;p->dy=195;break;
 case 5:p->dx=23;p->dy=75;p->start=3;p->scans=5;break;
 case 6:p->dx=57;p->dy=97;p->w=19;p->h=8;p->sx=2;p->sy=1;p->start=3;p->scans=5;break;
 case 7:p->dx=65;p->dy=120;p->clip=1;p->cl=69;p->ct=122;p->cr=88;p->cb=128;break;
 case 8:p->dx=7;p->dy=141;p->w=p->h=1;p->sx=5;p->sy=3;break;
 case 9:p->dx=width-37;p->dy=189;p->clip=1;p->cl=width-1;p->ct=199;p->cr=width;p->cb=200;break;
 case 10:p->dx=17;p->dy=160;p->start=10;p->scans=5;break;
 case 11:p->dx=0;p->dy=0;p->start=3;p->scans=5;p->clip=1;p->cl=10;p->ct=4;p->cr=26;p->cb=7;break;
 case 12:p->scans=0;break;
 case 13:p->start=DH;break;
 case 14:p->dx=width+3;break;
 case 15:p->dy=-12;break;
 case 16:p->clip=1;p->cl=p->cr=20;break;
 case 17:p->bad=1;break;
 case 18:p->bad=2;break;
 case 19:p->bad=3;break;
 case 20:p->bad=4;break;
 case 21:p->bad=5;break;
 }
}
static void one(int id) {
 struct CASE p;HRGN region=0;POINT pt;int geom,depth,stride,bg,cx,cy,ret,i,changed=0;
 BYTE *bp,*sp;
 if(id<48){geom=id%GEOMS;depth=id/GEOMS;depth=depth==0?1:depth==1?4:depth==2?8:24;}
 else {geom=id-48+12;depth=4;}
 setup(&p,geom);stride=initbits(depth);bg=id&1;if(geom==9)bg=0;
 if(p.bad==1)bi.h.biCompression=1L;
 if(p.bad==2)bi.h.biCompression=2L;
 if(p.bad==3)bi.h.biCompression=256L;
 if(p.bad==4)bi.h.biHeight=-DH;
 if(p.bad==5)bi.h.biWidth=0;
 saved=bi;for(i=0;i<4096;i++)original[i]=bits[i];
 SelectClipRgn(dc,NULL);ShowCursor(FALSE);
 if(!PatBlt(dc,0,0,width,height,bg?WHITENESS:BLACKNESS))failures++;
 cx=p.dx+2;cy=p.dy+p.h-(p.start+p.scans-p.sy)+1;
 if(cx<p.cl)cx=p.cl;if(cy<p.ct)cy=p.ct;
 if(cx<0)cx=0;if(cx>=width-2)cx=width-4;
 if(cy<0)cy=0;if(cy>=height-2)cy=height-4;
 if(geom==0){cx=width-24;cy=height-24;}
 SetCursor(arrow);SetCursorPos(cx,cy);GetCursorPos(&pt);ShowCursor(TRUE);snap(pref);
 if(p.clip){region=CreateRectRgn(p.cl,p.ct,p.cr,p.cb);if(!region)failures++;SelectClipRgn(dc,region);}
 note("CASE",id);note("GEOM",geom);note("BPP",depth);note("BG",bg);
 note("DX",p.dx);note("DY",p.dy);note("W",p.w);note("H",p.h);
 note("SX",p.sx);note("SY",p.sy);note("START",p.start);note("SCANS",p.scans);
 note("CL",p.cl);note("CT",p.ct);note("CR",p.cr);note("CB",p.cb);note("CLIP",p.clip);
 note("BAD",p.bad);note("CX",pt.x);note("CY",pt.y);flushlog();
 ret=SetDIBitsToDevice(dc,p.dx,p.dy,p.w,p.h,p.sx,p.sy,p.start,p.scans,
   bits+p.start*stride,(BITMAPINFO FAR *)&bi,DIB_RGB_COLORS);
 snap(drawf);ShowCursor(FALSE);snap(cleanf);ShowCursor(TRUE);snap(shownf);
 for(i=0;i<4096;i++)if(bits[i]!=original[i])changed++;
 bp=(BYTE *)&bi;sp=(BYTE *)&saved;for(i=0;i<sizeof(bi);i++)if(bp[i]!=sp[i])changed++;
 note("RETURN",ret);note("INPUT_CHANGED",changed);note("ENDCASE",id);flushlog();
 if(changed)failures++;SelectClipRgn(dc,NULL);if(region)DeleteObject(region);
}
static void run(HWND w) {
 int i,ret;dc=GetDC(w);width=GetDeviceCaps(dc,HORZRES);height=GetDeviceCaps(dc,VERTRES);colors=GetDeviceCaps(dc,NUMCOLORS);
 logf=_lcreat("C:\\EDGE.LOG",0);pref=_lcreat("C:\\EPRE.BIN",0);drawf=_lcreat("C:\\EDRAW.BIN",0);cleanf=_lcreat("C:\\ECLEAN.BIN",0);shownf=_lcreat("C:\\ESHOW.BIN",0);
 note("VERSION",1);note("FLAGS",GetWinFlags());note("WIDTH",width);note("HEIGHT",height);note("COLORS",colors);note("CASES",CASES);
 arrow=LoadCursor(0,IDC_ARROW);note("CURSOR_LOADED",arrow!=NULL);
 do{ret=ShowCursor(FALSE);}while(ret>=0);ShowCursor(TRUE);
 for(i=0;i<CASES;i++)one(i);
 note("FAILURES",failures);note("COMPLETE",1);_lclose(pref);_lclose(drawf);_lclose(cleanf);_lclose(shownf);_lclose(logf);ReleaseDC(w,dc);PostMessage(w,WM_CLOSE,0,0);
}
LONG FAR PASCAL WndProc(HWND w,UINT m,WORD p,LONG l) {
 if(m==WM_TIMER){KillTimer(w,1);if(!done){done=1;run(w);}return 0;}
 if(m==WM_DESTROY){PostQuitMessage(0);return 0;}return DefWindowProc(w,m,p,l);
}
int PASCAL WinMain(HANDLE inst,HANDLE prev,LPSTR cmd,int show) {
 WNDCLASS c;MSG m;c.style=0;c.lpfnWndProc=WndProc;c.cbClsExtra=c.cbWndExtra=0;
 c.hInstance=inst;c.hIcon=0;c.hCursor=LoadCursor(0,IDC_ARROW);c.hbrBackground=GetStockObject(BLACK_BRUSH);c.lpszMenuName=0;c.lpszClassName="DIBEdgesV1";
 RegisterClass(&c);wnd=CreateWindow("DIBEdgesV1","DIB edges",WS_POPUP,0,0,GetSystemMetrics(SM_CXSCREEN),GetSystemMetrics(SM_CYSCREEN),0,0,inst,0);
 ShowWindow(wnd,show);UpdateWindow(wnd);SetTimer(wnd,1,100,0);
 while(GetMessage(&m,0,0,0)){TranslateMessage(&m);DispatchMessage(&m);}return m.wParam;
}
