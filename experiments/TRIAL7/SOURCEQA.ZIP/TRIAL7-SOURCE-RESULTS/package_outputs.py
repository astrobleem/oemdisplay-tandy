#!/usr/bin/env python3
"""Allow-listed private Trial7 deliverables. Never includes guest OS/tools."""
from pathlib import Path
import difflib,hashlib,json,shutil,zipfile
P=Path(__file__).resolve().parent;OUT=P/'deliverables';STAGE=OUT/'TRIAL7-SOURCE-RESULTS'
TEXT={'.py','.c','.h','.asm','.def','.rsp','.bat','.cnf','.log','.json','.jsn','.txt','.sha','.patch'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def copy(src,dst=None):
 src=P/src;dst=STAGE/(dst or src.relative_to(P));assert src.is_file(),src;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
def main():
 assert json.loads((P/'PAIRED-SUMMARY.json').read_text())['complete']
 assert json.loads((P/'scope-tests/SUMMARY.json').read_text())['passed']
 assert json.loads((P/'line-tests/SUMMARY.json').read_text())['passed']
 assert (P/'EVERYDAY-REPORT.TXT').exists() and (P/'PACKAGE-REPORT.TXT').exists()
 OUT.mkdir(exist_ok=True);assert not STAGE.exists(),'Use a fresh delivery stage or inspect existing output first';STAGE.mkdir()
 for n in ['REPORT.TXT','EVERYDAY-REPORT.TXT','PACKAGE-REPORT.TXT','SOURCE-DELTA.patch','CANDIDATES.json','REFERENCE-PINS.json','FROZEN-BUILDS.json','SOURCE-SCOPE.json','MONO-POLICY-PIXELS.json','PAIRED-SUMMARY.json','verify_builds.py','build_variants.py','run_benchmark.py','collect_results.py','make_report.py','run_remaining_benchmarks.py','package_outputs.py']:
  copy(n)
 for n in ['BUILD88.PY','BLDTR6.PY','BLDTR5.PY','DIBBOUND.PY','BORDER7.PY','TEXT7.PY']:
  copy('source/src/tandysw/'+n)
 for d in ['baseline','bench-build']:
  for f in (P/d).rglob('*'):
   if f.is_file() and f.suffix.lower() in TEXT and '__pycache__' not in f.parts:copy(f.relative_to(P))
 for tag in ['tr6','border','text','combined']:
  for mode in json.loads((P/'REFERENCE-PINS.json').read_text()):
   r=Path('bench-'+tag)/mode
   for n in ['RESULT.json','VALIDATION.json','RUN.CNF']:copy(r/n)
   if (P/r/'PROVENANCE.json').exists():copy(r/'PROVENANCE.json')
   for n in ['BENCH.LOG','CPUCHECK.TXT','LATERCPU.TXT','RESERVE.TXT','RETURNED.TXT']:copy(r/'guest'/n,r/n)
 for tag in ['border','text','combined']:
  for mode in json.loads((P/'REFERENCE-PINS.json').read_text()):
   r=Path('builds')/tag/mode
   for n in ['RESULT.json','BUILD.CNF']:copy(r/n)
   for n in ['BUILD0.LOG','LINK.LOG']:copy(r/'renderer/EGA'/n,r/n)
 for d in ['scope-tests','dib-regression','line-tests']:
  for f in (P/d).iterdir():
   if f.is_file() and f.suffix.lower() in TEXT and f.name not in {'VERIFIED.LOG','DEFAULT.LOG','HOSTBUILD.LOG'}:copy(f.relative_to(P))
  runs=(P/d/'verified-v2').glob('run-*') if d=='line-tests' else (P/d).glob('run-*')
  for run in runs:
   for mode in run.iterdir():
    if not mode.is_dir():continue
    dst=Path(d)/run.name/mode.name
    for n in ['RESULT.json','CHECK.json','RUN.CNF']:
     if (mode/n).exists():copy((mode/n).relative_to(P),dst/n)
    for n in ['SCOPE.LOG','EDGE.LOG','LINE.LOG','CPUCHECK.TXT','LATERCPU.TXT','RESERVE.TXT','RETURNED.TXT']:
     f=mode/'guest'/n
     if f.exists():copy(f.relative_to(P),dst/n)
 for d in ['border7-checks','text-evidence']:
  for f in (P/d).rglob('*'):
   if not f.is_file() or f.suffix.lower() not in TEXT:continue
   rel=f.relative_to(P);parts=rel.parts
   if any('failed' in part.lower() or part in {'mock','__pycache__','policy-v2','opt16016','opt32016','opt3204','opt6404','opt6402'} for part in parts):continue
   # Explicit evidence/source only; no listing, object, binary or DDK fixture.
   if any(part.startswith('fixture') for part in parts):continue
   copy(rel)
 native=P/'everyday-tests/PUBLICATION';assert native.is_dir(),'Native allow-listed export missing'
 for f in native.rglob('*'):
  if f.is_file():
   assert f.suffix.lower() in TEXT|{'.png','.bin'},f
   if f.suffix.lower()=='.bin':assert f.name.startswith('D') and f.stat().st_size in (16384,32768),f
   copy(f.relative_to(P),Path('everyday-tests')/f.relative_to(native))
 # The kit worker produces a first-party QA export with no guest/toolchain.
 qa=P/'package/QA-EXPORT';assert qa.is_dir(),'Kit QA export missing'
 for f in qa.rglob('*'):
  if f.is_file():
   assert f.suffix.lower() in TEXT,f
   copy(f.relative_to(P),Path('package/qa')/f.relative_to(qa))
 for f in (P/'package/TRIAL7/SOURCE').rglob('*'):
  if f.is_file() and f.suffix.lower() in TEXT:copy(f.relative_to(P),Path('package/SOURCE')/f.relative_to(P/'package/TRIAL7/SOURCE'))
 readme='''TRIAL7 BORDERS AND TEXT SOURCE AND RESULTS

Read REPORT.TXT first. This is a private experimental source overlay and
verified evidence. It is not an installation disk or a hardware acceptance.
The separate TRIAL7 rollback-driver ZIP is the optional hardware test kit.

The source/src/tandysw subtree overlays exact project commit
1eac04fdc571f73037b502ecf1f085028271866e. It includes the new builder,
exact historical TR5/TR6 builders, retained TR6 DIB transform, and isolated
BORDER7/TEXT7 transforms. Original authorized repository/DDK/compiler and
Windows media are prerequisites and are intentionally not redistributed.

Main benchmark, independent/differential GDI suites, bounds/ABI probes,
actual native Notepad/Paintbrush workflows and rollback helper QA are
separate evidence sets. Pixel equality does not convert guest timings into
physical timings. See each report for coverage and remaining caveats.

No release or prior TR5/TR6 artifact was replaced. No user computer or CF
was modified. Never redistribute your Windows installation or toolchain.
'''
 (STAGE/'README.TXT').write_bytes(readme.replace('\n','\r\n').encode())
 files={str(f.relative_to(STAGE)):sha(f) for f in sorted(STAGE.rglob('*')) if f.is_file()}
 (STAGE/'CONTENTS-SHA256.json').write_text(json.dumps(files,indent=2)+'\n')
 records=[]
 for root,name in [(STAGE,'TRIAL7-BORDERS-TEXT-SOURCE-AND-RESULTS.zip'),(P/'package/TRIAL7','TRIAL7-BORDERS-TEXT-ROLLBACK-DRIVERS.zip')]:
  dest=OUT/name;assert not dest.exists()
  with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,9) as z:
   for f in sorted(root.rglob('*')):
    if f.is_file():z.write(f,str(Path(root.name)/f.relative_to(root)))
  with zipfile.ZipFile(dest) as z:
   assert z.testzip() is None
   names=z.namelist()
   if root==STAGE:assert not any(Path(n).suffix.upper() in {'.EXE','.DRV','.DLL','.COM','.FON','.OBJ','.LST','.LIB'} for n in names)
   assert not any('/guest/' in n or '/local-runs/' in n or '/library-helpers/' in n for n in names)
  records.append({'path':str(dest),'bytes':dest.stat().st_size,'sha256':sha(dest),'files':len(names)})
 (OUT/'ARTIFACTS.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(records,indent=2))
if __name__=='__main__':main()
