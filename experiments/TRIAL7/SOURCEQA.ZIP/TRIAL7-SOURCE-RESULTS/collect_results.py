#!/usr/bin/env python3
from pathlib import Path
import hashlib,importlib.util,json
P=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('baseline_validator',P/'baseline/validate.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
MODES=list(json.loads((P/'REFERENCE-PINS.json').read_text()));TAGS=['tr6','border','text','combined']
def collect():
 summary={'complete':False,'modes':[],'total_batches':0,'total_api_calls':0}
 for mode in MODES:
  if not all((P/('bench-'+t)/mode/'RESULT.json').exists() for t in TAGS):continue
  results={}
  for tag in TAGS:
   v.P=P/('bench-'+tag);results[tag]=v.validate(mode);expected_path=(P/'references'/json.loads((P/'REFERENCE-PINS.json').read_text())[mode]['tr6_file']) if tag=='tr6' else (P/'builds'/tag/mode/json.loads((P/'REFERENCE-PINS.json').read_text())[mode]['driver']);assert results[tag]['driver_sha256']==hashlib.sha256(expected_path.read_bytes()).hexdigest(),(tag,mode,'stale driver result');assert results[tag]['passed'],(tag,mode,results[tag]['checks']);raw=json.loads((v.P/mode/'RESULT.json').read_text());_,rows=v.parse(raw['log']);summary['total_batches']+=len(rows);summary['total_api_calls']+=sum(r['CALLS'] for r in rows)
  pairs={};active=v.PROFILES[mode][2]*8192
  for tag in TAGS[1:]:
   pairs[tag]={}
   for n in ['PRE','DRAW','CLEAN','RESHOW']:
    a=(P/'bench-tr6'/mode/'guest'/(n+'.BIN')).read_bytes();b=(P/('bench-'+tag)/mode/'guest'/(n+'.BIN')).read_bytes();aa=b''.join(a[i*32768:i*32768+active] for i in range(24));bb=b''.join(b[i*32768:i*32768+active] for i in range(24));pairs[tag][n]={'active_vram_equal':aa==bb,'entire_32768_equal':a==b,'active_bytes':len(aa),'reference_sha256':hashlib.sha256(aa).hexdigest(),'candidate_sha256':hashlib.sha256(bb).hexdigest()};assert aa==bb,(mode,tag,n)
  timing=[]
  for i,before in enumerate(results['tr6']['timings']):
   t={'case':before['case'],'tr6_ms':before['median_ms_per_call']}
   for tag in TAGS[1:]:
    after=results[tag]['timings'][i];assert before['case']==after['case'];a,b=before['median_ms_per_call'],after['median_ms_per_call'];t[tag+'_ms']=b;t[tag+'_speedup']=a/b;t[tag+'_reduction_percent']=100*(1-b/a)
   t['replicate_details']={tag:results[tag]['timings'][i] for tag in TAGS};timing.append(t)
  hist=json.loads((P.parent/'dib-opt-20261005/bench-tr6'/mode/'VALIDATION.json').read_text());exact=all(a['median_ms_per_call']==b['median_ms_per_call'] for a,b in zip(hist['timings'],results['tr6']['timings']))
  summary['modes'].append({'mode':mode,'passed':True,'driver_sha256':{tag:results[tag]['driver_sha256'] for tag in TAGS},'old_tr6_medians_reproduced_exactly':exact,'frames':pairs,'timings':timing})
 summary['complete']=len(summary['modes'])==5;(P/'PAIRED-SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n');return summary
if __name__=='__main__':
 s=collect()
 for r in s['modes']:
  print(r['mode'],'PASS','old TR6 exact',r['old_tr6_medians_reproduced_exactly']);print([(t['case'],round(t['tr6_ms'],3),round(t['border_ms'],3),round(t['text_ms'],3),round(t['combined_ms'],3)) for t in r['timings']])
 print('Complete',s['complete'],'batches',s['total_batches'],'calls',s['total_api_calls'])
