from pathlib import Path
import subprocess,fcntl,json
P=Path(__file__).resolve().parent
modes=json.loads((P/'REFERENCE-PINS.json').read_text())
for variant in ['combined','border','text']:
 for mode in modes:
  if mode=='320x200x16' and variant!='combined':continue
  out=P/'builds'/variant/mode
  if out.exists():
   assert (out/'RESULT.json').exists(),out
   continue
  out.parent.mkdir(parents=True,exist_ok=True)
  with (P/'emulator.lock').open('w') as lock:
   fcntl.flock(lock,fcntl.LOCK_EX)
   with (out.parent/(mode+'.log')).open('w') as log:
    print('BUILD',variant,mode,flush=True)
    subprocess.run(['python3',str(P/'source/src/tandysw/BUILD88.PY'),'--trial7',variant,'--dosbox','/workspace/shared/dosbox-x/run','--mode',mode,'--out',str(out)],stdout=log,stderr=subprocess.STDOUT,check=True)
  r=json.loads((out/'RESULT.json').read_text());print('PASS',variant,mode,r['driver_sha256'],flush=True)
