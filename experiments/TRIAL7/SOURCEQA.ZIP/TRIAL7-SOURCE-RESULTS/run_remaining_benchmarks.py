#!/usr/bin/env python3
from pathlib import Path
import subprocess,time,sys
P=Path(__file__).resolve().parent
for mode in ['320x200x4','640x200x4','640x200x2']:
 while not all((P/'builds'/v/mode/'RESULT.json').exists() for v in ['border','text','combined']):
  print('Awaiting built variants',mode,flush=True);time.sleep(30)
 print('BENCHMARK MODE',mode,flush=True)
 subprocess.run([sys.executable,str(P/'run_benchmark.py'),'--modes',mode],check=True)
 subprocess.run([sys.executable,str(P/'collect_results.py')],check=True)
