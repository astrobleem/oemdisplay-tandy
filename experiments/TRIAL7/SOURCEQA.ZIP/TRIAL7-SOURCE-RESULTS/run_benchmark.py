#!/usr/bin/env python3
"""Serial matched TR5/TR6 benchmark using the unchanged verified-v3 EXE.
Local Windows/toolchain files are required and are never bundled.
"""
from pathlib import Path
import argparse,shutil,os,subprocess,time,json,hashlib,re,datetime,fcntl
P=Path(__file__).resolve().parent
FIXTURE=Path(os.environ.get('DIB_TRIAL_FIXTURE','/workspace/shared/windows30/round05-c'))
DOSBOX=os.environ.get('DIB_TRIAL_DOSBOX','/workspace/shared/dosbox-x/run')
MODES=json.loads((P/'REFERENCE-PINS.json').read_text())

def driver_for(variant,mode):
    if variant=='tr6':return P/'references'/MODES[mode]['tr6_file']
    return P/'builds'/variant/mode/MODES[mode]['driver']

sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def ini(path,section,key,value):
    lines=path.read_text().splitlines();target=False;found=False;out=[]
    for line in lines:
        if line.strip().startswith('['):
            if target and not found:out.append(key+'='+value);found=True
            target=line.strip().lower()=='['+section.lower()+']'
        if target and '=' in line and line.split('=',1)[0].strip().lower()==key.lower():
            out.append(key+'='+value);found=True
        else:out.append(line)
    if not found:
        if not target:out.append('['+section+']')
        out.append(key+'='+value)
    path.write_bytes(('\r\n'.join(out)+'\r\n').encode('latin1'))

def prepare_guest(g,driver,exe):
    g.mkdir()
    shutil.copytree(FIXTURE/'WINDOWS',g/'WINDOWS')
    for name in ['RESERVE.COM','CPUCHECK.COM','LATERCPU.COM']:
        shutil.copyfile(FIXTURE/name,g/name)
    shutil.copyfile(exe,g/'WINDOWS'/exe.name)
    shutil.copyfile(driver,g/'WINDOWS/SYSTEM/TRIAL.DRV')
    ini(g/'WINDOWS/SYSTEM.INI','boot','display.drv','TRIAL.DRV')
    ini(g/'WINDOWS/SYSTEM.INI','boot','shell',exe.name)
    # The lost baseline fixture started in 160-mode. Use CGA font filenames
    # in this reconstructed paired fixture; exact old INI bytes are unavailable.
    for key,value in [('fonts.fon','cgasys.fon'),('fixedfon.fon','cgafix.fon'),('oemfonts.fon','cgaoem.fon')]:
        ini(g/'WINDOWS/SYSTEM.INI','boot',key,value)
    ini(g/'WINDOWS/WIN.INI','windows','run','')
    ini(g/'WINDOWS/WIN.INI','windows','load','')
    (g/'START.BAT').write_bytes(b'@ECHO OFF\r\nCD \\\r\nCPUCHECK > CPUCHECK.TXT\r\nLATERCPU > LATERCPU.TXT\r\nRESERVE > RESERVE.TXT\r\nIF ERRORLEVEL 1 GOTO BAD\r\nSET PATH=C:\\WINDOWS;Z:\\\r\nSET TEMP=C:\\WINDOWS\\TEMP\r\nCD WINDOWS\r\nWIN /R\r\nCD \\\r\nECHO RETURNED > RETURNED.TXT\r\nGOTO DONE\r\n:BAD\r\nECHO RESERVE_FAILED > RETURNED.TXT\r\n:DONE\r\nEXIT\r\n')

def run(variant,mode):
    p=P/('bench-'+variant)/mode
    if (p/'RESULT.json').exists():
        r=json.loads((p/'RESULT.json').read_text())
        if r['completed']:print('SKIP',variant,mode,flush=True);return
    p.mkdir(parents=True);g=p/'guest'
    drv=driver_for(variant,mode)
    expected=sha(drv);exe=P/'bench-build/BENCH.EXE'
    assert sha(exe)=='f5b0e3f3f9b32c1087e37f19ce5e67b5f097e8c7f6b71f4096a3faec37af080b'
    prepare_guest(g,drv,exe)
    s=(P/'baseline'/mode/'RUN.CNF').read_text().split('[autoexec]')[0]
    s=re.sub(r'captures=.*', 'captures='+str(p/'captures'),s)
    s+='[autoexec]\nmount C "'+str(g)+'"\nC:\nSTART.BAT\n';conf=p/'RUN.CNF';conf.write_text(s)
    env=os.environ.copy();env.update(SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy')
    t=time.monotonic();start=datetime.datetime.now(datetime.timezone.utc).isoformat();print('START',variant,mode,start,flush=True)
    with (p/'HOST.LOG').open('w') as f:
        pr=subprocess.Popen([DOSBOX,'-nopromptfolder','-conf',str(conf)],env=env,stdout=f,stderr=subprocess.STDOUT)
        (p/'PID').write_text(str(pr.pid));last=-1
        while pr.poll() is None:
            time.sleep(5)
            log=(g/'BENCH.LOG').read_text() if (g/'BENCH.LOG').exists() else ''
            count=len(re.findall(r'^CASE=',log,re.M))
            if count!=last:print(variant,mode,'batches',count,'seconds',round(time.monotonic()-t,1),flush=True);last=count
            if time.monotonic()-t>1200:pr.kill();pr.wait();raise RuntimeError('timeout '+mode)
    log=(g/'BENCH.LOG').read_text()
    r={'mode':mode,'variant':variant,'started_utc':start,'driver_path':str(drv.relative_to(P)),'driver_sha256':sha(drv),'installed_driver_sha256':sha(g/'WINDOWS/SYSTEM/TRIAL.DRV'),'benchmark_sha256':sha(exe),'config_sha256':sha(conf),'host_seconds':time.monotonic()-t,'host_return':pr.returncode,'completed':'COMPLETE=1' in log,'log':log,'dos_return':(g/'RETURNED.TXT').read_text() if (g/'RETURNED.TXT').exists() else None}
    r['files']={n:{'bytes':(g/n).stat().st_size,'sha256':sha(g/n)} for n in ['BENCH.LOG','PRE.BIN','DRAW.BIN','CLEAN.BIN','RESHOW.BIN']}
    (p/'RESULT.json').write_text(json.dumps(r,indent=2))
    assert r['completed'] and r['host_return']==0 and r['dos_return'].strip()=='RETURNED' and 'FAILURES=0' in log and 'FLAGS=64' in log
    assert r['driver_sha256']==r['installed_driver_sha256']==expected
    print('FINISH',variant,mode,round(r['host_seconds'],1),flush=True)

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--modes',nargs='+',default=list(MODES));a.add_argument('--variants',nargs='+',default=['tr6','border','text','combined']);args=a.parse_args()
    # Pause between complete mode blocks for other authorized emulator work.
    while (P/'PAUSE-BENCHMARKS').exists():time.sleep(1)
    lock=(P/'emulator.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX)
    for mode in args.modes:
        for variant in args.variants:run(variant,mode)
