#define WINVER 0x0300
#include <windows.h>
/* Native app integration driver. No synthetic application painting. */
static HWND self,app,edit;
static HINSTANCE application;
static HFILE logf;
static int pass,kind,step,ticks,waits,failures,width,height,colors,menus,closed,reopened;
static WORD undo;
static RECT original;
static char *commands[]={"NOTEPAD.EXE C:\\WORDS.TXT","PBRUSH.EXE SCENE.BMP","NOTEPAD.EXE C:\\WORDS.TXT"};
static void text(char *s){_lwrite(logf,s,lstrlen(s));_lwrite(logf,"\r\n",2);}
static void note(char *key,LONG v){char out[100],digits[16];int n=0,d=0;DWORD u;while(*key)out[n++]=*key++;out[n++]='=';if(v<0){out[n++]='-';u=(DWORD)(-v);}else u=(DWORD)v;do{digits[d++]=(char)('0'+u%10);u/=10;}while(u);while(d)out[n++]=digits[--d];out[n]=0;text(out);}
static void flush(void){char n[]="C:\\DAY1.LOG";n[6]=(char)('0'+pass);_lclose(logf);logf=_lopen(n,OF_WRITE);_llseek(logf,0L,2);}
static void snap(int id){char n[]="C:\\D1000.BIN";HFILE f;UINT bytes=((width==320&&colors==16)||(width==640&&colors==4))?32768U:16384U;n[4]=(char)('0'+pass);n[5]=(char)('0'+kind);n[6]=(char)('0'+id/10);n[7]=(char)('0'+id%10);f=_lcreat(n,0);if(_lwrite(f,(const void FAR *)0xb8000000L,bytes)!=bytes)failures++;_lclose(f);note("SNAPSHOT",kind*100+id);flush();}
static HWND findapp(void){HWND w=GetWindow(self,GW_HWNDFIRST);while(w){if(w!=self&&GetWindowWord(w,GWW_HINSTANCE)==application&&IsWindowVisible(w)&&!GetWindow(w,GW_OWNER))return w;w=GetWindow(w,GW_HWNDNEXT);}return 0;}
static HWND findedit(HWND w){HWND h=GetWindow(w,GW_CHILD);char c[40];while(h){GetClassName(h,c,40);if(!lstrcmpi(c,"edit"))return h;h=GetWindow(h,GW_HWNDNEXT);}return 0;}
static int contains(char *s,char *t){int i,j;for(i=0;s[i];i++){for(j=0;t[j]&&s[i+j]==t[j];j++);if(!t[j])return 1;}return 0;}
static void describe(void){char c[100];HWND h;RECT r;GetWindowText(app,c,100);text(c);GetClassName(app,c,100);text(c);GetWindowRect(app,&r);note("LEFT",r.left);note("TOP",r.top);note("RIGHT",r.right);note("BOTTOM",r.bottom);note("MENU_COUNT",GetMenuItemCount(GetMenu(app)));note("APP_VPOS",GetScrollPos(app,SB_VERT));h=GetWindow(app,GW_CHILD);while(h){GetClassName(h,c,100);text(c);note("CHILD_STYLE",GetWindowLong(h,GWL_STYLE));note("CHILD_VPOS",GetScrollPos(h,SB_VERT));note("CHILD_HPOS",GetScrollPos(h,SB_HORZ));h=GetWindow(h,GW_HWNDNEXT);}flush();}
static void finish(void){note("NATIVE_MENU_OPENS",menus);note("NATIVE_APP_CLOSES",closed);note("NATIVE_APP_REOPEN",reopened);note("FAILURES",failures);note("COMPLETE",1);_lclose(logf);KillTimer(self,1);PostMessage(self,WM_CLOSE,0,0);}
static void next(void){kind++;step=0;waits=0;if(kind==3)finish();}
static void tick(void){HWND h;note("STEP",kind*100+step);flush();
 switch(step){
 case 0:application=(HINSTANCE)WinExec(commands[kind],SW_SHOWNORMAL);note("WINEXEC",application);flush();if(application<32){failures++;next();return;}step=1;return;
 case 1:app=findapp();if(!app){if(++waits>60){text("APP_NOT_FOUND");failures++;next();}return;}ShowWindow(app,SW_SHOWNORMAL);SetWindowPos(app,HWND_TOP,0,0,width,height,SWP_SHOWWINDOW);BringWindowToTop(app);edit=findedit(app);waits=0;step=2;return;
 case 2:{char title[100];GetWindowText(app,title,100);note("EXPECTED_DOCUMENT_LOADED",contains(title,kind==1?"SCENE.BMP":"WORDS.TXT"));if(!contains(title,kind==1?"SCENE.BMP":"WORDS.TXT"))failures++;}describe();GetWindowRect(app,&original);if(kind==2){reopened++;step=24;return;}snap(0);step=3;return;
 case 3:case 6:case 9:PostMessage(app,WM_SYSCOMMAND,SC_KEYMENU,'f');menus++;step++;return;
 case 4:case 7:case 10:snap(step);PostMessage(app,WM_KEYDOWN,VK_ESCAPE,1L);PostMessage(app,WM_KEYUP,VK_ESCAPE,0xc0000001L);PostMessage(app,WM_KEYDOWN,VK_ESCAPE,1L);PostMessage(app,WM_KEYUP,VK_ESCAPE,0xc0000001L);step++;return;
 case 5:case 8:case 11:snap(step);step++;return;
 case 12:MoveWindow(app,11,9,width-23,height-25,TRUE);step++;return;
 case 13:describe();snap(13);MoveWindow(app,0,0,width,height,TRUE);step++;return;
 case 14:snap(14);MoveWindow(app,-9,7,width+17,height-19,TRUE);step++;return;
 case 15:describe();snap(15);MoveWindow(app,0,0,width,height,TRUE);step++;return;
 case 16:snap(16);if(edit)PostMessage(edit,WM_VSCROLL,SB_PAGEDOWN,0L);else {PostMessage(app,WM_VSCROLL,SB_PAGEDOWN,0L);h=GetWindow(app,GW_CHILD);while(h){PostMessage(h,WM_VSCROLL,SB_PAGEDOWN,0L);h=GetWindow(h,GW_HWNDNEXT);}}step++;return;
 case 17:describe();note("NATIVE_VERTICAL_SCROLL_POS",GetScrollPos(edit?app:GetWindow(app,GW_CHILD),SB_VERT));snap(17);if(edit)PostMessage(edit,WM_VSCROLL,SB_PAGEUP,0L);else {PostMessage(app,WM_VSCROLL,SB_TOP,0L);h=GetWindow(app,GW_CHILD);while(h){PostMessage(h,WM_VSCROLL,SB_TOP,0L);h=GetWindow(h,GW_HWNDNEXT);}}step++;return;
 case 18:note("RESTORED_VERTICAL_SCROLL_POS",GetScrollPos(edit?app:GetWindow(app,GW_CHILD),SB_VERT));snap(18);ShowWindow(app,SW_MINIMIZE);step++;return;
 case 19:snap(19);ShowWindow(app,SW_RESTORE);BringWindowToTop(app);step++;return;
 case 20:snap(20);if(kind==1){h=GetWindow(app,GW_CHILD);PostMessage(h,WM_LBUTTONDOWN,MK_LBUTTON,MAKELONG(21,21));PostMessage(h,WM_MOUSEMOVE,MK_LBUTTON,MAKELONG(29,25));PostMessage(h,WM_MOUSEMOVE,MK_LBUTTON,MAKELONG(37,29));PostMessage(h,WM_LBUTTONUP,0,MAKELONG(37,29));step=26;}else {PostMessage(app,WM_SYSCOMMAND,SC_KEYMENU,'f');menus++;step++;}return;
 case 21:snap(21);PostMessage(app,WM_KEYDOWN,VK_ESCAPE,1L);PostMessage(app,WM_KEYUP,VK_ESCAPE,0xc0000001L);PostMessage(app,WM_KEYDOWN,VK_ESCAPE,1L);PostMessage(app,WM_KEYUP,VK_ESCAPE,0xc0000001L);step++;return;
 case 22:snap(22);step=24;return;
 case 26:snap(26);undo=GetMenuItemID(GetSubMenu(GetMenu(app),1),0);note("PAINTBRUSH_UNDO_COMMAND",undo);note("PAINTBRUSH_UNDO_STATE",GetMenuState(GetSubMenu(GetMenu(app),1),0,MF_BYPOSITION));PostMessage(app,WM_COMMAND,undo,0L);step=27;return;
 case 27:snap(27);PostMessage(app,WM_SYSCOMMAND,SC_KEYMENU,'f');menus++;step=21;return;
 case 24:PostMessage(app,WM_CLOSE,0,0L);step++;return;
 case 25:if(IsWindow(app)){h=GetLastActivePopup(app);if(kind==1&&h!=app&&GetDlgItem(h,IDNO)){text("PAINTBRUSH_SAVE_PROMPT_DISCARD");PostMessage(h,WM_COMMAND,IDNO,MAKELONG(GetDlgItem(h,IDNO),BN_CLICKED));}if(++waits>30){text("APP_CLOSE_TIMEOUT");describe();failures++;finish();}return;}closed++;next();return;
 }
}
LONG FAR PASCAL WndProc(HWND w,UINT m,WORD p,LONG l){if(m==WM_TIMER){if(++ticks>400){text("HARNESS_TIMEOUT");failures++;finish();}else tick();return 0;}if(m==WM_DESTROY){PostQuitMessage(0);return 0;}return DefWindowProc(w,m,p,l);}
int PASCAL WinMain(HANDLE inst,HANDLE prev,LPSTR cmd,int show){WNDCLASS c;MSG m;HFILE f;HDC d;char n[]="C:\\DAY1.LOG";
 f=_lopen("C:\\PASS1.OK",OF_READ);if(f>=0){_lclose(f);pass=2;}else {pass=1;f=_lcreat("C:\\PASS1.OK",0);_lclose(f);}n[6]=(char)('0'+pass);logf=_lcreat(n,0);
 c.style=0;c.lpfnWndProc=WndProc;c.cbClsExtra=c.cbWndExtra=0;c.hInstance=inst;c.hIcon=0;c.hCursor=LoadCursor(0,IDC_ARROW);c.hbrBackground=GetStockObject(WHITE_BRUSH);c.lpszMenuName=0;c.lpszClassName="NativeDay7";RegisterClass(&c);self=CreateWindow("NativeDay7","Native Windows app validation",WS_POPUP,0,0,0,0,0,0,inst,0);
 d=GetDC(0);width=GetDeviceCaps(d,HORZRES);height=GetDeviceCaps(d,VERTRES);note("FLAGS",GetWinFlags());note("WIDTH",width);note("HEIGHT",height);colors=GetDeviceCaps(d,NUMCOLORS);note("COLORS",colors);note("PASS",pass);ReleaseDC(0,d);SetCursorPos(width-1,height-1);SetTimer(self,1,350,0);while(GetMessage(&m,0,0,0)){TranslateMessage(&m);DispatchMessage(&m);}return m.wParam;
}
