#!/usr/bin/env python3
"""Write an evidence-backed plain-text engineering report after final checks."""
from pathlib import Path
import hashlib,json,datetime,textwrap
P=Path(__file__).resolve().parent
get=lambda p:json.loads((P/p).read_text())
def main():
 s=get('PAIRED-SUMMARY.json');build=get('CANDIDATES.json');scope=get('scope-tests/SUMMARY.json');dib=get('dib-regression/SUMMARY.json');lines=get('line-tests/SUMMARY.json')
 assert s['complete'] and scope['passed'] and dib['completed'] and all(r['passed'] for r in dib['results']) and lines['passed']
 out=[];put=out.append
 put('TRIAL7 BORDERS AND TEXT PERFORMANCE REPORT')
 put('WindowsXT / Windows 3.0 real-mode Tandy display driver')
 put('Generated '+datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%d %H:%M UTC'))
 put('')
 put('RESULT')
 put('TRIAL7 combines narrowly bounded border/line refresh and short raster-label refresh with the exact TRIAL6 DIB optimization. All five modes passed the separate border-only, text-only and combined benchmark comparison. This remains a private experimental overlay, not an accepted release or a physical Tandy qualification.')
 d=next(r for r in s['modes'] if r['mode']=='320x200x16');t={x['case']:x for x in d['timings']}
 put('320x200x16 main benchmark medians')
 for key,label in [('BORDER_1PX','1-pixel Rectangle'),('BORDER_2PX','2-pixel Rectangle'),('TEXT_AWAY','Short label, cursor away'),('TEXT_OVER','Short label, cursor overlapping'),('DIB_16_AWAY','16x16 DIB, cursor away'),('DIB_80_AWAY','80x80 DIB, cursor away'),('DIB_FULL_OVER','Full-screen DIB')]:
  r=t[key];put('%s: %.3f -> %.3f ms per call (%.2fx).'%(label,r['tr6_ms'],r['combined_ms'],r['combined_speedup']))
 for r in lines['paired_timings']:
  if r['mode']=='320x200x16':put('Direct 74-pixel %s stroke (MoveTo+LineTo): %.3f -> %.3f ms (%.2fx).'%(r['case'],r['tr6_ms'],r['border_ms'],r['speedup']))
 put('For comparability, the main benchmark intentionally retains the historical CGA-font fixture even in 320x200x16. Native everyday tests separately use the actual EGA fonts for this mode. These timings describe this fixed workload, not every font or string.')
 put('These are fixed-cycle DOSBox-X guest-clock measurements. They are not physical 8088 timings, host execution timings, or measured whole-application speedups. Differences of a few percent should be read in light of the approximately 55 ms guest timer quantum.')
 put('')
 put('WHAT CHANGED')
 put('BORDER7 preserves the original TRIAL6 Output eligibility gate and renderer. One or two validated scanline intervals refresh their outward-rounded logical byte columns separately, without reconverting the gap. Thin two-point lines refresh a conservative endpoint bounding rectangle. Longer/unproven inputs retain the proven row or full-frame fallback. The single full-width span keeps the old row path. ROPs are executed once by the unchanged renderer; refresh only copies the final shadow.')
 put('TEXT7 first requires the existing proven raster-font row bounds. It adds a fail-closed short-label path for 1..64 characters with no explicit width vector or spacing. The pinned font header, glyph widths and default-glyph substitution must fit a conservative maximum-width bound. Explicit opaque fill is included. Unknown, transformed, decorated or otherwise unsupported cases retain the old row/full fallback. Eligible text rows and columns use the already-qualified retained-cursor helpers, avoiding hide/redraw when the cursor is elsewhere.')
 put('The new code has no persistent buffer or global-state allocation. Output adds 10 private local stack bytes; each text wrapper adds 4 private local bytes plus temporary saved-register/span-validation stack use. Final drivers grow by 864..960 bytes over TRIAL6. Rasterizers, cursor assembly, DIB bridge, conversion helpers, identity/full-shadow resynchronization and package/release pins remain unchanged.')
 put('Monochrome policy: the initial split scanline path measured 6.866 ms against 6.418 ms for TR6. The final 640x200x2 build keeps the original scanline row copy and reproduces 6.418 ms, while retaining narrow thin-line updates. Superseded candidate measurements are excluded from the final table.')
 put('The 1-pixel Rectangle workload remains on its conservative full fallback and is not materially accelerated. This trial does not claim every border or every string is optimized.')
 put('')
 put('MAIN BENCHMARK ALL FIVE MODES')
 put('Values are median guest milliseconds per API call over three measured batches. Every measured batch lasts at least one guest second. TR6 is the immutable control; BORDER and TEXT isolate each change; BOTH combines them. Full replicate counts/ranges appear in PAIRED-SUMMARY.json.')
 for mode in s['modes']:
  put('');put(mode['mode']);put('Workload             TR6        BORDER       TEXT       BOTH')
  for row in mode['timings']:
   put('%-20s %9.3f %11.3f %10.3f %10.3f'%(row['case'],row['tr6_ms'],row['border_ms'],row['text_ms'],row['combined_ms']))
  put('Old TR6 medians reproduced exactly: '+str(mode['old_tr6_medians_reproduced_exactly']))
 put('')
 put('SUPPLEMENTAL DIRECT LINE MEASUREMENTS')
 put('MoveTo+LineTo horizontal, vertical and 45-degree diagonal strokes are measured independently with three batches of at least one second per driver/mode. Eight additional untimed cursor/clipping cases per run verify pixels. See line-tests for coordinates, counts, ranges, the independent endpoint-exclusive pixel oracle and raw evidence hashes.')
 for r in lines['paired_timings']:
  put('%-12s %-12s %8.3f -> %8.3f ms (%6.2fx)'%(r['mode'],r['case'],r['tr6_ms'],r['border_ms'],r['speedup']))
 put('')
 put('CORRECTNESS AND TARGET QUALIFICATION')
 put('- Main benchmark: %d batches / %d successful API calls. All benchmark validators passed, with paired active VRAM equality and cursor restoration.'%(s['total_batches'],s['total_api_calls']))
 put('- Borders/text edge suite: 180 GDI cases per driver/mode, TR6 versus combined across five modes: 1,800 guest cases. Rectangle and LineTo/Polyline widths/styles, clipping/off-screen edges, ROP/fill fallback, TextOut/ExtTextOut opaque and clipped output, spacing, custom advances, alignment, bold/italic/underline/strikeout, cursor overlap, reshow and move/hide are covered. Every active framebuffer byte matches the exact control; all cursor and padding checks pass. This is differential rendering validation, not an independent font or wide-pen rasterizer.')
 put('- DIB regression: 580 guest cases across exact TR6 and combined, all five modes. Independent DIB/pixel bounds, odd widths, edge clipping, bands/source crops, 1/4/8/24-bit inputs, cursor overlap, input preservation and no-op/rejected cases pass. Black/white patterns exercise packing/bounds; this is not an exhaustive color-conversion proof. The DIB assembly is byte-identical to TR6, and its earlier partial-failure source invariant remains unchanged; no new injected converter-failure claim is made.')
 put('- Direct line suite: %d independently checked clean frames (plus cursor snapshots) and %d checked visible pixels; no mismatch, cursor or bank-padding failure.'%(lines['total_frames'],lines['independent_pixels']))
 put('- BORDER7: 87 host source/pin/inverse/CRLF/rejection checks, 806,960 exhaustive interval/endpoint bound cases, and 180 executed assembly gate/ABI cases (90 original color plus 90 final monochrome cases).')
 put('- TEXT7: 30 source/pin/inverse/composition checks, 75,000 host geometries (8,905 eligible bounds), and 226 executed assembly gate/ABI cases. Actual gates verify bounds, fallback states, flags including DF, GPRs, DS/ES and BP/SP; they are separate from complete Windows rendering tests.')
 put('- All 15 driver builds pass the 27-object emitted-instruction/link audit, zero unsupported 8086 instructions, zero unsafe multi-prefix REP sites and zero unaccounted library code bytes. New wrappers preserve original renderer calls and returns.')
 put('- Windows runtime uses normal core, cputype=8086_prefetch (DOSBox-X name for its four-byte 8088-compatible prefetch core), 640 KB conventional RAM, memsize=0, FPU/EMS/XMS/UMB off, and the original reservation helper. CPU and later-instruction probes plus Windows FLAGS=64 are retained. No 386 or extra-memory workaround is used. Build and functional guard-test clocks are separate from the fixed 25000 driver timing profile.')
 put('')
 put('EVERYDAY NATIVE WINDOWS AND ROLLBACK KIT')
 put((P/'EVERYDAY-REPORT.TXT').read_text().strip())
 put('')
 put((P/'PACKAGE-REPORT.TXT').read_text().strip())
 put('')
 put('DRIVER IDENTITIES')
 refs=get('REFERENCE-PINS.json')
 for mode,pin in refs.items():
  r=build['combined'][mode];put(mode+'  '+pin['driver']);put('  TR5: '+pin['tr5']);put('  TR6: '+pin['tr6']);put('  TR7: '+r['driver_sha256']+'  '+str(r['driver_bytes'])+' bytes; +'+str(r['growth_over_tr6_bytes'])+' versus TR6')
 put('')
 put('REPRODUCTION AND PRESERVATION')
 put('Base source is the verified astrobleem/oemdisplay-tandy commit 1eac04fdc571f73037b502ecf1f085028271866e. This package supplies a first-party overlay and explicit evidence, not the complete repository, Windows installation/media, DDK or compiler. Those authorized original inputs remain prerequisites. Apply the overlay to that exact source; BLDTR5.PY and BLDTR6.PY retain the exact historical builders. BUILD88.PY --trial7 border|text|combined selects this trial (default combined). Use a fresh --out and each --mode profile with the existing --dosbox argument; every build fails closed on changed pinned dependencies.')
 put('The original baseline BENCH.C and byte-identical BENCH.EXE were retained unchanged (EXE SHA256 f5b0e3f3f9b32c1087e37f19ce5e67b5f097e8c7f6b71f4096a3faec37af080b). The reconstructed paired performance fixture intentionally keeps CGA fonts in all modes to preserve the exact historical comparison. Native everyday testing separately uses the actual profile fonts: EGA for 320x200x16, CGA for the other four modes. The baseline, run_benchmark.py, per-run configuration/logs, source transformations, independent checkers and build audit JSON are supplied. Exact TR6 control binaries can be reproduced with BLDTR6.PY and verified against REFERENCE-PINS.json; the previous TRIAL6 private kit also preserves them.')
 put('No public publication, PR, merge, release-package replacement, user-machine modification, CF write, shell/wheel change or unrelated cleanup was performed. Existing TR5/TR6 references and earlier Library artifacts remain intact. Initial test-harness/staging setup errors were corrected and retained separately; final pass claims refer only to the final frozen source, final harnesses and exact drivers listed above.')
 put('')
 put('LIMITS')
 put('Physical Tandy EX/HX behavior and timing, genuine DOS variants, CF reliability, power-loss recovery, every font/ROP/application and arbitrary invalid caller memory are not established by these tests. In particular, the existing 640x200x4 DOSBox-X model qualification remains: emulation does not by itself prove original EX/HX mode 0Ah behavior. That mode is four colors (black/red/green/white), never 640x200x16. No EMS/XMS/UMB shortcut or logical-plane increase changes the physical color depth. Caller buffers still must be valid live stable allocations; range/alias checks are not an allocation-ownership proof.')
 formatted=[]
 for entry in out:
  for line in entry.split('\n'):
   formatted.append(textwrap.fill(line,width=96,break_long_words=False,break_on_hyphens=False) if len(line)>96 else line)
 (P/'REPORT.TXT').write_bytes(('\n'.join(formatted)+'\n').replace('\n','\r\n').encode('utf8'))
 print(P/'REPORT.TXT')
if __name__=='__main__':main()
