/* Native fourth-saver registry/config fixture. Production source is included
   so static whitelist and Hold decisions are exercised, not copied. */
#include "TSSAVER.C"
#define holding holdHolding
#define stopping holdStopping
#include "TSHOLD.C"
#undef holding
#undef stopping
#include "TSSAVCFG.C"
static HWND qaOwner,fake,dialog,actual;
static HINSTANCE qaInstance;
static HFILE qaLog=-1;
static int qaStage,qaTicks,qaErrors,qaLeaks,qaSeen,qaNotices;
static SCCONFIG qaConfig;
static void qaCheck(char *s,int ok){
    if(qaLog!=-1){_lwrite(qaLog,s,lstrlen(s));_lwrite(qaLog,ok?" PASS\r\n":" FAIL\r\n",ok?7:7);}
    if(!ok)qaErrors++;
}
int TandyBootBusy(void){return 0;}
void TinyNotice(HWND w,HINSTANCE i,char *title,char *text){
    (void)w;(void)i;(void)title;(void)text;qaNotices++;
}
int SaverStarOptions(HWND w,HINSTANCE i,int *speed,int *stars){
    (void)w;(void)i;(void)speed;(void)stars;return 0;
}
UINT PmLaunchShow(HWND w,char *command,int show){(void)w;return WinExec(command,show);}
static void snap(char *path){HFILE f=_lcreat(path,0);if(f!=-1){_lwrite(f,(const void FAR *)0xb8000000L,32768U);_lclose(f);}}
LONG FAR PASCAL QaProc(HWND w,UINT m,WORD wp,LONG lp){
    char command[128];RECT r,c;int choice;
    if(m==WM_TIMER&&w==qaOwner){
        if(++qaTicks>400){qaCheck("TIMEOUT",0);DestroyWindow(w);return 0;}
        if(qaStage==0){
            target=w;qaCheck("OLD_DEFAULTS",SaverConfigRead(&qaConfig)==SC_OK&&!ScEnabled(&qaConfig)&&ScChoice(&qaConfig)==SC_MATRIX);
            qaCheck("TANDI_PATH",SaverConfigProgram(w,qaInstance,&qaConfig,SC_TANDINATOR,command)&&!lstrcmp(command,"C:\\WINDOWS\\TANDI.EXE /S"));
            fake=CreateWindow("TandyTandinatorSaver","registry probe",WS_POPUP,0,0,10,10,0,0,qaInstance,0);
            qaCheck("FOURTH_RUNNING",saverRunning());qaCheck("FOURTH_WINDOW",saverWindow());
            qaCheck("HOLD_WHITELIST_BLOCK",!canOpen(w)&&!GetCapture());
            closeSaver();qaStage=1;return 0;
        }
        if(qaStage==1){
            if(IsWindow(fake))return 0;
            qaCheck("FOURTH_CLOSE",!saverWindow());UnregisterClass("TandyTandinatorSaver",qaInstance);
            qaStage=2;TSSaverSettings(w,qaInstance);qaStage=5;return 0;
        }
        if(qaStage==2){
            dialog=cfgWindow;if(!dialog||!GetDlgItem(dialog,CFG_TANDI))return 0;
            GetWindowRect(dialog,&r);qaCheck("CONFIG_SCREEN_BOUNDS",r.left>=0&&r.top>=0&&r.right<=GetSystemMetrics(SM_CXSCREEN)&&r.bottom<=GetSystemMetrics(SM_CYSCREEN));
            SendMessage(dialog,WM_COMMAND,CFG_TANDI,MAKELONG(GetDlgItem(dialog,CFG_TANDI),BN_CLICKED));
            choice=selection(dialog);qaCheck("FOURTH_RADIO",choice==SC_TANDINATOR);
            qaCheck("STAR_OPTIONS_SEPARATE",!IsWindowEnabled(GetDlgItem(dialog,CFG_OPTIONS)));
            GetClientRect(dialog,&c);GetWindowRect(GetDlgItem(dialog,CFG_TANDI),&r);
            qaCheck("RADIO_VISIBLE",IsWindowVisible(GetDlgItem(dialog,CFG_TANDI)));
            snap("C:\\TS10CFG.BIN");qaStage=3;
            SetFocus(GetDlgItem(dialog,CFG_PREVIEW));
            SendMessage(dialog,WM_COMMAND,CFG_PREVIEW,MAKELONG(GetDlgItem(dialog,CFG_PREVIEW),BN_CLICKED));return 0;
        }
        if(qaStage==3){
            actual=FindWindow("TandyTandinatorSaver",NULL);if(!actual)return 0;
            qaSeen=1;qaCheck("FOURTH_PREVIEW_CLASS",saverWindow()&&saverRunning());
            qaCheck("ACTUAL_DEMO_OWNS_CAPTURE",GetCapture()==actual);
            qaCheck("HOLD_BLOCKS_ACTUAL",!canOpen(w));
            /* Checked shutdown/preview-close path, no synthetic global input. */
            closeSaver();qaStage=4;return 0;
        }
        if(qaStage==4){
            if(FindWindow("TandyTandinatorSaver",NULL))return 0;
            qaCheck("PREVIEW_CLOSE_RELEASES",GetCapture()==NULL);
            SendMessage(dialog,WM_COMMAND,IDCANCEL,0L);return 0;
        }
        if(qaStage==5){
            qaCheck("INI_DEFAULTS_UNCHANGED",SaverConfigRead(&qaConfig)==SC_OK&&!ScEnabled(&qaConfig)&&ScChoice(&qaConfig)==SC_MATRIX);
            qaCheck("NO_UNEXPECTED_NOTICE",!qaNotices);qaCheck("NO_INPUT_LEAK",!qaLeaks);
            qaCheck("PREVIEW_SEEN",qaSeen);qaCheck("COMPLETE",!qaErrors);DestroyWindow(w);return 0;
        }
        return 0;
    }
    if((m>=WM_KEYFIRST&&m<=WM_KEYLAST)||(m>=WM_MOUSEFIRST&&m<=WM_MOUSELAST)){
        if(w==qaOwner&&m!=WM_MOUSEMOVE)qaLeaks++;return 0;
    }
    if(m==WM_DESTROY&&w==qaOwner){KillTimer(w,1);if(qaLog!=-1)_lclose(qaLog);PostQuitMessage(0);return 0;}
    return DefWindowProc(w,m,wp,lp);
}
int PASCAL WinMain(HANDLE inst,HANDLE prev,LPSTR cmd,int show){
    WNDCLASS c;MSG m;(void)prev;(void)cmd;qaInstance=inst;
    c.style=0;c.lpfnWndProc=QaProc;c.cbClsExtra=c.cbWndExtra=0;c.hInstance=inst;c.hIcon=0;
    c.hCursor=LoadCursor(NULL,IDC_ARROW);c.hbrBackground=GetStockObject(WHITE_BRUSH);c.lpszMenuName=0;
    c.lpszClassName="TS10QA";if(!RegisterClass(&c))return 1;
    c.lpszClassName="TandyTandinatorSaver";if(!RegisterClass(&c))return 1;
    qaOwner=CreateWindow("TS10QA","Fourth saver QA",WS_POPUP,0,0,GetSystemMetrics(SM_CXSCREEN),GetSystemMetrics(SM_CYSCREEN),0,0,inst,0);
    qaLog=_lcreat("C:\\TS10.LOG",0);ShowWindow(qaOwner,show);SetActiveWindow(qaOwner);SetFocus(qaOwner);
    SetTimer(qaOwner,1,100,NULL);
    while(GetMessage(&m,0,0,0)){TranslateMessage(&m);DispatchMessage(&m);}return m.wParam;
}
