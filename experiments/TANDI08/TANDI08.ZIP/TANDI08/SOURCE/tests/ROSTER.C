/* Truthful full-roster traversal using the shipped ENGINE.C and DB.C. */
#include <stdio.h>
#include "../src/TANDI.H"
static TDB d;static ENGINE e;static U8 row[TD_ROW];
int main(int argc,char **argv){
    int c,q,guess,first,miss,cap,unknown,rejects,i;char name[40];
    if(argc!=2||!db_open(&d,argv[1]))return 2;
    printf("index,name,questions,cap,first_guess,first_miss,rejections,unknown\n");
    for(c=0;c<(int)d.nc;c++){
        if(!db_row(&d,c,row)||!db_name(&d,c,name))return 3;
        unknown=0;for(i=0;i<(int)d.nq;i++)unknown+=db_value(row,i)==2;
        eng_reset(&e,&d);first=-1;miss=cap=rejects=0;
        for(i=0;i<(int)d.nc+(int)d.nq+1;i++){
            guess=eng_confident(&e,&d);
            if(!guess){q=eng_choose(&e,&d);guess=q<0;}
            if(guess){
                if(e.best<0)return 4;
                if(first<0){first=e.best;miss=first!=c;cap=e.turn>=25;}
                if(e.best==c)break;
                eng_reject(&e,&d);rejects++;
            }else if(!eng_answer(&e,&d,db_value(row,q)))return 5;
        }
        if(e.best!=c)return 6;
        printf("%d,%s,%d,%d,%d,%d,%d,%d\n",c,name,e.turn,cap,first,miss,rejects,unknown);
    }
    db_close();return 0;
}
