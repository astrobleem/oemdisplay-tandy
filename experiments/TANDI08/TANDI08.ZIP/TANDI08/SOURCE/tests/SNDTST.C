/* Host-only Win16/PSG mocks. The production C file is compiled unchanged. */
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include "TDSOUND.H"

#define APP 1
#define INST 77
#define OTHER 78
#define MAXWIN 520
#define MAXOUT 10000
typedef struct { int valid;HINSTANCE inst;char name[40]; } WINDOW;
static WINDOW windows[MAXWIN];
static HWND foreground,created;
static unsigned flags,rom,romReads;
static int appEnabled,iconic,registered,registerOK,createOK,destroyOK;
static int unregisterOK,moduleBusy,driverLoaded,driverBusy,raceBusy;
static int badClassRead,cycleWindows;
static unsigned writes,values[MAXOUT],destroyCalls,registerCalls,createCalls;
static unsigned cases;

static HWND addwin(const char *name,HINSTANCE inst)
{
    unsigned i;
    for(i=2;i<MAXWIN;i++)if(!windows[i].valid) {
        windows[i].valid=1;windows[i].inst=inst;
        assert(strlen(name)<sizeof(windows[i].name));
        strcpy(windows[i].name,name);return (HWND)i;
    }
    assert(0);return 0;
}
DWORD GetWinFlags(void) { return flags; }
unsigned TdSoundTestRom(void) { romReads++;return rom; }
int IsWindow(HWND w) { return w<MAXWIN && windows[w].valid; }
WORD GetWindowWord(HWND w,int field)
{ assert(field==GWW_HINSTANCE);return IsWindow(w)?windows[w].inst:0; }
int GetClassName(HWND w,char *name,int n)
{
    int size;
    if(!IsWindow(w) || w==badClassRead)return 0;
    size=(int)strlen(windows[w].name);if(size>=n)size=n-1;
    memcpy(name,windows[w].name,(size_t)size);name[size]=0;return size;
}
int lstrcmp(const char *a,const char *b) { return strcmp(a,b); }
HWND FindWindow(const char *name,const char *title)
{
    unsigned i;(void)title;
    for(i=1;i<MAXWIN;i++)
        if(windows[i].valid && !strcmp(windows[i].name,name))return (HWND)i;
    return 0;
}
HMODULE GetModuleHandle(const char *name)
{
    if(!strcmp(name,"TEXIT"))return (HMODULE)(moduleBusy?11:0);
    if(!strcmp(name,"SOUND"))return (HMODULE)(driverLoaded?12:0);
    return 0;
}
static void dummy(void) { }
FARPROC GetProcAddress(HMODULE h,const char *name)
{ assert(h==12 && !strcmp(name,"DEBUGTIMER"));return driverBusy?dummy:NULL; }
HWND GetWindow(HWND w,UINT mode)
{
    unsigned i;
    assert(IsWindow(w));assert(mode==GW_HWNDFIRST || mode==GW_HWNDNEXT);
    if(cycleWindows && mode==GW_HWNDNEXT)return w;
    i=mode==GW_HWNDFIRST?1:(unsigned)w+1;
    for(;i<MAXWIN;i++)if(windows[i].valid)return (HWND)i;
    return 0;
}
int outp(unsigned port,int value)
{
    assert(port==0xc0);assert(value>=0 && value<=255);assert(writes<MAXOUT);
    /* Data bytes and the two tone-0 latches only. Never touch other voices. */
    assert(value<64 || (value>=0x80 && value<=0x9f));
    values[writes++]=(unsigned)value;return value;
}
int DestroyWindow(HWND w)
{
    assert(IsWindow(w) && w==created && windows[w].inst==INST);
    destroyCalls++;if(!destroyOK)return 0;
    windows[w].valid=0;return 1;
}
int UnregisterClass(const char *name,HINSTANCE inst)
{
    unsigned i;assert(registered);assert(!strcmp(name,"TandyPSGTest"));
    assert(inst==INST);
    if(!unregisterOK)return 0;
    for(i=1;i<MAXWIN;i++)
        if(windows[i].valid && windows[i].inst==inst &&
           !strcmp(windows[i].name,name))return 0;
    registered=0;return 1;
}
HWND GetActiveWindow(void) { return foreground; }
int IsWindowEnabled(HWND w) { assert(w==APP);return appEnabled; }
int IsIconic(HWND w) { assert(w==APP);return iconic; }
LONG DefWindowProc(HWND w,UINT m,WORD wp,LONG lp)
{ (void)w;(void)m;(void)wp;(void)lp;return 0; }
int RegisterClass(const WNDCLASS *c)
{
    registerCalls++;assert(!registered);
    assert(c->lpfnWndProc==DefWindowProc && c->hInstance==INST);
    assert(!strcmp(c->lpszClassName,"TandyPSGTest"));
    if(!registerOK)return 0;
    registered=1;return 1;
}
HWND CreateWindow(const char *name,const char *title,DWORD style,
    int x,int y,int cx,int cy,HWND parent,void *menu,HINSTANCE inst,void *data)
{
    createCalls++;assert(registered);
    assert(!strcmp(name,"TandyPSGTest") && !strcmp(title,"Tandinator sound busy"));
    assert(style==WS_POPUP && !x && !y && !cx && !cy);
    assert(!parent && !menu && !data && inst==INST);
    if(!createOK)return 0;
    created=addwin(name,inst);
    if(raceBusy)addwin("TandyStartupChime",OTHER);
    return created;
}

static TDSNDSTAT snapshot(void)
{ TDSNDSTAT s;TdSoundGetStats(&s);return s; }
static void reset(void)
{
    unsigned i;
    /* Leave each mocked world clean before creating another test fixture. */
    destroyOK=unregisterOK=1;moduleBusy=driverBusy=0;badClassRead=cycleWindows=0;
    for(i=2;i<MAXWIN;i++)if(windows[i].inst!=INST)windows[i].valid=0;
    TdSoundStop(APP);assert(!registered);
    memset(windows,0,sizeof(windows));windows[APP].valid=1;
    windows[APP].inst=INST;strcpy(windows[APP].name,"Tandinator06");
    foreground=APP;flags=0;rom=0x21;romReads=0;
    appEnabled=1;iconic=0;registered=0;registerOK=createOK=1;
    driverLoaded=driverBusy=raceBusy=0;created=0;
    writes=destroyCalls=registerCalls=createCalls=0;
    assert(TdSoundInit(APP,INST,1));assert(TdSoundEnabled());assert(!writes);
}
static void firstnote(int cue,DWORD now)
{
    assert(TdSoundBegin(APP,cue,now)==TD_SND_STARTED);
    assert(!writes && FindWindow("TandyPSGTest",NULL)==created);
    TdSoundTick(APP,now);assert(writes==4);
}
static void quiet(void)
{
    TDSNDSTAT s=snapshot();assert(!s.playing && !registered);
    assert(!FindWindow("TandyPSGTest",NULL));
}
static void check_note(unsigned at,unsigned divisor,unsigned volume)
{
    assert(at+3<writes);assert(values[at]==0x9f);
    assert(values[at+1]==(0x80|(divisor&15)));
    assert(values[at+2]==((divisor>>4)&63));
    assert(values[at+3]==(0x90|volume));
}
static void cue_tests(void)
{
    int cue;unsigned i,n,durations[3]={400,600,400};
    static const unsigned divs[3][4]={{170,143,107,0},{214,170,143,107},{339,359,428,0}};
    static const unsigned vols[3][4]={{6,6,7,0},{5,5,5,7},{7,8,9,0}};
    TDSNDSTAT before,after;
    for(cue=1;cue<=3;cue++) {
        reset();before=snapshot();firstnote(cue,1000);
        assert(snapshot().durationMs==durations[cue-1]);
        n=cue==TD_SND_VICTORY?4:3;
        for(i=1;i<n;i++)TdSoundTick(APP,1000+i*100);
        for(i=0;i<n;i++)check_note(i*4,divs[cue-1][i],vols[cue-1][i]);
        TdSoundTick(APP,1000+durations[cue-1]-1);assert(writes==n*4);
        TdSoundTick(APP,1000+durations[cue-1]);assert(writes==n*4+1);
        assert(values[writes-1]==0x9f);quiet();after=snapshot();
        assert(after.starts[cue-1]==before.starts[cue-1]+1);
        assert(after.completions[cue-1]==before.completions[cue-1]+1);
        i=writes;TdSoundTick(APP,5000);TdSoundStop(APP);assert(writes==i);
        cases++;
    }
}
static void guard_tests(void)
{
    static const char *busy[]={"TandyPSGTest","TandyStartupChime",
        "TandyXPStartupChime","TandyAutomaticMouth","TandyPreExitChime",
        "TandyMiniMIDI","TandyJoyMIDI","TandyBeatsLab"};
    unsigned i;HWND w;TDSNDSTAT before,after;
    for(i=0;i<sizeof(busy)/sizeof(busy[0]);i++) {
        reset();w=addwin(busy[i],OTHER);before=snapshot();
        assert(TdSoundBegin(APP,1,0)==TD_SND_BUSY);TdSoundStop(APP);
        after=snapshot();assert(after.busySkips==before.busySkips+1);
        assert(!writes && !registered && !destroyCalls && IsWindow(w));cases++;
    }
    reset();moduleBusy=1;assert(TdSoundBegin(APP,1,0)==TD_SND_BUSY);assert(!writes);cases++;
    reset();driverLoaded=driverBusy=1;
    assert(TdSoundBegin(APP,1,0)==TD_SND_BUSY);assert(!writes);cases++;
    reset();driverLoaded=1;firstnote(1,0);TdSoundStop(APP);quiet();cases++;
    reset();flags=WF_PMODE;romReads=0;assert(!TdSoundInit(APP,INST,1));
    assert(!romReads && !TdSoundEnabled());TdSoundEnable(1);
    assert(TdSoundBegin(APP,1,0)==TD_SND_DISABLED);assert(!writes);cases++;
    reset();rom=0;assert(!TdSoundInit(APP,INST,1));TdSoundEnable(1);
    assert(TdSoundBegin(APP,1,0)==TD_SND_DISABLED);assert(!writes);cases++;
    reset();assert(!TdSoundInit(APP,INST,0));TdSoundEnable(1);
    assert(TdSoundBegin(APP,1,0)==TD_SND_DISABLED);assert(!writes);cases++;
    reset();TdSoundEnable(0);assert(TdSoundBegin(APP,1,0)==TD_SND_DISABLED);
    TdSoundEnable(1);firstnote(1,0);TdSoundStop(APP);quiet();cases++;
    reset();assert(TdSoundBegin(44,1,0)==TD_SND_BADARG);
    assert(TdSoundBegin(APP,0,0)==TD_SND_BADARG);
    assert(TdSoundBegin(APP,4,0)==TD_SND_BADARG);assert(!writes);cases++;
    reset();foreground=0;assert(TdSoundBegin(APP,1,0)==TD_SND_INACTIVE);assert(!writes);cases++;
    reset();appEnabled=0;assert(TdSoundBegin(APP,1,0)==TD_SND_INACTIVE);assert(!writes);cases++;
    reset();iconic=1;assert(TdSoundBegin(APP,1,0)==TD_SND_INACTIVE);assert(!writes);cases++;
}
static void failure_tests(void)
{
    unsigned i;TDSNDSTAT before,after;
    reset();registerOK=0;assert(TdSoundBegin(APP,1,0)==TD_SND_FAILED);
    assert(!writes && !createCalls);quiet();cases++;
    reset();createOK=0;assert(TdSoundBegin(APP,1,0)==TD_SND_FAILED);
    assert(!writes && !destroyCalls);quiet();cases++;
    reset();raceBusy=1;assert(TdSoundBegin(APP,1,0)==TD_SND_BUSY);
    assert(!writes && !registered && destroyCalls==1);cases++;
    reset();firstnote(1,0);destroyOK=0;before=snapshot();TdSoundStop(APP);
    after=snapshot();assert(after.cleanupFailures==before.cleanupFailures+1);
    assert(writes==5 && registered && IsWindow(created));
    assert(TdSoundBegin(APP,2,100)==TD_SND_FAILED);assert(writes==5);
    destroyOK=1;TdSoundStop(APP);quiet();assert(writes==5);cases++;
    reset();firstnote(1,0);unregisterOK=0;TdSoundStop(APP);
    assert(writes==5 && registered && !IsWindow(created));
    assert(TdSoundBegin(APP,2,100)==TD_SND_FAILED);assert(writes==5);
    unregisterOK=1;TdSoundStop(APP);quiet();cases++;
    reset();firstnote(1,0);unregisterOK=0;
    assert(!TdSoundInit(APP,INST,0));assert(!TdSoundEnabled());
    TdSoundEnable(1);assert(!TdSoundEnabled());unregisterOK=1;
    TdSoundStop(APP);quiet();cases++;
    reset();for(i=0;i<256;i++)addwin("ordinary",OTHER);
    assert(TdSoundBegin(APP,1,0)==TD_SND_BUSY);assert(!writes && !registered);cases++;
    reset();cycleWindows=1;assert(TdSoundBegin(APP,1,0)==TD_SND_BUSY);
    assert(!writes && !registered);cases++;
    reset();badClassRead=addwin("ordinary",OTHER);
    assert(TdSoundBegin(APP,1,0)==TD_SND_BUSY);assert(!writes && !registered);cases++;
}
static void lifecycle_tests(void)
{
    HWND foreign;unsigned old;TDSNDSTAT before,after;
    reset();assert(TdSoundBegin(APP,1,0)==1);TdSoundStop(APP);quiet();assert(!writes);cases++;
    reset();firstnote(1,0);TdSoundStop(APP);quiet();assert(writes==5);cases++;
    reset();firstnote(1,0);foreground=0;TdSoundTick(APP,100);quiet();assert(writes==5);cases++;
    reset();firstnote(1,0);appEnabled=0;TdSoundTick(APP,100);quiet();assert(writes==5);cases++;
    reset();firstnote(1,0);iconic=1;TdSoundTick(APP,100);quiet();assert(writes==5);cases++;
    reset();firstnote(1,0);TdSoundEnable(0);quiet();assert(writes==5 && !TdSoundEnabled());cases++;
    reset();firstnote(1,0);TdSoundTick(44,100);TdSoundStop(44);
    assert(writes==4 && snapshot().playing);TdSoundStop(APP);quiet();cases++;
    reset();firstnote(1,0);assert(TdSoundBegin(APP,2,100)==1);assert(writes==5);
    TdSoundTick(APP,100);assert(writes==9);check_note(5,214,5);
    TdSoundStop(APP);quiet();assert(writes==10);cases++;
    reset();firstnote(1,0);foreign=addwin("TandyStartupChime",OTHER);
    before=snapshot();TdSoundTick(APP,100);after=snapshot();
    assert(writes==4 && IsWindow(foreign) && !registered);
    assert(after.ownershipLosses==before.ownershipLosses+1);cases++;
    reset();firstnote(1,0);foreign=addwin("TandyPSGTest",OTHER);
    assert(FindWindow("TandyPSGTest",NULL)==created);
    TdSoundStop(APP);assert(writes==4 && IsWindow(foreign) && !registered);cases++;
    reset();firstnote(1,0);moduleBusy=1;TdSoundStop(APP);
    assert(writes==4 && !registered);cases++;
    reset();firstnote(1,0);driverLoaded=driverBusy=1;TdSoundStop(APP);
    assert(writes==4 && !registered);cases++;
    reset();firstnote(1,0);foreign=addwin("TandyStartupChime",OTHER);
    assert(TdSoundBegin(APP,2,100)==TD_SND_BUSY);
    assert(writes==4 && IsWindow(foreign) && !registered);cases++;
    reset();firstnote(1,0);windows[created].valid=0;TdSoundStop(APP);
    assert(writes==4 && !registered && !destroyCalls);cases++;
    reset();firstnote(1,0);windows[created].inst=OTHER;
    strcpy(windows[created].name,"ForeignWindow");foreign=created;TdSoundStop(APP);
    assert(writes==4 && IsWindow(foreign) && !registered && !destroyCalls);cases++;
    reset();assert(TdSoundBegin(APP,1,0)==1);foreground=0;TdSoundTick(APP,100);
    quiet();assert(!writes);cases++;
    reset();firstnote(1,0);old=writes;assert(!TdSoundInit(APP,INST,0));
    quiet();assert(writes==old+1 && !TdSoundEnabled());cases++;
    reset();firstnote(1,0);foreign=addwin("TandyStartupChime",OTHER);
    assert(!TdSoundInit(APP,INST,0));assert(writes==4 && IsWindow(foreign));cases++;
}
static void timing_tests(void)
{
    TDSNDSTAT before,after;DWORD start;
    reset();before=snapshot();assert(TdSoundBegin(APP,1,0)==1);
    TdSoundTick(APP,301);after=snapshot();quiet();assert(!writes);
    assert(after.lateAborts==before.lateAborts+1);cases++;
    reset();assert(TdSoundBegin(APP,1,0)==1);TdSoundTick(APP,300);
    assert(writes==4);TdSoundStop(APP);quiet();cases++;
    reset();firstnote(1,0);before=snapshot();TdSoundTick(APP,321);
    after=snapshot();quiet();assert(writes==5);
    assert(after.lateAborts==before.lateAborts+1);cases++;
    reset();firstnote(1,0);TdSoundTick(APP,320);assert(writes==8);
    check_note(4,107,7);TdSoundTick(APP,400);quiet();assert(writes==9);cases++;
    reset();firstnote(2,0);TdSoundTick(APP,10000);quiet();assert(writes==5);cases++;
    reset();firstnote(1,1000);TdSoundTick(APP,999);quiet();assert(writes==5);cases++;
    reset();start=(DWORD)0xffffffc0UL;firstnote(1,start);
    TdSoundTick(APP,(DWORD)(start+100));TdSoundTick(APP,(DWORD)(start+200));
    TdSoundTick(APP,(DWORD)(start+400));quiet();assert(writes==13);cases++;
    reset();start=(DWORD)0xffffffc0UL;assert(TdSoundBegin(APP,1,start)==1);
    TdSoundTick(APP,(DWORD)(start+100));assert(writes==4);TdSoundStop(APP);quiet();cases++;
    reset();firstnote(1,0);TdSoundTick(APP,0);TdSoundTick(APP,55);
    TdSoundTick(APP,99);assert(writes==4);TdSoundStop(APP);quiet();cases++;
    TdSoundGetStats(NULL);cases++;
}
int main(void)
{
    TDSNDSTAT s;
    cue_tests();guard_tests();failure_tests();lifecycle_tests();timing_tests();
    s=snapshot();
    printf("PASS: %u host cue/ownership/lifecycle/failure/timing scenarios\n",cases);
    printf("Total attempts=%lu writes=%lu notes=%lu late_aborts=%lu ownership_losses=%lu\n",
        (unsigned long)s.attempts,(unsigned long)s.portWrites,(unsigned long)s.notes,
        (unsigned long)s.lateAborts,(unsigned long)s.ownershipLosses);
    return 0;
}
