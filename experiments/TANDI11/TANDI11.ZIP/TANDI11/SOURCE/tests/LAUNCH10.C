/* First-party private-fixture launcher: Win3 boot shell accepts a file only.
   Pass real WinMain arguments through WinExec. No global input generation. */
#define WINVER 0x0300
#include <windows.h>
static HWND child,own;static int seen,ticks,mode,stage,leaks;
static HFILE log=-1;
static void note(char *s){if(log!=-1){_lwrite(log,s,lstrlen(s));_lwrite(log,"\r\n",2);}}
LONG FAR PASCAL LaunchProc(HWND w,UINT m,WORD wp,LONG lp){
    /* This caller owns its deliberately supplied cursor; its class default
       must not overwrite that value while testing child cleanup. */
    if(m==WM_SETCURSOR&&mode==4&&stage)return 1;
    if(m==WM_TIMER){
        child=FindWindow("TandyTandinatorSaver",NULL);
        if(child)seen=1;
        if(GetModuleHandle("TANDI"))seen=1;
        if(mode&&child){
            if(++ticks==20){
                stage=1;
                if(mode==1){SendMessage(child,WM_KEYDOWN,VK_RETURN,0);SendMessage(child,WM_CHAR,13,0);}
                else if(mode==2)SendMessage(child,WM_LBUTTONDOWN,MK_LBUTTON,0);
                else if(mode==3)SetCapture(w);
                else if(mode==4){SetCursor(LoadCursor(NULL,IDC_CROSS));SetFocus(w);}
                else if(mode==5)SendMessage(child,WM_CLOSE,0,0);
                else SendMessage(child,WM_QUERYENDSESSION,0,0);
                stage=1;
            }
            if(stage==1&&ticks==26){
                if(mode<3){note(IsWindow(child)&&GetCapture()==child?"PRODUCTION HELD PASS":"PRODUCTION HELD FAIL");
                    if(mode==1)SendMessage(child,WM_KEYUP,VK_RETURN,0);
                    else SendMessage(child,WM_LBUTTONUP,0,0);}
                stage=2;
            }
            if(mode==2&&stage==2&&ticks==30){
                note(IsWindow(child)&&GetCapture()==child?"PRODUCTION DOUBLE DRAIN PASS":"PRODUCTION DOUBLE DRAIN FAIL");
                SendMessage(child,WM_LBUTTONDBLCLK,MK_LBUTTON,0);SendMessage(child,WM_LBUTTONUP,0,0);stage=3;
            }
        }
        if(seen&&!GetModuleHandle("TANDI")){
            if(mode){
                note(!leaks?"PRODUCTION INPUT LEAKS ZERO":"PRODUCTION INPUT LEAK FAIL");
                if(mode<3)note(GetActiveWindow()==w&&GetFocus()==w?"PRODUCTION RESTORE PASS":"PRODUCTION RESTORE FAIL");
                if(mode==3){note(GetCapture()==w?"PRODUCTION CAPTURE PASS":"PRODUCTION CAPTURE FAIL");ReleaseCapture();}
                if(mode==4){HCURSOR cursor=SetCursor(NULL);SetCursor(cursor);note(cursor==LoadCursor(NULL,IDC_CROSS)?"PRODUCTION CURSOR PASS":"PRODUCTION CURSOR FAIL");}
                note("PRODUCTION COMPLETE");
            }
            DestroyWindow(w);
        }
        return 0;
    }
    if((m>=WM_KEYFIRST&&m<=WM_KEYLAST)||(m>=WM_MOUSEFIRST&&m<=WM_MOUSELAST)){
        if(mode&&stage&&m!=WM_MOUSEMOVE)leaks++;return 0;
    }
    if(m==WM_DESTROY){KillTimer(w,1);if(log!=-1)_lclose(log);PostQuitMessage(0);return 0;}
    return DefWindowProc(w,m,wp,lp);
}
int PASCAL WinMain(HANDLE inst,HANDLE prev,LPSTR cmd,int show){
    WNDCLASS c;MSG m;char args[80],command[100];int result;
    (void)prev;(void)cmd;
    c.style=0;c.lpfnWndProc=LaunchProc;c.cbClsExtra=c.cbWndExtra=0;
    c.hInstance=inst;c.hIcon=0;c.hCursor=LoadCursor(NULL,IDC_ARROW);
    c.hbrBackground=GetStockObject(WHITE_BRUSH);c.lpszMenuName=0;c.lpszClassName="TandiDemoLaunch";
    if(!RegisterClass(&c))return 1;
    own=CreateWindow(c.lpszClassName,"Demo launcher",WS_POPUP,0,0,
                    GetSystemMetrics(SM_CXSCREEN),GetSystemMetrics(SM_CYSCREEN),0,0,inst,0);
    ShowWindow(own,show);SetActiveWindow(own);SetFocus(own);UpdateWindow(own);
    GetProfileString("DemoFixture","Command","/J",args,sizeof(args));
    mode=GetProfileInt("DemoFixture","Production",0);log=_lcreat("C:\\LAUNCH.LOG",0);
    lstrcpy(command,"TANDI.EXE ");lstrcat(command,args);
    result=WinExec(command,SW_SHOWNORMAL);if(result<32){note("LAUNCH FAILED");DestroyWindow(own);return 1;}
    SetTimer(own,1,100,NULL);
    while(GetMessage(&m,0,0,0)){TranslateMessage(&m);DispatchMessage(&m);}return m.wParam;
}
