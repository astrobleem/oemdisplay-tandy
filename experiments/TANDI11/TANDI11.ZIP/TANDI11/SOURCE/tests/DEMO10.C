/* Actual engine/data, deterministic pacing, no UI or synthetic global input. */
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include "../src/DEMO.H"
static TDB db;
static ENGINE engine;
static TDHISTORY history;
static TDDEMO demo,copy;
static int seen[TD_MAXC];
int main(int argc,char **argv){
    U32 now=0xfffffe00UL;int event,calls=0,i,games=0,oldphase;
    if(argc!=2||!db_open(&db,argv[1]))return 2;
    assert(demo_due(1UL,0xfffffffeUL));
    assert(!demo_due(0xfffffffeUL,1UL));
    assert(demo_init(&demo,&engine,&db,&history,now));
    for(i=0;i<DEMO_ROSTER;i++)assert(!seen[demo.roster[i]]++);
    memset(seen,0,sizeof(seen));
    while(demo.games<64){
        assert(++calls<50000);copy=demo;
        assert(!demo_step(&demo,&engine,&db,&history,demo.due-1UL));
        assert(!memcmp(&copy,&demo,sizeof(demo)));
        oldphase=demo.phase;now=demo.due;
        event=demo_step(&demo,&engine,&db,&history,now);
        assert(event>0&&demo.enabled);
        assert(demo.phase!=oldphase);
        assert(demo.due!=now&&!demo_due(now,demo.due));
        assert(engine.turn==history.count);
        assert(!demo_step(&demo,&engine,&db,&history,now));
        if(event&DEMO_VICTORY){
            assert(demo.phase==DEMO_SUCCESS&&engine.best==demo.target);
            seen[demo.target]++;games++;
            printf("game=%d target=%d answers=%d rejects=%d\n",games,demo.target,engine.turn,demo.rejections);
        }
    }
    for(i=0;i<DEMO_ROSTER;i++)assert(seen[demo.roster[i]]==8);
    /* Large timer lateness advances one phase only, no catch-up burst. */
    copy=demo;now=demo.due+100000UL;
    assert(demo_step(&demo,&engine,&db,&history,now)>0);
    assert(demo.phase!=copy.phase&&!demo_step(&demo,&engine,&db,&history,now));
    demo.enabled=0;copy=demo;
    assert(!demo_step(&demo,&engine,&db,&history,now+100000UL));
    assert(!memcmp(&copy,&demo,sizeof(demo)));
    /* Fail closed before altering the active engine when a name is missing. */
    db.nc=0;copy=demo;assert(!demo_init(&demo,&engine,&db,&history,now));
    printf("PASS games=%d calls=%d wrap=1 no_catchup=1 disabled=1 missing=1\n",games,calls);
    db_close();return 0;
}
