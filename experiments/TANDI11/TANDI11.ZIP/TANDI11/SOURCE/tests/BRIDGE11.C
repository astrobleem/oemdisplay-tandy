/* Host and native fixtures call the actual separate notebook and engine. */
#include "../src/LEARN.H"
#include "../src/SHAPIN.H"
static TDB d;static ENGINE e;static TDHISTORY h;
int fx_open(const char *p){if(!db_open(&d,p))return 0;return ln_open(&d,p);}
void fx_close(void){ln_close();db_close();}
int fx_report(int c,int *q,int *a,int n,U32 id,int used){int i;obs_reset(&h);if(n>40)return 0;for(i=0;i<n;i++){h.q[i]=(U16)q[i];h.a[i]=(U8)a[i];}h.count=n;return ln_save(&d,c,&h,id,used);}
int fx_reset(void){return ln_reset(&d);}
int fx_fresh(void){return ln_fresh(&d);}
void fx_game(void){eng_reset(&e,&d);obs_reset(&h);}
int fx_q(int budget){if(e.turn>=40||(e.turn<25||e.turn>=budget)&&eng_confident(&e,&d))return -1;return eng_choose(&e,&d);}
int fx_answer(int a){return e.turn<40&&obs_answer(&h,&e,&d,a);}
int fx_guess(int on){eng_rank(&e,&d);return on?ln_tie(&e,&d,&h):e.best;}
void fx_reject(void){eng_reject(&e,&d);}
int fx_turn(void){return e.turn;}
int fx_score(int c){return e.score[c];}
int fx_sha(const char *p,U8 *b){return td_sha(p,b);}
