#define WINVER 0x0300
#include <windows.h>
static int phase,mode;static HWND child;static DWORD launchAt;
static void logline(LPSTR s){HFILE f=_lopen("NATIVE.LOG",OF_WRITE);if(f==HFILE_ERROR)f=_lcreat("NATIVE.LOG",0);if(f!=HFILE_ERROR){_llseek(f,0L,2);_lwrite(f,s,lstrlen(s));_lclose(f);}}
LONG FAR PASCAL WndProc(HWND w,UINT m,WPARAM wp,LPARAM lp){char b[160];
 if(m==WM_TIMER){
  if(phase==0){launchAt=GetTickCount();WinExec(mode<2?"C:\\WINDOWS\\MAZE.EXE":"C:\\WINDOWS\\MAZE.EXE /S",SW_SHOWNORMAL);phase=1;return 0;}
  if(phase==1){child=FindWindow(mode<2?"TandyMaze":"TandyMazeSaver",NULL);if(!child){logline("FAIL launch\r\n");DestroyWindow(w);return 0;}
   wsprintf(b,"LAUNCH mode=%d elapsed_ms=%lu\r\n",mode,GetTickCount()-launchAt);logline(b);
   if(mode==1){MoveWindow(child,0,0,130,130,TRUE);PostMessage(child,WM_SIZE,0,0L);}
   if(mode==0||mode==2)PostMessage(child,WM_CLOSE,0,0L);
   else{PostMessage(child,WM_KEYDOWN,VK_ESCAPE,0L);PostMessage(child,WM_KEYUP,VK_ESCAPE,0L);}
   phase=2;return 0;
  }
  if(phase==2){if(IsWindow(child))return 0;
   wsprintf(b,"PASS mode=%d closed elapsed_ms=%lu capture_released=%d\r\n",mode,GetTickCount()-launchAt,GetCapture()==NULL);logline(b);
   if(++mode==4){logline("QUIT clean\r\n");DestroyWindow(w);}else phase=0;return 0;
  }
 }
 if(m==WM_DESTROY){KillTimer(w,1);PostQuitMessage(0);return 0;}return DefWindowProc(w,m,wp,lp);
}
int PASCAL WinMain(HINSTANCE h,HINSTANCE prev,LPSTR cmd,int show){WNDCLASS wc;HWND w;MSG msg;HFILE f;
 f=_lcreat("NATIVE.LOG",0);if(f!=HFILE_ERROR)_lclose(f);
 wc.style=0;wc.lpfnWndProc=WndProc;wc.cbClsExtra=wc.cbWndExtra=0;wc.hInstance=h;wc.hIcon=NULL;wc.hCursor=LoadCursor(NULL,IDC_ARROW);wc.hbrBackground=GetStockObject(WHITE_BRUSH);wc.lpszMenuName=NULL;wc.lpszClassName="MazeStartQA";RegisterClass(&wc);
 w=CreateWindow("MazeStartQA","QA",WS_OVERLAPPEDWINDOW,0,0,90,50,NULL,NULL,h,NULL);ShowWindow(w,SW_SHOWNORMAL);SetTimer(w,1,55,NULL);
 while(GetMessage(&msg,NULL,0,0)){TranslateMessage(&msg);DispatchMessage(&msg);}return 0;}
