#define MAZE_HOST
#include "MAZE.C"
#include <assert.h>
#include <stdio.h>
int main(void){unsigned a[RAYS];unsigned char b[RAYS];int n,i,j;
for(n=0;n<2000;n++){cast(168);for(i=0;i<RAYS;i++){a[i]=walls[i];b[i]=shades[i];walls[i]=999;shades[i]=99;}
for(j=0;j<RAYS;j+=4)castRange(168,j,j+4);
for(i=0;i<RAYS;i++)assert(a[i]==walls[i]&&b[i]==shades[i]);advance();}
puts("PASS 2000 maze poses: eight four-ray setup slices exactly match a full cast.");return 0;}
