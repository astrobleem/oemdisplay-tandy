/* Optional Arwing joystick input. Windows 3.0 / 8086, small model.
   No hardware presence claim: both axes must produce timed transitions.
   A single bounded 512-sample burst per caller-selected polling interval. */
#ifndef STJOY_HOST_TEST
#define WINVER 0x0300
#include <windows.h>
#endif
#include "JOYCORE.H"
#include "STJOY.H"

#define SJ_MARGIN 4
#define SJ_TEXT 80
static JOY_CAL sj_cal;
static unsigned sj_port;
static int sj_enabled;
static unsigned char sj_raw[JOY_SAMPLES];

/* The persisted value is exactly eight unsigned decimal fields:
   version,port,xMin,xMax,xCenter,yMin,yMax,yCenter. No suffix or whitespace.
   Bounds are checked before arithmetic; incomplete reads cannot enable I/O. */
static int sj_valid(const JOY_CAL *c,unsigned port) {
 unsigned a,end,mask;
 if(port>1)return 0;
 a=port*2;end=a+2;mask=3u<<a;
 if((c->seen&mask)!=mask||(c->centered&mask)!=mask)return 0;
 for(;a<end;a++) {
  if(c->low[a]<1||c->high[a]>=JOY_TIMEOUT||
     c->center[a]<=c->low[a]||c->center[a]>=c->high[a])return 0;
  if(c->center[a]-c->low[a]<SJ_MARGIN||
     c->high[a]-c->center[a]<SJ_MARGIN)return 0;
 }
 return 1;
}
static int sj_parse(const char *text,JOY_CAL *result,unsigned *port) {
 unsigned v[8],i,d,n,a;JOY_CAL c;
 for(i=0;i<8;i++) {
  n=0;v[i]=0;
  while(*text>='0'&&*text<='9') {
   if(++n>3)return 0;
   d=(unsigned)(*text++-'0');v[i]=v[i]*10+d;
   if(v[i]>=JOY_TIMEOUT)return 0;
  }
  if(!n)return 0;
  if(i<7){if(*text++!=',')return 0;}else if(*text)return 0;
 }
 if(v[0]!=1||v[1]>1)return 0;
 joy_reset(&c);a=v[1]*2;
 c.low[a]=v[2];c.high[a]=v[3];c.center[a]=v[4];
 c.low[a+1]=v[5];c.high[a+1]=v[6];c.center[a+1]=v[7];
 c.seen=c.centered=(unsigned char)(3u<<a);
 if(!sj_valid(&c,v[1]))return 0;
 *result=c;*port=v[1];return 1;
}
static int sj_timed(const JOY_SAMPLE *s,unsigned port) {
 unsigned mask;if(port>1)return 0;mask=3u<<(port*2);
 return (s->timed&mask)==mask&&!(s->early&mask)&&!(s->timeout&mask);
}
static void sj_sample(JOY_SAMPLE *s) {
 joy_capture(sj_raw);joy_decode(sj_raw,JOY_SAMPLES,s);
}
/* Center 50, neutral 40..60 inclusive: total-width-20 deadzone. */
static int sj_velocity(int n) {
 if(n<0)return 0;
 if(n<25)return -2;if(n<40)return -1;
 if(n<=60)return 0;if(n<=75)return 1;return 2;
}
int sj_read(int *dx,int *dy,int *buttons) {
 JOY_SAMPLE s;int x,y;unsigned a;
 *dx=*dy=*buttons=0;
 if(!sj_enabled||!sj_valid(&sj_cal,sj_port))return 0;
 sj_sample(&s);if(!sj_timed(&s,sj_port))return 0;
 a=sj_port*2;x=joy_normal(&sj_cal,a,s.axis[a]);
 y=joy_normal(&sj_cal,a+1,s.axis[a+1]);
 if(x<0||y<0)return 0;
 *dx=sj_velocity(x);*dy=sj_velocity(y);
 *buttons=(s.buttons>>a)&3;return 1;
}

#ifndef STJOY_HOST_TEST
void sj_load(char *ini) {
 char text[SJ_TEXT];JOY_CAL c;unsigned p;
 sj_enabled=0;joy_reset(&sj_cal);
 if(!ini||!ini[0]||(GetWinFlags()&WF_PMODE))return;
 if(GetPrivateProfileString("Starfield","JoyCal","",text,sizeof(text),ini)
    >=sizeof(text)-1)return;
 if(sj_parse(text,&c,&p)){sj_cal=c;sj_port=p;sj_enabled=1;}
}

#define SJ_CENTER 101
#define SJ_SAVE 102
#define SJ_PORT 103
#define SJ_RESET 104
#define SJ_TIMER 41
static HINSTANCE sj_instance;
static HWND sj_window;
static JOY_CAL sj_work;
static JOY_SAMPLE sj_live;
static unsigned sj_editport;
static int sj_centered,sj_saved,sj_registered;
static char sj_path[144],sj_notice[20];

static void sj_redraw(void) {
 if(sj_window)InvalidateRect(sj_window,NULL,FALSE);
}
static void sj_notice_set(char *text) {
 lstrcpy(sj_notice,text);sj_redraw();
}
static void sj_reset_work(void) {
 joy_reset(&sj_work);joy_decode(sj_raw,0,&sj_live);sj_centered=0;
 if(sj_window)EnableWindow(GetDlgItem(sj_window,SJ_SAVE),FALSE);
 sj_notice_set("Sweep all edges");
}
/* Unlike the diagnostic core's range view, control calibration deliberately
   excludes first-sample-low endpoints as well as never-low timeouts. */
static void sj_track_work(void) {
 unsigned a,end,bit;
 if(!sj_timed(&sj_live,sj_editport))return;
 a=sj_editport*2;end=a+2;
 for(;a<end;a++) {
  bit=1u<<a;
  if(sj_live.axis[a]<sj_work.low[a])sj_work.low[a]=sj_live.axis[a];
  if(sj_live.axis[a]>sj_work.high[a])sj_work.high[a]=sj_live.axis[a];
  sj_work.seen|=(unsigned char)bit;
 }
}
static void sj_poll_work(void) {
 sj_sample(&sj_live);
 if(!sj_centered)sj_track_work();
 if(!sj_timed(&sj_live,sj_editport))sj_notice_set("Signal unknown");
 else if(!lstrcmp(sj_notice,"Signal unknown"))
  sj_notice_set(sj_centered?"Centered; Save":"Sweep; then Center");
 sj_redraw();
}
static void sj_center_work(void) {
 unsigned a;sj_sample(&sj_live);sj_centered=0;sj_work.centered=0;
 EnableWindow(GetDlgItem(sj_window,SJ_SAVE),FALSE);
 if(!sj_timed(&sj_live,sj_editport)){sj_notice_set("Signal unknown");return;}
 a=sj_editport*2;
 sj_work.center[a]=sj_live.axis[a];sj_work.center[a+1]=sj_live.axis[a+1];
 sj_work.centered=(unsigned char)(3u<<a);
 if(!sj_valid(&sj_work,sj_editport)){
  sj_work.centered=0;sj_notice_set("Sweep farther");return;
 }
 sj_centered=1;EnableWindow(GetDlgItem(sj_window,SJ_SAVE),TRUE);
 sj_notice_set("Centered; Save");
}
static void sj_save_work(void) {
 char text[SJ_TEXT],readback[SJ_TEXT];unsigned a;int x,y;HFILE existing;LPSTR destination;
 if(!sj_centered||!sj_valid(&sj_work,sj_editport)){
  sj_notice_set("Center first");return;
 }
 sj_sample(&sj_live);
 if(!sj_timed(&sj_live,sj_editport)){sj_notice_set("Signal unknown");return;}
 a=sj_editport*2;x=joy_normal(&sj_work,a,sj_live.axis[a]);
 y=joy_normal(&sj_work,a+1,sj_live.axis[a+1]);
 if(x<40||x>60||y<40||y>60){sj_notice_set("Release the stick");return;}
 wsprintf(text,"1,%u,%u,%u,%u,%u,%u,%u",sj_editport,
  sj_work.low[a],sj_work.high[a],sj_work.center[a],
  sj_work.low[a+1],sj_work.high[a+1],sj_work.center[a+1]);
 /* One key avoids separately committed port/range/center combinations.
    Readback is verified; this is not a power-loss-atomic filesystem promise. */
 existing=_lopen(sj_path,OF_READ|OF_SHARE_DENY_NONE);
 destination=sj_path;
 if(existing==HFILE_ERROR)destination="TSHELL.INI";else _lclose(existing);
 if(!WritePrivateProfileString("Starfield","JoyCal",text,destination)){
  sj_notice_set("Save failed");return;
 }
 GetPrivateProfileString("Starfield","JoyCal","",readback,sizeof(readback),sj_path);
 if(lstrcmp(text,readback)){sj_notice_set("Save not verified");return;}
 sj_cal=sj_work;sj_port=sj_editport;sj_enabled=1;sj_saved=1;
 DestroyWindow(sj_window);
}
static void sj_action(unsigned id) {
 if(id==SJ_CENTER)sj_center_work();
 else if(id==SJ_SAVE)sj_save_work();
 else if(id==SJ_PORT){sj_editport=1-sj_editport;sj_reset_work();}
 else if(id==SJ_RESET)sj_reset_work();
}
static HWND sj_button(HWND w,char *s,int x,int y,int id) {
 HWND b;b=CreateWindow("BUTTON",s,WS_CHILD|WS_VISIBLE|WS_TABSTOP,
   x,y,70,20,w,(HMENU)id,sj_instance,NULL);
 if(b)SendMessage(b,WM_SETFONT,(WPARAM)GetStockObject(SYSTEM_FIXED_FONT),0L);
 return b;
}
static void sj_line(HDC dc,int y,char *s) {
 TextOut(dc,4,y,s,lstrlen(s));
}
static void sj_paint(HWND w) {
 PAINTSTRUCT ps;HDC dc;RECT r;char text[24];unsigned a,i;
 dc=BeginPaint(w,&ps);GetClientRect(w,&r);
 FillRect(dc,&r,GetStockObject(WHITE_BRUSH));
 SelectObject(dc,GetStockObject(SYSTEM_FIXED_FONT));
 SetBkMode(dc,TRANSPARENT);SetTextColor(dc,RGB(0,0,0));
 sj_line(dc,2,"JOYSTICK: Esc exits");
 sj_line(dc,18,sj_editport?"LEFT PORT (P)":"RIGHT PORT (P)");
 sj_line(dc,34,"1 Sweep all edges");sj_line(dc,50,"2 Release; Center");
 a=sj_editport*2;
 for(i=0;i<2;i++,a++) {
  if(sj_work.seen&(1u<<a)) {
   if(sj_centered)wsprintf(text,"%s %03u..%03u C%03u",(LPSTR)(i?"Y":"X"),
     sj_work.low[a],sj_work.high[a],sj_work.center[a]);
   else wsprintf(text,"%s %03u..%03u C---",(LPSTR)(i?"Y":"X"),
     sj_work.low[a],sj_work.high[a]);
  }else lstrcpy(text,i?"Y ---..--- C---":"X ---..--- C---");
  sj_line(dc,66+(int)i*16,text);
 }
 sj_line(dc,98,sj_notice);EndPaint(w,&ps);
}
LONG FAR PASCAL SJCalProc(HWND w,UINT m,WPARAM wp,LPARAM lp) {
 switch(m) {
 case WM_CREATE:
  sj_window=w;
  if(!sj_button(w,"&Center",4,118,SJ_CENTER)||
     !sj_button(w,"&Save",78,118,SJ_SAVE)||
     !sj_button(w,"&Port",4,142,SJ_PORT)||
     !sj_button(w,"&Reset",78,142,SJ_RESET))return -1;
  EnableWindow(GetDlgItem(w,SJ_SAVE),FALSE);
  if(!SetTimer(w,SJ_TIMER,250,NULL))return -1;return 0;
 case WM_COMMAND:sj_action(wp);return 0;
 case WM_TIMER:
  if(wp==SJ_TIMER&&GetActiveWindow()==w&&!IsIconic(w))sj_poll_work();return 0;
 case WM_PAINT:sj_paint(w);return 0;
 case WM_QUERYENDSESSION:return TRUE;
 case WM_ENDSESSION:if(wp)DestroyWindow(w);return 0;
 case WM_CLOSE:DestroyWindow(w);return 0;
 case WM_DESTROY:KillTimer(w,SJ_TIMER);sj_window=NULL;return 0;
 }
 return DefWindowProc(w,m,wp,lp);
}
int sj_calibrate(HINSTANCE inst,LPSTR ini) {
 WNDCLASS wc;RECT r;MSG msg;HWND w,next;int x,y,width,height,quit=0;
 DWORD style=WS_POPUP|WS_CAPTION|WS_SYSMENU|WS_CLIPCHILDREN;
 if(sj_window||!ini||!ini[0]||lstrlen(ini)>=sizeof(sj_path)||
    (GetWinFlags()&WF_PMODE))return 0;
 sj_instance=inst;lstrcpy(sj_path,ini);sj_saved=0;
 sj_editport=sj_enabled?sj_port:0;sj_reset_work();
 if(!sj_registered) {
  wc.style=CS_HREDRAW|CS_VREDRAW;wc.lpfnWndProc=SJCalProc;
  wc.cbClsExtra=wc.cbWndExtra=0;wc.hInstance=inst;wc.hIcon=NULL;
  wc.hCursor=LoadCursor(NULL,IDC_ARROW);wc.hbrBackground=GetStockObject(WHITE_BRUSH);
  wc.lpszMenuName=NULL;wc.lpszClassName="StarfieldJoyCal";
  if(!RegisterClass(&wc))return 0;sj_registered=1;
 }
 r.left=r.top=0;r.right=152;r.bottom=166;AdjustWindowRect(&r,style,FALSE);
 width=r.right-r.left;height=r.bottom-r.top;
 x=(GetSystemMetrics(SM_CXSCREEN)-width)/2;
 y=(GetSystemMetrics(SM_CYSCREEN)-height)/2;if(x<0)x=0;if(y<0)y=0;
 w=CreateWindow("StarfieldJoyCal","Joystick",style,x,y,width,height,
  NULL,NULL,inst,NULL);
 if(!w){sj_window=NULL;return 0;}
 ShowWindow(w,SW_SHOW);UpdateWindow(w);SetFocus(GetDlgItem(w,SJ_CENTER));
 while(sj_window) {
  if(!GetMessage(&msg,NULL,0,0)){quit=1;break;}
  if(msg.message==WM_KEYDOWN&&(msg.hwnd==w||IsChild(w,msg.hwnd))) {
   if(msg.wParam==VK_ESCAPE){DestroyWindow(w);continue;}
   if(msg.wParam=='C'){sj_action(SJ_CENTER);continue;}
   if(msg.wParam=='S'){sj_action(SJ_SAVE);continue;}
   if(msg.wParam=='P'){sj_action(SJ_PORT);continue;}
   if(msg.wParam=='R'){sj_action(SJ_RESET);continue;}
   if(msg.wParam==VK_TAB){
    next=GetNextDlgTabItem(w,GetFocus(),GetKeyState(VK_SHIFT)<0);
    if(next)SetFocus(next);continue;
   }
   if(msg.wParam==VK_RETURN){
    next=GetFocus();if(next&&IsChild(w,next))sj_action(GetDlgCtrlID(next));
    continue;
   }
  }
  TranslateMessage(&msg);DispatchMessage(&msg);
 }
 if(sj_window)DestroyWindow(sj_window);
 if(quit)PostQuitMessage(msg.wParam);
 return sj_saved;
}
#endif
