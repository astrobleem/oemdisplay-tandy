#include "STFLY.H"
static int clamp(int n,int lo,int hi){return n<lo?lo:n>hi?hi:n;}
static int magnitude(int n){return n<0?-n:n;}
/* Positive division keeps the rounding symmetric on every C89 compiler.
   The largest numerator is 320*64+32, within a signed 8086 int. */
static int fraction(int n,int scale,int divisor){int value;
 value=(magnitude(n)*scale+divisor/2)/divisor;
 return n<0?-value:value;
}
static void project(FLY *f,FLY_SHOT *s){
 static unsigned char depth[FLY_SHOT_AGES]={
  64,56,48,41,35,30,25,21,17,14,11,8,6,4,2,1,0};
 int cx,cy,scale,dx,dy,distance,length;
 if(s->age>=FLY_SHOT_AGES){s->active=0;return;}
 cx=f->width/2;cy=f->height/2;scale=depth[s->age];
 s->tailx=cx+fraction(s->originx-cx,scale,64);
 s->taily=cy+fraction(s->originy-cy,scale,64);
 dx=cx-s->tailx;dy=cy-s->taily;
 distance=magnitude(dx);
 if(magnitude(dy)>distance)distance=magnitude(dy);
 /* Near-point launches and arrivals retire here, never at a screen edge. */
 if(distance<=1){s->active=0;return;}
 length=(FLY_LASER_H*scale+63)/64;
 if(length>distance)length=distance;
 s->headx=s->tailx+fraction(dx,length,distance);
 s->heady=s->taily+fraction(dy,length,distance);
 s->thick=scale>=32?f->scale:1;
 s->x=s->tailx<s->headx?s->tailx:s->headx;
 s->y=s->taily<s->heady?s->taily:s->heady;
 s->w=magnitude(s->headx-s->tailx)+s->thick;
 s->h=magnitude(s->heady-s->taily)+1;
}
void fly_init(FLY *f,int width,int height){int i;
 f->width=width;f->height=height;f->w=width<240?16:width<480?32:64;
 f->scale=width<480?1:2;f->x=(width-f->w)/2;f->y=height*2/3;
 f->pose=1;f->autox=1;f->autoy=-1;f->phase=f->cooldown=0;
 f->fired=f->steps=0;for(i=0;i<FLY_SHOTS;i++)f->shots[i].active=0;
}
void fly_step(FLY *f,int joystick,int dx,int dy,int buttons){int i,vx,vy;
 FLY_SHOT *s;
 f->steps++;f->phase=(f->phase+1)%4;
 if(joystick){vx=clamp(dx,-2,2);vy=clamp(dy,-2,2);}
 else{
  if(f->x<f->width/5)f->autox=1;
  if(f->x>f->width*4/5-f->w)f->autox=-1;
  if(f->y<f->height/2)f->autoy=1;
  if(f->y>f->height*3/4)f->autoy=-1;
  vx=f->autox;vy=f->phase?0:f->autoy;
 }
 f->x=clamp(f->x+vx*f->scale,2,f->width-f->w-2);
 f->y=clamp(f->y+vy,30,f->height-FLY_HEIGHT-2);
 f->pose=vx<0?0:vx>0?2:1;
 for(i=0;i<FLY_SHOTS;i++)if(f->shots[i].active){
  f->shots[i].age++;project(f,&f->shots[i]);
 }
 if(f->cooldown)f->cooldown--;
 if(joystick&&buttons&&!f->cooldown){
  for(i=0;i<FLY_SHOTS;i++)if(!f->shots[i].active){
   s=&f->shots[i];
   /* Wing tips match the native 32-pixel ARTBUILD.PY polygon, including
      the three bank poses. Only X is scaled; ship height stays 26. */
   if(f->fired&1){
    s->originx=f->x+(30*(f->w-1)+15)/31;
    s->originy=f->y+6+3*f->pose;
   }else{
    s->originx=f->x+((f->w-1)+15)/31;
    s->originy=f->y+12-3*f->pose;
   }
   s->age=0;s->active=1;project(f,s);
   f->fired++;f->cooldown=3;break;
  }
 }
}
