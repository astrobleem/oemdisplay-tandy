#define WINVER 0x0300
#include <windows.h>
static HINSTANCE inst;static HWND host,ts,cfg,opt,sv;static int step,waits,failed,pauseTicks;static char ini[144];
static void log(char *s){HFILE f=_lopen("C:\\TSGUI.LOG",OF_WRITE);if(f==HFILE_ERROR)f=_lcreat("C:\\TSGUI.LOG",0);if(f!=HFILE_ERROR){_llseek(f,0L,2);_lwrite(f,s,lstrlen(s));_lwrite(f,"\r\n",2);_lclose(f);}}
static void check(char *s,int ok){char b[130];wsprintf(b,"%s step=%d %s",(LPSTR)(ok?"PASS":"FAIL"),step,(LPSTR)s);log(b);if(!ok)failed++;}
static void click(HWND w,int id){HWND b=GetDlgItem(w,id);SetActiveWindow(w);SetFocus(b);PostMessage(w,WM_COMMAND,id,MAKELONG(b,BN_CLICKED));}
static void radio(HWND w,int id){click(w,id);}
static void shot(char *name){HFILE f=_lcreat(name,0);if(f!=HFILE_ERROR){_lwrite(f,(void FAR *)0xb8000000L,32768U);_lclose(f);}}
static int conf(char *key,int d){return GetPrivateProfileInt("Starfield",key,d,ini);}
static void tick(void){RECT r;char b[140];HWND n;
 if(++waits>300){log("FAIL watchdog");failed++;step=99;}
 cfg=FindWindow(NULL,"Screen saver");opt=FindWindow("#32770","Starfield");sv=FindWindow("TandyStarfieldSaver",NULL);
 switch(step){
 case 0:ts=FindWindow("TandyStart",NULL);if(!ts)return;check("shell running",1);PostMessage(ts,WM_COMMAND,48,0L);break;
 case 1:if(!cfg)return;radio(cfg,119);break;
 case 2:click(cfg,126);break;
 case 3:if(!opt)return;GetWindowRect(opt,&r);check("options fit screen",r.left>=0&&r.top>=0&&r.right<=GetSystemMetrics(SM_CXSCREEN)&&r.bottom<=200);check("legacy default plain speed2 stars32",!IsDlgButtonChecked(opt,136)&&IsDlgButtonChecked(opt,131)&&IsDlgButtonChecked(opt,134));shot("C:\\OPTIONS.BIN");radio(opt,132);break;
 case 4:radio(opt,133);CheckDlgButton(opt,136,1);break;
 case 5:click(opt,IDOK);break;
 case 6:if(opt)return;check("OK staged no INI write",conf("Arwing",-1)==-1&&conf("Speed",0)==2&&conf("Stars",0)==32);click(cfg,124);break;
 case 7:if(!sv)return;check("Arwing preview captured only saver",GetCapture()==sv);if(++pauseTicks<6)return;pauseTicks=0;shot("C:\\FLIGHT.BIN");PostMessage(sv,WM_KEYDOWN,VK_ESCAPE,0L);PostMessage(sv,WM_KEYUP,VK_ESCAPE,0L);break;
 case 8:if(sv)return;check("preview exit releases capture and returns dialog",GetCapture()==NULL&&GetActiveWindow()==cfg);check("preview preserves unsaved INI",conf("Arwing",-1)==-1);click(cfg,126);break;
 case 9:if(!opt)return;check("staged choices reopen",IsDlgButtonChecked(opt,136)&&IsDlgButtonChecked(opt,132)&&IsDlgButtonChecked(opt,133));CheckDlgButton(opt,136,0);click(opt,IDCANCEL);break;
 case 10:if(opt)return;click(cfg,126);break;
 case 11:if(!opt)return;check("Options Cancel preserves stage",IsDlgButtonChecked(opt,136)&&IsDlgButtonChecked(opt,132)&&IsDlgButtonChecked(opt,133));click(opt,IDOK);break;
 case 12:if(opt)return;click(cfg,125);break;
 case 13:n=FindWindow(NULL,"Saver");if(!n)return;check("Apply saves full tuple",conf("Arwing",-1)==1&&conf("Speed",0)==3&&conf("Stars",0)==16);click(n,IDOK);break;
 case 14:click(cfg,IDCANCEL);break;
 case 15:if(cfg)return;PostMessage(ts,WM_COMMAND,48,0L);break;
 case 16:if(!cfg)return;click(cfg,126);break;
 case 17:if(!opt)return;check("saved choices survive dialog reopen",IsDlgButtonChecked(opt,136)&&IsDlgButtonChecked(opt,132)&&IsDlgButtonChecked(opt,133));CheckDlgButton(opt,136,0);radio(opt,130);break;
 case 18:radio(opt,135);break;
 case 19:click(opt,IDOK);break;
 case 20:if(opt)return;click(cfg,124);break;
 case 21:if(!sv)return;if(++pauseTicks<6)return;pauseTicks=0;shot("C:\\PLAIN.BIN");PostMessage(sv,WM_MOUSEMOVE,0,MAKELONG(10,10));break;
 case 22:if(sv)return;check("plain preview exit releases capture",GetCapture()==NULL);check("second preview preserves prior Apply",conf("Arwing",-1)==1&&conf("Speed",0)==3&&conf("Stars",0)==16);click(cfg,IDCANCEL);break;
 case 23:if(cfg)return;PostMessage(ts,WM_COMMAND,48,0L);break;
 case 24:if(!cfg)return;click(cfg,126);break;
 case 25:if(!opt)return;check("outer Cancel discards staged off",IsDlgButtonChecked(opt,136)&&IsDlgButtonChecked(opt,132)&&IsDlgButtonChecked(opt,133));click(opt,IDCANCEL);break;
 case 26:if(opt)return;click(cfg,IDCANCEL);break;
 case 27:if(cfg)return;PostMessage(ts,WM_CLOSE,0,0L);break;
 case 28:if(FindWindow("TandyStart",NULL))return;check("shell closes after repeat preview",GetCapture()==NULL);step=98;break;
 case 99:wsprintf(b,"DONE failures=%d",failed);log(b);KillTimer(host,1);ExitWindows(0L,0);DestroyWindow(host);return;
 }
 step++;waits=0;
}
LONG FAR PASCAL GuiProc(HWND w,UINT m,WPARAM wp,LPARAM lp){if(m==WM_TIMER){tick();return 0;}if(m==WM_DESTROY){PostQuitMessage(0);return 0;}return DefWindowProc(w,m,wp,lp);}
int PASCAL WinMain(HINSTANCE i,HINSTANCE prev,LPSTR cmd,int show){WNDCLASS wc;MSG msg;HFILE f;inst=i;f=_lcreat("C:\\TSGUI.LOG",0);if(f!=HFILE_ERROR)_lclose(f);GetWindowsDirectory(ini,sizeof(ini));lstrcat(ini,"\\TSHELL.INI");
 wc.style=0;wc.lpfnWndProc=GuiProc;wc.cbClsExtra=wc.cbWndExtra=0;wc.hInstance=i;wc.hIcon=NULL;wc.hCursor=NULL;wc.hbrBackground=NULL;wc.lpszMenuName=NULL;wc.lpszClassName="TSGUI";RegisterClass(&wc);
 host=CreateWindow("TSGUI","QA",WS_POPUP,0,0,1,1,NULL,NULL,i,NULL);SetTimer(host,1,300,NULL);WinExec("C:\\WINDOWS\\TSHELL.EXE",SW_SHOW);
 while(GetMessage(&msg,NULL,0,0)){TranslateMessage(&msg);DispatchMessage(&msg);}return failed;}
