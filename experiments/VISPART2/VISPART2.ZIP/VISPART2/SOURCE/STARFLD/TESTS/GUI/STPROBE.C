#define WINVER 0x0300
#include <windows.h>
int PASCAL WinMain(HINSTANCE i,HINSTANCE p,LPSTR cmd,int show){HFILE f;char b[180];
 f=_lopen("C:\\PROBE.LOG",OF_WRITE);if(f==HFILE_ERROR)f=_lcreat("C:\\PROBE.LOG",0);
 if(f!=HFILE_ERROR){_llseek(f,0L,2);_lwrite(f,cmd,lstrlen(cmd));_lwrite(f,"\r\n",2);_lclose(f);}
 lstrcpy(b,"C:\\WINDOWS\\STARFLD.EXE ");lstrcat(b,cmd);WinExec(b,SW_SHOW);return 0;}
