#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "STFLY.H"
#define WHITENESS 0
static int screenDC;
static unsigned long boltPatches;
static unsigned char output[8][8],expected[8][8];
static void PatBlt(int dc,int x,int y,int w,int h,int rop){int i,j;(void)dc;(void)rop;
 assert(x>=0&&y>=0&&w>0&&h>0&&x+w<=8&&y+h<=8);
 for(j=y;j<y+h;j++)for(i=x;i<x+w;i++)output[j][i]=1;
}
static void drawBolt(FLY_SHOT *q){unsigned char bits[16];int i,n,x,y,xx,yy,dx,dy,sx,sy,err,e2;
 if(!q->active)return;for(i=0;i<16;i++)bits[i]=0;
 x=q->tailx-q->x;y=q->taily-q->y;xx=q->headx-q->x;yy=q->heady-q->y;
 dx=xx>x?xx-x:x-xx;dy=yy>y?yy-y:y-yy;sx=x<xx?1:-1;sy=y<yy?1:-1;err=dx-dy;
 for(n=0;n<8;n++){
  for(i=0;i<q->thick;i++)bits[y*2]|=(unsigned char)(128U>>(x+i));
  if(x==xx&&y==yy)break;e2=err*2;
  if(e2>-dy){err-=dy;x+=sx;}if(e2<dx){err+=dx;y+=sy;}
 }
 /* Each Bresenham row is one contiguous run, including thick==2.
    Equal neighboring rows can use one WHITENESS rectangle. At most seven
    solid patches per bolt; no object allocation or bitmap upload per frame. */
 y=0;while(y<q->h){
  if(!bits[y*2]){y++;continue;}
  x=0;while(!(bits[y*2]&(128U>>x)))x++;
  xx=q->w-1;while(!(bits[y*2]&(128U>>xx)))xx--;
  yy=y+1;while(yy<q->h&&bits[yy*2]==bits[y*2])yy++;
  PatBlt(screenDC,q->x+x,q->y+y,xx-x+1,yy-y,WHITENESS);boltPatches++;y=yy;
 }
}
static void reference(FLY_SHOT *q){int x,y,dx,dy,sx,sy,e,i,major;
 x=q->tailx;y=q->taily;dx=q->headx-x;dy=q->heady-y;sx=dx<0?-1:1;sy=dy<0?-1:1;if(dx<0)dx=-dx;if(dy<0)dy=-dy;
 if(dx>=dy){e=dx/2;for(major=0;major<=dx;major++){for(i=0;i<q->thick;i++)expected[y][x+i]=1;x+=sx;e-=dy;if(e<0){y+=sy;e+=dx;}}}
 else{e=dy/2;for(major=0;major<=dy;major++){for(i=0;i<q->thick;i++)expected[y][x+i]=1;y+=sy;e-=dx;if(e<0){x+=sx;e+=dy;}}}
}
int main(void){FLY_SHOT q;int tx,ty,hx,hy,t,dx,dy;unsigned n=0;unsigned long before;
 for(ty=0;ty<=6;ty++)for(tx=0;tx<=6;tx++)for(hy=0;hy<=6;hy++)for(hx=0;hx<=6;hx++)for(t=1;t<=2;t++){
  q.active=1;q.tailx=tx;q.taily=ty;q.headx=hx;q.heady=hy;q.thick=t;
  q.x=tx<hx?tx:hx;q.y=ty<hy?ty:hy;dx=tx-hx;if(dx<0)dx=-dx;dy=ty-hy;if(dy<0)dy=-dy;q.w=dx+t;q.h=dy+1;
  memset(output,0,sizeof(output));memset(expected,0,sizeof(expected));before=boltPatches;
  drawBolt(&q);reference(&q);assert(!memcmp(output,expected,sizeof(output)));assert(boltPatches-before<=7);n++;
 }
 printf("PASS %u production raster cases: exact reference pixels, tight8x8 bounds, at most7 coalesced patches\n",n);return 0;
}
