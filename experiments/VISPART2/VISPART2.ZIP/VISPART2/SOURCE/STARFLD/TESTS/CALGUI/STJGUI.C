#define WINVER 0x0300
#include <windows.h>
#include "STJOY.C"
static unsigned captures,tx=60,ty=70;
static int failures,checks,stage,phase;
static DWORD began;
static HFILE logf;
static char path[144],saved[80];
void joy_capture(unsigned char *raw) {
 unsigned i;captures++;
 for(i=0;i<JOY_SAMPLES;i++)raw[i]=(unsigned char)(0xf0|(i<tx?1:0)|(i<ty?2:0));
}
static void logtext(char *text){_lwrite(logf,text,lstrlen(text));_lwrite(logf,"\r\n",2);}
static void check(char *text,int ok){char b[120];checks++;if(!ok)failures++;wsprintf(b,"%s %s",(LPSTR)(ok?"PASS":"FAIL"),(LPSTR)text);logtext(b);}
static void bounds(void){
 RECT win,client,br;POINT p;HDC dc;TEXTMETRIC tm;DWORD ext;char b[80];int i,ok=1;HWND control;
 GetWindowRect(sj_window,&win);GetClientRect(sj_window,&client);
 wsprintf(b,"BOUNDS window=%d,%d,%d,%d client=%d,%d",win.left,win.top,win.right,win.bottom,client.right,client.bottom);logtext(b);
 check("screen is 160x200",GetSystemMetrics(SM_CXSCREEN)==160&&GetSystemMetrics(SM_CYSCREEN)==200);
 check("calibration outer window fits screen",win.left>=0&&win.top>=0&&win.right<=160&&win.bottom<=200);
 for(i=SJ_CENTER;i<=SJ_RESET;i++){
  control=GetDlgItem(sj_window,i);check("calibration control exists",control!=NULL);
  if(!control){ok=0;continue;}GetWindowRect(control,&br);p.x=br.left;p.y=br.top;ScreenToClient(sj_window,&p);
  if(p.x<0||p.y<0||p.x+br.right-br.left>client.right||p.y+br.bottom-br.top>client.bottom)ok=0;
  dc=GetDC(control);SelectObject(dc,GetStockObject(SYSTEM_FIXED_FONT));GetWindowText(control,b,sizeof(b));ext=GetTextExtent(dc,b,lstrlen(b));
  check("button caption fits its control",(int)LOWORD(ext)<br.right-br.left&&(int)HIWORD(ext)<br.bottom-br.top);ReleaseDC(control,dc);
 }
 check("all controls inside calibration client",ok);
 dc=GetDC(sj_window);SelectObject(dc,GetStockObject(SYSTEM_FIXED_FONT));GetTextMetrics(dc,&tm);
 ext=GetTextExtent(dc,"JOYSTICK: Esc exits",18);
 check("longest instruction fits client",4+(int)LOWORD(ext)<=client.right);
 check("text rows fit without vertical overlap",tm.tmHeight<=16);
 wsprintf(b,"FONT average=%d max=%d height=%d",tm.tmAveCharWidth,tm.tmMaxCharWidth,tm.tmHeight);logtext(b);
 ReleaseDC(sj_window,dc);
}
LONG FAR PASCAL TestProc(HWND w,UINT m,WPARAM wp,LPARAM lp){
 if(m==WM_TIMER){
  if(GetTickCount()-began>35000UL){logtext("FAIL WATCHDOG");failures++;if(sj_window)DestroyWindow(sj_window);ExitWindows(0L,0);return 0;}
  if(!sj_window||phase==1||phase==3)return 0;
  if(stage==0){bounds();check("Save initially disabled",!IsWindowEnabled(GetDlgItem(sj_window,SJ_SAVE)));SendMessage(sj_window,WM_COMMAND,SJ_CENTER,0L);check("Center before range rejected",!sj_centered&&!sj_work.centered&&!IsWindowEnabled(GetDlgItem(sj_window,SJ_SAVE)));tx=10;ty=20;stage++;}
  else if(stage==1){check("low range arrived through timer",sj_work.low[0]==10&&sj_work.low[1]==20);tx=110;ty=120;stage++;}
  else if(stage==2){check("high range arrived through timer",sj_work.high[0]==110&&sj_work.high[1]==120);tx=60;ty=70;stage++;}
  else if(stage==3){SendMessage(sj_window,WM_COMMAND,SJ_CENTER,0L);check("manual center accepted",sj_centered&&sj_work.center[0]==60&&sj_work.center[1]==70);check("valid center enables Save",IsWindowEnabled(GetDlgItem(sj_window,SJ_SAVE)));tx=ty=512;SendMessage(sj_window,WM_COMMAND,SJ_SAVE,0L);check("disconnect before Save rejected",sj_window&&!sj_saved);GetPrivateProfileString("Starfield","JoyCal","",saved,sizeof(saved),path);check("rejected Save did not write value",!saved[0]);tx=60;ty=70;stage++;}
  else if(stage==4){SendMessage(sj_window,WM_COMMAND,SJ_SAVE,0L);check("valid Save closes calibration",!sj_window&&sj_saved);stage++;}
  else if(stage==5){check("reopened calibration has no implicit center",!sj_centered&&!sj_work.centered);SendMessage(sj_window,WM_COMMAND,SJ_PORT,0L);check("Port switches to left and clears range",sj_editport==1&&!sj_work.seen&&!sj_work.centered);stage++;}
  else if(stage==6){PostMessage(sj_window,WM_KEYDOWN,VK_ESCAPE,0L);stage++;}
  return 0;
 }
 if(m==WM_DESTROY){KillTimer(w,1);return 0;}
 return DefWindowProc(w,m,wp,lp);
}
static void waittime(DWORD duration){MSG msg;DWORD t=GetTickCount();while(GetTickCount()-t<duration&&GetMessage(&msg,NULL,0,0)){TranslateMessage(&msg);DispatchMessage(&msg);}}
int PASCAL WinMain(HINSTANCE inst,HINSTANCE prev,LPSTR cmd,int show){
 WNDCLASS wc;HWND controller;unsigned before;int result;HFILE f;char verify[80],b[100];
 logf=_lcreat("C:\\STJGUI.LOG",0);began=GetTickCount();
 GetWindowsDirectory(path,sizeof(path));lstrcat(path,"\\TSHELL.INI");
 f=_lopen(path,OF_READ);check("TSHELL.INI is initially absent",f==HFILE_ERROR);if(f!=HFILE_ERROR)_lclose(f);
 sj_load(path);before=captures;check("missing calibration disabled",!sj_enabled);{int x,y,buttons;check("disabled read has no capture",!sj_read(&x,&y,&buttons)&&captures==before&&!x&&!y&&!buttons);}
 wc.style=0;wc.lpfnWndProc=TestProc;wc.cbClsExtra=wc.cbWndExtra=0;wc.hInstance=inst;wc.hIcon=NULL;wc.hCursor=NULL;wc.hbrBackground=NULL;wc.lpszMenuName=NULL;wc.lpszClassName="StjGuiController";
 if(!RegisterClass(&wc))return 2;
 controller=CreateWindow("StjGuiController","",WS_POPUP,0,0,1,1,NULL,NULL,inst,NULL);
 if(!controller||!SetTimer(controller,1,1000,NULL))return 3;
 result=sj_calibrate(inst,path);check("first calibration returned saved",result==1);
 GetPrivateProfileString("Starfield","JoyCal","",saved,sizeof(saved),path);
 check("first creation full-path readback matches",!lstrcmp(saved,"1,0,10,110,60,20,120,70"));
 f=_lopen(path,OF_READ);check("TSHELL.INI now exists",f!=HFILE_ERROR);if(f!=HFILE_ERROR)_lclose(f);
 phase=1;before=captures;waittime(1500UL);check("no capture after Save closes window",captures==before&&!sj_window);
 sj_load(path);check("saved calibration reloads",sj_enabled&&sj_port==0);
 phase=2;result=sj_calibrate(inst,path);check("Escape cancels reopened window",result==0&&!sj_window);
 GetPrivateProfileString("Starfield","JoyCal","",verify,sizeof(verify),path);check("Escape preserves saved calibration",!lstrcmp(saved,verify));
 phase=3;before=captures;waittime(1500UL);check("no capture after Escape closes window",captures==before&&!sj_window);
 DestroyWindow(controller);wsprintf(b,"TOTAL_FAILURES=%d CHECKS=%d CAPTURES=%u",failures,checks,captures);logtext(b);_lclose(logf);ExitWindows(0L,0);return failures;
}
