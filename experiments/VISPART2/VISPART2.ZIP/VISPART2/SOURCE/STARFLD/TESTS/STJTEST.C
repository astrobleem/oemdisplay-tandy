#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define STJOY_HOST_TEST
#include "STJOY.C"
static unsigned checks, captures;
static unsigned char injected[JOY_SAMPLES];
#define CHECK(x) do {checks++;if(!(x)){fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#x);exit(1);}}while(0)
void joy_capture(unsigned char *r) {captures++;memcpy(r,injected,JOY_SAMPLES);}
static void burst(unsigned x,unsigned y,unsigned lx,unsigned ly,unsigned buttons) {
 unsigned i,a,t[4];t[0]=x;t[1]=y;t[2]=lx;t[3]=ly;
 for(i=0;i<JOY_SAMPLES;i++) {injected[i]=(unsigned char)((~buttons&15)<<4);
  for(a=0;a<4;a++)if(i<t[a])injected[i]|=(unsigned char)(1u<<a);
 }
}
static int enable(const char *text) {
 sj_enabled=sj_parse(text,&sj_cal,&sj_port);return sj_enabled;
}
int main(void) {
 const char *good="1,0,10,110,60,20,120,70";
 const char *bad[]={"","1","1,0,10,110,60,20,120","1,0,10,110,60,20,120,70,1",
 " 1,0,10,110,60,20,120,70","1,0,10,110,60,20,120,70 ","1,0,10,110,60,20,120,70x",
 "1,0,10,110,60,20,120,70\n","1,0,10,110,60,20,120,-70","1,0,10,110,60,20,120,+70",
 "1,0,10,,60,20,120,70","2,0,10,110,60,20,120,70","1,2,10,110,60,20,120,70",
 "1,0,0,110,60,20,120,70","1,0,10,512,60,20,120,70","1,0,10,110,10,20,120,70",
 "1,0,10,110,110,20,120,70","1,0,10,110,13,20,120,70","1,0,10,110,107,20,120,70",
 "1,0,10,110,60,20,120,23","1,0,10,110,60,20,120,117","1,0,10,110,60,20,120,1000",
 "1,0,10,110,60,120,20,70","1,0,10,110,60,20,120,9999999999999999999999999"};
 unsigned i,p,b,x,y,before;int dx,dy,buttons;char text[100];JOY_CAL c,old;unsigned port;
 for(i=0;i<sizeof(bad)/sizeof(bad[0]);i++) {
  memset(&c,0x5a,sizeof(c));old=c;port=17;
  CHECK(!sj_parse(bad[i],&c,&port));CHECK(!memcmp(&c,&old,sizeof(c)));CHECK(port==17);
 }
 for(i=0;i<strlen(good);i++){memcpy(text,good,i);text[i]=0;CHECK(!sj_parse(text,&c,&port));}
 CHECK(sj_parse("1,0,1,9,5,503,511,507",&c,&port));CHECK(port==0);
 CHECK(sj_parse("1,1,1,9,5,503,511,507",&c,&port));CHECK(port==1);
 CHECK(!sj_parse("1,1,1,8,5,503,511,507",&c,&port));
 CHECK(!sj_parse("1,1,1,9,5,504,511,507",&c,&port));
 sj_enabled=0;before=captures;dx=dy=buttons=99;
 CHECK(!sj_read(&dx,&dy,&buttons));CHECK(!dx&&!dy&&!buttons&&captures==before);
 CHECK(enable(good));
 for(p=0;p<2;p++) {
  sprintf(text,"1,%u,10,110,60,20,120,70",p);CHECK(enable(text));
  for(x=0;x<=100;x++)for(y=0;y<=100;y++) {
   if(p)burst(0,512,10+x,20+y,0);else burst(10+x,20+y,0,512,0);
   CHECK(sj_read(&dx,&dy,&buttons));CHECK(dx==sj_velocity((int)x));
   CHECK(dy==sj_velocity((int)y));CHECK(!buttons);
  }
  for(b=0;b<16;b++) {
   burst(60,70,60,70,b);CHECK(sj_read(&dx,&dy,&buttons));
   CHECK(dx==0&&dy==0&&buttons==(int)((b>>(p*2))&3));
  }
  for(i=0;i<4;i++) {
   x=(i&1)?512:0;y=(i&2)?512:0;
   if(p)burst(60,70,x,y,15);else burst(x,y,60,70,15);
   dx=dy=buttons=99;CHECK(!sj_read(&dx,&dy,&buttons));CHECK(!dx&&!dy&&!buttons);
  }
  if(p)burst(60,70,0,70,15);else burst(0,70,60,70,15);
  CHECK(!sj_read(&dx,&dy,&buttons));CHECK(!dx&&!dy&&!buttons);
  if(p)burst(60,70,60,512,15);else burst(60,512,60,70,15);
  CHECK(!sj_read(&dx,&dy,&buttons));CHECK(!dx&&!dy&&!buttons);
 }
 CHECK(sj_velocity(0)==-2&&sj_velocity(24)==-2&&sj_velocity(25)==-1);
 CHECK(sj_velocity(39)==-1&&sj_velocity(40)==0&&sj_velocity(50)==0);
 CHECK(sj_velocity(60)==0&&sj_velocity(61)==1&&sj_velocity(75)==1);
 CHECK(sj_velocity(76)==2&&sj_velocity(100)==2);
 memset(injected,255,sizeof(injected));CHECK(!sj_read(&dx,&dy,&buttons));CHECK(!dx&&!dy&&!buttons);
 memset(injected,0,sizeof(injected));CHECK(!sj_read(&dx,&dy,&buttons));CHECK(!dx&&!dy&&!buttons);
 CHECK(!enable("1,0,0,110,60,20,120,70"));before=captures;
 CHECK(!sj_read(&dx,&dy,&buttons));CHECK(captures==before&&!dx&&!dy&&!buttons);
 printf("PASS %u checks, %u injected bounded capture calls. Parser, exact deadzone,\nselected-port axes/buttons, absent/early/timeouts, disabled=no I/O.\n",checks,captures);
 return 0;
}
