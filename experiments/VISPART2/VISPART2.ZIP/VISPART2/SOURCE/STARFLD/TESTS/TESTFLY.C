/* Host-only C89 tests; the model itself remains /G0 16-bit C. */
#include <assert.h>
#include <limits.h>
#include <stdio.h>
#include "STFLY.H"

static const int depth[FLY_SHOT_AGES]={
 64,56,48,41,35,30,25,21,17,14,11,8,6,4,2,1,0};
static unsigned long slices,births,retirements;
static unsigned directions;
static int maximum_active;

static int mag(int n){return n<0?-n:n;}
static int minimum(int a,int b){return a<b?a:b;}
static int maximum(int a,int b){return a>b?a:b;}
static int bound(int n,int lo,int hi){return maximum(lo,minimum(n,hi));}
static int between(int n,int a,int b){
 return n>=minimum(a,b)&&n<=maximum(a,b);
}
/* Widen only the independent host oracle, never the target model. */
static int projected(int origin,int center,int age){long n;
 assert(age>=0&&age<FLY_SHOT_AGES);
 n=(long)mag(origin-center)*depth[age];
 assert(n+32<=32767L);
 n=(n+32)/64;
 return center+(origin<center?-(int)n:(int)n);
}
static int remaining(FLY *f,FLY_SHOT *s,int age){int x,y;
 if(age>=FLY_SHOT_AGES)return 0;
 x=projected(s->originx,f->width/2,age);
 y=projected(s->originy,f->height/2,age);
 return maximum(mag(x-f->width/2),mag(y-f->height/2));
}
static int extent(FLY_SHOT *s){
 return maximum(mag(s->headx-s->tailx),mag(s->heady-s->taily));
}
static void point_inside(FLY_SHOT *s,int x,int y){
 assert(x>=s->x&&x<s->x+s->w);
 assert(y>=s->y&&y<s->y+s->h);
}
/* Exercise all pixels of both lines and the explicitly drawn endpoints. */
static void check_line(FLY_SHOT *s,int offset){
 int x,y,x1,y1,dx,dy,sx,sy,error,twice;
 x=s->tailx+offset;y=s->taily;x1=s->headx+offset;y1=s->heady;
 dx=mag(x1-x);dy=-mag(y1-y);sx=x<x1?1:-1;sy=y<y1?1:-1;
 error=dx+dy;
 for(;;){
  point_inside(s,x,y);if(x==x1&&y==y1)break;
  twice=error*2;
  if(twice>=dy){error+=dy;x+=sx;}
  if(twice<=dx){error+=dx;y+=sy;}
 }
}
static void check_shot(FLY *f,FLY_SHOT *s){
 int cx,cy,distance,length,dx,dy;long cross;
 cx=f->width/2;cy=f->height/2;
 assert(s->active==1&&s->age>=0&&s->age<FLY_SHOT_AGES-1);
 assert(s->tailx==projected(s->originx,cx,s->age));
 assert(s->taily==projected(s->originy,cy,s->age));
 assert(between(s->tailx,s->originx,cx));
 assert(between(s->taily,s->originy,cy));
 assert(between(s->headx,s->tailx,cx));
 assert(between(s->heady,s->taily,cy));
 distance=remaining(f,s,s->age);assert(distance>1);
 length=minimum((FLY_LASER_H*depth[s->age]+63)/64,distance);
 assert(extent(s)==length&&length>=1&&length<=FLY_LASER_H);
 assert(s->thick==(depth[s->age]>=32?f->scale:1));
 assert(s->thick>=1&&s->thick<=2);
 assert(s->x==minimum(s->tailx,s->headx));
 assert(s->y==minimum(s->taily,s->heady));
 assert(s->w==mag(s->headx-s->tailx)+s->thick);
 assert(s->h==mag(s->heady-s->taily)+1);
 assert(s->x>=0&&s->y>=0&&s->x+s->w<=f->width);
 assert(s->y+s->h<=f->height);
 /* Quantized endpoints stay within two pixels of the fixed origin ray. */
 dx=s->originx-cx;dy=s->originy-cy;
 cross=(long)(s->tailx-cx)*dy-(long)(s->taily-cy)*dx;
 if(cross<0)cross=-cross;
 assert(cross<=maximum(mag(dx),mag(dy)));
 cross=(long)(s->headx-cx)*dy-(long)(s->heady-cy)*dx;
 if(cross<0)cross=-cross;
 assert(cross<=2L*maximum(mag(dx),mag(dy)));
 if(dx<0)directions|=1;
 if(dx>0)directions|=2;
 if(dy<0)directions|=4;
 if(dy>0)directions|=8;
 check_line(s,0);if(s->thick==2)check_line(s,1);
 point_inside(s,s->headx+s->thick-1,s->heady);
 point_inside(s,s->tailx+s->thick-1,s->taily);
}
static void check_birth(FLY *f,FLY_SHOT *s,unsigned oldfire){
 int native_x,native_y;
 native_x=oldfire&1?30:1;
 native_y=oldfire&1?6+3*f->pose:12-3*f->pose;
 assert(s->age==0);
 assert(s->originx==f->x+(native_x*(f->w-1)+15)/31);
 assert(s->originy==f->y+native_y);
 assert(s->tailx==s->originx&&s->taily==s->originy);
 assert(s->active==(remaining(f,s,0)>1));
 births++;
}
/* Every injected slice checks the unchanged steering/autoflight and
   cooldown contracts as well as each birth, fixed ray, and retirement. */
static void step_checked(FLY *f,int joystick,int dx,int dy,int buttons){
 FLY old;int i,vx,vy,ax,ay,phase,cooldown,free_slot,new_slot,active;
 unsigned expected_fired;
 old=*f;phase=(old.phase+1)%4;ax=old.autox;ay=old.autoy;
 if(joystick){vx=bound(dx,-2,2);vy=bound(dy,-2,2);}
 else{
  if(old.x<old.width/5)ax=1;
  if(old.x>old.width*4/5-old.w)ax=-1;
  if(old.y<old.height/2)ay=1;
  if(old.y>old.height*3/4)ay=-1;
  vx=ax;vy=phase?0:ay;
 }
 cooldown=old.cooldown?old.cooldown-1:0;free_slot=-1;
 for(i=0;i<FLY_SHOTS;i++){
  if(!old.shots[i].active||
     remaining(&old,&old.shots[i],old.shots[i].age+1)<=1){
   if(free_slot<0)free_slot=i;
  }
 }
 new_slot=joystick&&buttons&&!cooldown?free_slot:-1;
 expected_fired=old.fired;
 if(new_slot>=0){expected_fired++;cooldown=3;}
 fly_step(f,joystick,dx,dy,buttons);slices++;
 assert(f->x==bound(old.x+vx*old.scale,2,old.width-old.w-2));
 assert(f->y==bound(old.y+vy,30,old.height-FLY_HEIGHT-2));
 assert(f->pose==(vx<0?0:vx>0?2:1));
 assert(f->autox==ax&&f->autoy==ay&&f->phase==phase);
 assert(f->steps==(unsigned)(old.steps+1));
 assert(f->fired==expected_fired&&f->cooldown==cooldown);
 assert(f->width==old.width&&f->height==old.height);
 assert(f->w==old.w&&f->scale==old.scale);
 active=0;
 for(i=0;i<FLY_SHOTS;i++){
  FLY_SHOT *s,*before;
  s=&f->shots[i];before=&old.shots[i];
  if(before->active&&remaining(&old,before,before->age+1)<=1)
   retirements++;
  if(i==new_slot)check_birth(f,s,old.fired);
  else if(before->active){
   assert(s->originx==before->originx&&s->originy==before->originy);
   assert(s->age==before->age+1);
   assert(s->active==(remaining(f,s,s->age)>1));
   if(s->active){
    assert(remaining(f,s,s->age)<=remaining(&old,before,before->age));
    assert(extent(s)<=extent(before)&&s->thick<=before->thick);
   }else{
    assert(s->age<=FLY_SHOT_AGES-1);
    assert(maximum(mag(s->tailx-f->width/2),
                   mag(s->taily-f->height/2))<=1);
   }
  }else assert(!s->active);
  if(s->active){check_shot(f,s);active++;}
 }
 assert(active<=FLY_SHOTS);maximum_active=maximum(maximum_active,active);
}
static void test_corners_banks(int width){
 FLY f;int xcase,ycase,pose,side,age;
 for(xcase=0;xcase<3;xcase++)for(ycase=0;ycase<3;ycase++)
 for(pose=0;pose<3;pose++)for(side=0;side<2;side++){
  fly_init(&f,width,200);
  f.x=xcase==0?2:xcase==1?(width-f.w)/2:width-f.w-2;
  f.y=ycase==0?30:ycase==1?91:200-FLY_HEIGHT-2;
  f.fired=(unsigned)side;
  step_checked(&f,1,pose-1,0,1);
  assert(f.pose==pose&&f.shots[0].active);
  assert(f.shots[0].age==0&&f.cooldown==3);
  for(age=1;age<FLY_SHOT_AGES;age++){
   /* Turn and translate after firing: neither may bend the existing ray. */
   step_checked(&f,1,age&1?-32000:32000,age&2?-32000:32000,0);
  }
  assert(!f.shots[0].active&&f.fired==(unsigned)(side+1));
 }
}
static void test_near_point(int width){
 FLY f;int pose,side,dx,dy,native_x,native_y;
 for(pose=0;pose<3;pose++)for(side=0;side<2;side++)
 for(dx=-1;dx<=1;dx++)for(dy=-1;dy<=1;dy++){
  fly_init(&f,width,200);f.fired=(unsigned)side;
  native_x=side?30:1;native_y=side?6+3*pose:12-3*pose;
  f.x=width/2+dx-(native_x*(f.w-1)+15)/31-(pose-1)*f.scale;
  f.y=100+dy-native_y;
  step_checked(&f,1,pose-1,0,1);
  assert(!f.shots[0].active&&f.cooldown==3);
  assert(f.fired==(unsigned)(side+1));
 }
}
static void test_axes(int width){
 FLY f;int axis,sign,age;
 for(axis=0;axis<2;axis++)for(sign=-1;sign<=1;sign+=2){
  fly_init(&f,width,200);
  f.x=width/2-((f.w-1)+15)/31+(axis?0:sign*30);
  f.y=100-9+(axis?sign*30:0);
  step_checked(&f,1,0,0,1);assert(f.shots[0].active);
  for(age=0;age<FLY_SHOT_AGES;age++){
   if(f.shots[0].active){
    if(axis)assert(f.shots[0].tailx==width/2&&f.shots[0].headx==width/2);
    else assert(f.shots[0].taily==100&&f.shots[0].heady==100);
   }
   step_checked(&f,1,0,0,0);
  }
  assert(!f.shots[0].active);
 }
}
static void test_held_fire(int width){
 FLY f;int i,j;unsigned previous;
 fly_init(&f,width,200);f.x=2;f.y=30;
 for(i=0;i<15;i++){
  step_checked(&f,1,0,0,3);
  assert(f.fired==(unsigned)minimum(i/3+1,4));
 }
 for(i=0;i<10000;i++){
  previous=f.fired;
  step_checked(&f,1,i%2?-32000:32000,i%2?-32000:32000,3);
  assert(f.fired-previous<=1);
 }
 assert(f.fired<=3340);previous=f.fired;
 for(i=0;i<100;i++)step_checked(&f,0,2,2,3);
 assert(f.fired==previous);
 for(j=0;j<FLY_SHOTS;j++)assert(!f.shots[j].active);
 /* Reinitialization clears all shots/cooldown even when called mid-volley. */
 for(i=0;i<12;i++)step_checked(&f,1,0,0,3);
 fly_init(&f,width,200);assert(!f.fired&&!f.steps&&!f.cooldown);
 for(j=0;j<FLY_SHOTS;j++)assert(!f.shots[j].active);
 for(i=0;i<10;i++){
  step_checked(&f,1,0,0,0);
  assert(f.pose==1&&f.x==(width-f.w)/2&&f.y==133);
 }
 /* Counters may wrap; the muzzle alternation must survive that boundary. */
 f.fired=UINT_MAX;f.steps=UINT_MAX;
 step_checked(&f,1,0,0,1);assert(!f.fired&&!f.steps);
 for(i=0;i<3;i++)step_checked(&f,1,0,0,1);
 assert(f.fired==1);
}
static void test_idle(int width){FLY f;int i;
 fly_init(&f,width,200);
 for(i=0;i<10000;i++){
  step_checked(&f,0,99,-99,3);
  assert(f.x>=2&&f.x+f.w<=width-2);
  assert(f.y>=30&&f.y+FLY_HEIGHT<=198&&!f.fired);
 }
}
static unsigned long random_value(unsigned long *seed){
 *seed=(*seed*1664525UL+1013904223UL)&0xffffffffUL;return *seed;
}
static void test_injected_sequences(int width){
 FLY f;unsigned long seed,r;int sequence,i,connected,dx,dy,buttons;
 for(sequence=0;sequence<32;sequence++){
  fly_init(&f,width,200);seed=1UL+(unsigned long)sequence*7919UL;
  for(i=0;i<2048;i++){
   r=random_value(&seed);connected=(r&7)!=0;
   dx=(int)((r>>4)%5)-2;dy=(int)((r>>9)%5)-2;
   if(r&0x100000UL)dx*=16000;
   if(r&0x200000UL)dy*=16000;
   buttons=(int)((r>>15)&3);
   step_checked(&f,connected,dx,dy,buttons);
   if((r&1023UL)==0)fly_init(&f,width,200);
  }
  for(i=0;i<FLY_SHOT_AGES;i++)step_checked(&f,0,0,0,3);
  for(i=0;i<FLY_SHOTS;i++)assert(!f.shots[i].active);
 }
}
int main(void){int width;
 for(width=160;width<=640;width*=2){
  test_corners_banks(width);test_near_point(width);test_axes(width);
  test_held_fire(width);test_idle(width);test_injected_sequences(width);
 }
 assert(directions==15&&maximum_active==FLY_SHOTS);
 assert(births>10000&&retirements>10000);
 printf("PASS: %lu checked slices, %lu births, %lu retirements; "
        "160/320/640, corners/banks/axes, alternating wing tips, fixed "
        "origins, convergence, shrinking beams, tight pixel bounds, "
        "cap/cooldown, disconnect/restart, and 96 injected sequences\n",
        slices,births,retirements);
 return 0;
}
