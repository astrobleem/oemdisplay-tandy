#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <dlfcn.h>
typedef union {uint32_t type; unsigned char raw[56];uint64_t alignment;} Event;
static void observe(const char *path){char b[8192],out[1024];FILE *f;size_t n=0;
 f=fopen(path,"rb");if(f){n=fread(b,1,sizeof(b)-1,f);fclose(f);}b[n]=0;
 snprintf(out,sizeof(out),"%s.INJECT",path);f=fopen(out,"w");if(f){fprintf(f,"HELD_DRAIN=%d NO_EARLY_END=%d\n",strstr(b,"DRAIN begin")!=NULL,strstr(b,"END reason=")==NULL);fclose(f);}}
static void *worker(void *unused){int (*push)(Event *);char buf[4096];const char *path=getenv("ARWING_INPUT_LOG"),*kind=getenv("ARWING_INPUT_KIND");FILE *f;Event e;int ready=0,n,i;
 (void)unused;if(!path)return NULL;
 for(i=0;i<600&&!ready;i++){f=fopen(path,"rb");if(f){n=fread(buf,1,sizeof(buf)-1,f);buf[n]=0;fclose(f);if(strstr(buf,"START driver="))ready=1;}if(!ready)usleep(100000);}
 if(!ready)return NULL;
 usleep(1800000);push=dlsym(RTLD_DEFAULT,"SDL_PushEvent");if(!push)return NULL;
 memset(&e,0,sizeof(e));
 if(kind&&kind[0]=='m'){e.type=0x401;e.raw[16]=1;e.raw[17]=1;*(int32_t *)(e.raw+20)=80;*(int32_t *)(e.raw+24)=80;push(&e);usleep(1800000);observe(path);e.type=0x402;e.raw[17]=0;push(&e);}
 else{e.type=0x300;e.raw[12]=1;*(int32_t *)(e.raw+16)=40;*(int32_t *)(e.raw+20)=13;push(&e);usleep(1800000);observe(path);e.type=0x301;e.raw[12]=0;push(&e);}
 return NULL;
}
__attribute__((constructor)) static void initialize(void){char p[1024];pthread_t t;int n=readlink("/proc/self/exe",p,sizeof(p)-1);if(n<0)return;p[n]=0;if(!strstr(p,"dosbox-x-sdl2"))return;pthread_create(&t,NULL,worker,NULL);pthread_detach(t);}
