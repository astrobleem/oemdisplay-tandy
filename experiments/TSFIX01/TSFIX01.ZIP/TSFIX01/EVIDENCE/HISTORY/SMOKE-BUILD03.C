#define WINVER 0x0300
#include <windows.h>
static HFILE logf;static int failures,passes,stage,busy;static HWND shell;
static void check(char*s,int ok){_lwrite(logf,ok?"PASS ":"FAIL ",5);_lwrite(logf,s,lstrlen(s));_lwrite(logf,"\r\n",2);if(ok)passes++;else failures++;_lclose(logf);logf=_lopen("C:\\SMOKE.LOG",OF_WRITE);_llseek(logf,0L,2);}
static void shot(char*name){HFILE f;unsigned char m=*((unsigned char FAR*)0x00400049L);f=_lcreat(name,0);if(f!=HFILE_ERROR){_lwrite(f,(LPSTR)0xb8000000L,(m==9||m==10)?32768U:16384U);_lclose(f);}}
LONG FAR PASCAL WndProc(HWND w,UINT m,WPARAM wp,LPARAM lp){HWND d,f;char b[100];RECT r;switch(m){case WM_CREATE:SetTimer(w,1,600,NULL);return 0;case WM_TIMER:
 if(busy)return 0;busy=1;wsprintf(b,"STAGE=%d\r\n",stage);_lwrite(logf,b,lstrlen(b));_lclose(logf);logf=_lopen("C:\\SMOKE.LOG",OF_WRITE);_llseek(logf,0L,2);
 if(stage==0)check("exact production starts",WinExec("C:\\TSHELL.EXE",SW_SHOWNORMAL)>=32);
 if(stage==1){shell=FindWindow("TandyStart",NULL);check("bar created",shell!=NULL);if(shell){GetWindowRect(shell,&r);check("bar fits width",r.left==0&&r.right==GetSystemMetrics(SM_CXSCREEN));PostMessage(shell,WM_COMMAND,42,0L);}}
 if(stage==2){d=FindWindow(NULL,"Run");check("Run opens",d!=NULL);if(d)PostMessage(d,WM_COMMAND,101,0L);}
 if(stage==3){d=FindWindow(NULL,"Browse");check("Browse opens",d!=NULL);if(d){f=GetDlgItem(d,103);check("PIF filter present",SendMessage(f,CB_GETCOUNT,0,0L)==4);SendMessage(f,CB_SETCURSEL,3,0L);SendMessage(d,WM_COMMAND,103,MAKELONG(f,CBN_SELCHANGE));check("shutdown query accepted",SendMessage(d,WM_QUERYENDSESSION,0,0L)!=0);SendMessage(d,WM_ENDSESSION,FALSE,0L);check("canceled query leaves dialog",IsWindow(d));UpdateWindow(d);shot("C:\\EXACT.RAW");PostMessage(d,WM_COMMAND,IDCANCEL,0L);}}
 if(stage==4){check("Browse cancelled",FindWindow(NULL,"Browse")==NULL);d=FindWindow(NULL,"Run");check("Run remains",d!=NULL);if(d)PostMessage(d,WM_COMMAND,IDCANCEL,0L);}
 if(stage==5){check("Run cancelled",FindWindow(NULL,"Run")==NULL);if(shell)PostMessage(shell,WM_COMMAND,42,0L);}
 if(stage==6){d=FindWindow(NULL,"Run");check("Run reopens",d!=NULL);if(d)PostMessage(d,WM_COMMAND,101,0L);}
 if(stage==7){d=FindWindow(NULL,"Browse");check("Browse reopens",d!=NULL);if(d){check("PIF filter retained",SendDlgItemMessage(d,103,CB_GETCURSEL,0,0L)==3);PostMessage(d,WM_COMMAND,IDCANCEL,0L);}}
 if(stage==8){d=FindWindow(NULL,"Run");if(d)PostMessage(d,WM_COMMAND,IDCANCEL,0L);}
 if(stage==9){if(shell)PostMessage(shell,WM_CLOSE,0,0L);}
 if(stage==10){check("secondary bar closes",!IsWindow(shell));KillTimer(w,1);wsprintf(b,"PASS_COUNT=%d\r\nFAIL_COUNT=%d\r\nCOMPLETE=1\r\n",passes,failures);_lwrite(logf,b,lstrlen(b));_lclose(logf);DestroyWindow(w);return 0;}
 stage++;busy=0;return 0;case WM_DESTROY:PostQuitMessage(0);return 0;}return DefWindowProc(w,m,wp,lp);}
int PASCAL WinMain(HINSTANCE inst,HINSTANCE prev,LPSTR cmd,int show){WNDCLASS wc;HWND w;MSG msg;logf=_lcreat("C:\\SMOKE.LOG",0);check("real mode",!(GetWinFlags()&WF_PMODE));wc.style=0;wc.lpfnWndProc=WndProc;wc.cbClsExtra=wc.cbWndExtra=0;wc.hInstance=inst;wc.hIcon=NULL;wc.hCursor=NULL;wc.hbrBackground=NULL;wc.lpszMenuName=NULL;wc.lpszClassName="ReviewSmoke";if(!RegisterClass(&wc))return 1;w=CreateWindow("ReviewSmoke","",WS_POPUP,0,0,1,1,NULL,NULL,inst,NULL);if(!w)return 1;while(GetMessage(&msg,NULL,0,0)){TranslateMessage(&msg);DispatchMessage(&msg);}return failures;}
