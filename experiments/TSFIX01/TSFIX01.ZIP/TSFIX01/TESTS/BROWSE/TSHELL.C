#define WinMain OriginalWinMain
#include "SUBJECT.C"
#undef WinMain
static HFILE qlog;static int qfail,qpass;
static void qc(char *s,int ok){_lwrite(qlog,ok?"PASS ":"FAIL ",5);_lwrite(qlog,s,lstrlen(s));_lwrite(qlog,"\r\n",2);if(ok)qpass++;else qfail++;_lclose(qlog);qlog=_lopen("C:\\QA.LOG",OF_WRITE);_llseek(qlog,0L,2);}
static void shot(char *name){HFILE f;unsigned char m=*((unsigned char FAR *)0x00400049L);unsigned char FAR *v=(unsigned char FAR *)0xb8000000L;f=_lcreat(name,0);if(f!=HFILE_ERROR){_lwrite(f,(LPSTR)v,(m==9||m==10)?32768U:16384U);_lclose(f);}}
static void finish(void){char b[80];wsprintf(b,"PASS_COUNT=%d\r\nFAIL_COUNT=%d\r\nCOMPLETE=1\r\n",qpass,qfail);_lwrite(qlog,b,lstrlen(b));_lclose(qlog);}
static HWND makewin(HINSTANCE inst,char *title,int width,int height){WNDCLASS wc;HWND w;wc.style=CS_HREDRAW|CS_VREDRAW;wc.lpfnWndProc=WndProc;wc.cbClsExtra=0;wc.cbWndExtra=0;wc.hInstance=inst;wc.hIcon=NULL;wc.hCursor=LoadCursor(NULL,IDC_ARROW);wc.hbrBackground=GetStockObject(WHITE_BRUSH);wc.lpszMenuName=NULL;wc.lpszClassName="PolishQA";qc("register class",RegisterClass(&wc)!=0);w=CreateWindow("PolishQA",title,WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_CLIPCHILDREN,0,0,width,height,NULL,NULL,inst,NULL);qc("window created",w!=NULL);if(w){ShowWindow(w,SW_SHOW);UpdateWindow(w);}return w;}



void PmReviewSetup(HINSTANCE inst);
BOOL FAR PASCAL PmDialogProc(HWND,UINT,WPARAM,LPARAM);
static int seen, phase;static char oldDir[144];
void FAR PASCAL UTRunTimer(HWND owner,UINT msg,UINT id,DWORD tick){
 HWND w,filter;char text[144];int count,i;LONG answer;
 w=FindWindow(NULL,phase==2?"Programs":"Browse");if(!w||(phase<2&&!browseValid))return;KillTimer(owner,2);seen++;
 if(phase==2){
  GetDlgItemText(w,213,text,sizeof(text));qc("cap and page coexist",text[0]=='4'&&text[1]=='0'&&text[7]=='1'&&text[8]=='/');
  SendMessage(w,WM_COMMAND,212,0L);GetDlgItemText(w,213,text,sizeof(text));qc("cap advances page",text[0]=='4'&&text[1]=='0'&&text[7]=='2'&&text[8]=='/');
  SendMessage(w,WM_COMMAND,211,0L);GetDlgItemText(w,213,text,sizeof(text));qc("cap returns page",text[0]=='4'&&text[1]=='0'&&text[7]=='1'&&text[8]=='/');
  UpdateWindow(w);shot("C:\\GROUPS.RAW");SendMessage(w,WM_COMMAND,IDCANCEL,0L);return;
 }
 qc("Browse dialog exists",GetDlgItem(w,FILELIST)!=NULL);
 filter=GetDlgItem(w,FILTER);count=(int)SendMessage(filter,CB_GETCOUNT,0,0L);
 qc("four filters",count==4);SendMessage(filter,CB_GETLBTEXT,3,(LPARAM)(LPSTR)text);qc("PIF filter",!lstrcmp(text,"*.PIF"));
 if(!phase){
  SendMessage(filter,CB_SETCURSEL,3,0L);SendMessage(w,WM_COMMAND,FILTER,MAKELONG(filter,CBN_SELCHANGE));
  qc("select PIF",browseFilter==3);
  count=(int)SendDlgItemMessage(w,NATIVELIST,LB_GETCOUNT,0,0L);i=0;
  while(i<count){SendDlgItemMessage(w,NATIVELIST,LB_GETTEXT,i,(LPARAM)(LPSTR)text);if(!lstrcmpi(text,"_DEFAULT.PIF"))break;i++;}
  qc("PIF appears in DOS listing",i<count);
  SendMessage(filter,CB_SETCURSEL,-1,0L);SendMessage(w,WM_COMMAND,FILTER,MAKELONG(filter,CBN_SELCHANGE));qc("invalid filter keeps safe mask",browseFilter==3);
  SendMessage(filter,CB_SETCURSEL,3,0L);
 }else qc("EXE filter restored on reopen",browseFilter==0&&(int)SendMessage(filter,CB_GETCURSEL,0,0L)==0);
 answer=SendMessage(w,WM_QUERYENDSESSION,0,0L);qc("Browse permits shutdown",answer!=0);
 qc("query leaves Browse alive",IsWindow(w));
 SendMessage(w,WM_ENDSESSION,FALSE,0L);qc("canceled end-session keeps Browse",IsWindow(w));
 UpdateWindow(w);shot(phase?"C:\\REOPEN.RAW":"C:\\BROWSE.RAW");
 SendMessage(w,WM_COMMAND,IDCANCEL,0L);
}
int PASCAL WinMain(HINSTANCE inst,HINSTANCE prev,LPSTR cmd,int show){HWND w;FARPROC callback;char now[144];instance=inst;qlog=_lcreat("C:\\QA.LOG",0);qc("real mode",!(GetWinFlags()&WF_PMODE));qc("Run preserves overflow sentinel",RUNMAX==126);qc("unique Program Manager mnemonic",!lstrcmp(names[0],"Program M&gr"));w=CreateWindow("STATIC","Review QA",WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU,0,0,120,60,NULL,NULL,inst,NULL);ShowWindow(w,SW_SHOW);getcwd(oldDir,sizeof(oldDir));callback=MakeProcInstance((FARPROC)UTRunTimer,inst);qc("callback",callback!=NULL);if(callback){for(phase=0;phase<2;phase++){qc("callback scheduled",SetTimer(w,2,500,(TIMERPROC)callback)!=0);qc("Browse cancellation",browse(w)==0);qc("CWD restored",getcwd(now,sizeof(now))&&!lstrcmpi(now,oldDir));}PmReviewSetup(inst);phase=2;qc("callback scheduled",SetTimer(w,2,500,(TIMERPROC)callback)!=0);smallDialog(w,"Programs",154,(FARPROC)PmDialogProc);KillTimer(w,2);FreeProcInstance(callback);}qc("all dialogs tested",seen==3);DestroyWindow(w);finish();return qfail;}
