#define WINVER 0x0300
#include <windows.h>
static HFILE qlog;static int qfail,qpass;static HINSTANCE instance;
static void qc(char*s,int ok){_lwrite(qlog,ok?"PASS ":"FAIL ",5);_lwrite(qlog,s,lstrlen(s));_lwrite(qlog,"\r\n",2);if(ok)qpass++;else qfail++;_lclose(qlog);qlog=_lopen("C:\\QA.LOG",OF_WRITE);_llseek(qlog,0L,2);}
static void finish(void){char b[80];wsprintf(b,"PASS_COUNT=%d\r\nFAIL_COUNT=%d\r\nCOMPLETE=1\r\n",qpass,qfail);_lwrite(qlog,b,lstrlen(b));_lclose(qlog);}
int TSSaverReconfigure(void){return 0;}int TSSaverPrimary(void){return 0;}void TSSaverHold(int n){}void TSSaverPreviewTick(HWND w){}void TSSaverPreviewEnd(HWND w){}
extern int qaDateApply,qaSaverApply,qaOptions,qaPreview;
void TandyDateTime(HWND,HINSTANCE);
void TSSaverSettings(HWND,HINSTANCE);
int SaverStarOptions(HWND,HINSTANCE,int*,int*);
static void mnemonic(HWND w,char c){MSG k;k.hwnd=GetFocus();k.message=WM_SYSCHAR;k.wParam=c;k.lParam=0x20000001L;k.time=GetTickCount();k.pt.x=k.pt.y=0;if(!IsDialogMessage(w,&k)){TranslateMessage(&k);DispatchMessage(&k);}}

static int phase,seen;
void FAR PASCAL UTRunTimer(HWND owner,UINT msg,UINT id,DWORD tick){HWND w,filter;char text[144];w=GetLastActivePopup(owner);if(w==owner||!w)return;KillTimer(owner,2);seen++;
 if(phase==3){
  filter=GetDlgItem(w,110);/* DATE_EDIT */
  GetClassName(filter,text,sizeof(text));
  /* IDs are read from the unchanged production header constants below. */
  filter=GetDlgItem(w,110);SetFocus(filter);
  SendMessage(w,WM_COMMAND,IDOK,0L);qc("date implicit Enter does not apply",qaDateApply==0);
  SendMessage(w,WM_COMMAND,113,MAKELONG(filter,BN_CLICKED));qc("date wrong button refused",qaDateApply==0);
  filter=GetDlgItem(w,113);EnableWindow(filter,FALSE);SendMessage(w,WM_COMMAND,113,MAKELONG(filter,BN_CLICKED));qc("date disabled Apply refused",qaDateApply==0);EnableWindow(filter,TRUE);
  SetFocus(GetDlgItem(w,110));mnemonic(w,'a');qc("date Alt+A accepted",qaDateApply==1);
  SendMessage(w,WM_COMMAND,IDCANCEL,0L);return;
 }
 if(phase==4){
  filter=GetDlgItem(w,123);SetFocus(filter);SendMessage(w,WM_COMMAND,IDOK,0L);qc("saver edit Enter inert",qaSaverApply==0&&qaPreview==0&&qaOptions==0);
  SendMessage(w,WM_COMMAND,125,MAKELONG(filter,BN_CLICKED));qc("saver wrong button refused",qaSaverApply==0);
  filter=GetDlgItem(w,119);SendMessage(w,WM_COMMAND,119,MAKELONG(filter,BN_CLICKED));
  SetFocus(GetDlgItem(w,123));mnemonic(w,'o');qc("saver Alt+O accepted",qaOptions==1);
  SetFocus(GetDlgItem(w,123));mnemonic(w,'a');qc("saver Alt+A accepted",qaSaverApply==1);
  /* ScSave fake returns unchanged config; select Starfield again. */
  filter=GetDlgItem(w,119);SendMessage(w,WM_COMMAND,119,MAKELONG(filter,BN_CLICKED));
  SetFocus(GetDlgItem(w,123));mnemonic(w,'p');qc("preview explicitly focuses button",GetFocus()==GetDlgItem(w,124));SendMessage(w,WM_USER+71,0,0L);qc("saver Alt+P accepted",qaPreview==1);
  SendMessage(w,WM_COMMAND,IDCANCEL,0L);return;
 }
 if(phase==5){
  SetFocus(GetDlgItem(w,130));SendMessage(w,WM_COMMAND,IDOK,0L);qc("options implicit Enter inert",IsWindow(w));
  mnemonic(w,'o');return;
 }
}
int PASCAL WinMain(HINSTANCE inst,HINSTANCE prev,LPSTR cmd,int show){HWND w;FARPROC callback;int speed=2,stars=32,result;instance=inst;qlog=_lcreat("C:\\QA.LOG",0);qc("real mode",!(GetWinFlags()&WF_PMODE));w=CreateWindow("STATIC","Dialog QA",WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU,0,0,120,60,NULL,NULL,inst,NULL);ShowWindow(w,SW_SHOW);callback=MakeProcInstance((FARPROC)UTRunTimer,inst);qc("callback",callback!=NULL);if(callback){phase=3;SetTimer(w,2,500,(TIMERPROC)callback);TandyDateTime(w,inst);phase=4;SetTimer(w,2,500,(TIMERPROC)callback);TSSaverSettings(w,inst);phase=5;SetTimer(w,2,500,(TIMERPROC)callback);result=SaverStarOptions(w,inst,&speed,&stars);qc("options Alt+O accepted",result==1);KillTimer(w,2);FreeProcInstance(callback);}qc("all dialogs tested",seen==3);DestroyWindow(w);finish();return qfail;}
