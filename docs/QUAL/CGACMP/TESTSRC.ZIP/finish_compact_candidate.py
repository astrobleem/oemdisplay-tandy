"""Collect only completed native results; exclude OS images and toolchains."""
from pathlib import Path
import hashlib,json,re,shutil,zipfile
from PIL import Image,ImageDraw,ImageFont,ImageChops
ROOT=Path(__file__).resolve().parent;REPO=ROOT/'integration';QUAL=REPO/'docs/QUAL/CGACMP'
PAL=[(0,0,0),(85,255,255),(255,85,255),(255,255,255)]

def pin(b):return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def write(p,s):p.write_bytes(s.replace('\r\n','\n').replace('\n','\r\n').encode('ascii'))
def row(p):return dict(path=p.relative_to(REPO).as_posix(),identity=pin(p.read_bytes()))
def copy(p,name):
 dst=QUAL/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dst);return row(dst)
def decode(b,width):
 im=Image.new('RGB',(width,200));pixels=[]
 for y in range(200):
  off=(y&1)*8192+(y//2)*80
  for x in range(width):
   pixels.append(PAL[(b[off+x//4]>>(6-2*(x%4)))&3] if width==320 else (255,255,255) if b[off+x//8]&(128>>(x%8)) else (0,0,0))
 im.putdata(pixels);return im

def main():
 dos=json.loads((ROOT/'COMPACT-DOS-SLOT-02.json').read_bytes());assert dos['status']=='PASS_NATIVE_COMPACT_INSTALLER'
 lease=json.loads((ROOT/'COMPACT-WINDOWS-LEASE-04.json').read_bytes());assert lease['status']=='PASS' and lease['inventory_after']==[] and lease['lease_released']
 for mode in ('320C','640C'):
  folder=ROOT/('recovered-compact-320C' if mode=='320C' else 'booted-compact-640C')
  r=json.loads((folder/'RESULT.json').read_bytes());assert r['status']=='PASS_NATIVE_COMPACT_WINDOWS' and r['dos_return']=='RETURNED\r\n'
 packet=REPO/'downloads/COMPACT/CGA.ZIP';packet.parent.mkdir(parents=True,exist_ok=True)
 if packet.exists():assert packet.read_bytes()==(ROOT/'compact-packet-02/CGADEV.ZIP').read_bytes()
 else:shutil.copyfile(ROOT/'compact-packet-02/CGADEV.ZIP',packet)
 q=dict(status='PENDING_INDEPENDENT_REVIEW',physical_hardware=False,runtime_source=dos['source_commit'],
        packet=row(packet),sources={},windows={},host={})
 with zipfile.ZipFile(packet) as z:q['members']={n:pin(z.read(n)) for n in z.namelist()}
 q['prepared']=copy(ROOT/'compact-prepared-05/PREPARED.JSN','PREPARED.JSN')
 q['build']=copy(ROOT/'compact-build-02/SETBUILD.JSN','BUILD.JSN')
 q['native_dos']=copy(ROOT/'COMPACT-DOS-SLOT-02.json','DOS.JSN')
 copy(ROOT/'COMPACT-DOS-SLOT-01.json','FAILED/HEAP.JSN')
 copy(ROOT/'compact-build-01/BUILD.LOG','FAILED/BUILD.LOG');copy(ROOT/'compact-build-01/SETUP.MAP','FAILED/SETUP.MAP')
 for mode,number in [('320C','01'),('640C','02')]:
  failed=ROOT/('installed-compact-'+mode)
  copy(failed/'RESULT.json','FAILED/'+mode+'-RESULT.JSN')
  copy(ROOT/('COMPACT-WINDOWS-LEASE-'+number+'.json'),'FAILED/'+mode+'-LEASE.JSN')
  for image in failed.glob('*.PNG'):copy(image,'FAILED/'+mode+'/'+image.name)
 copy(ROOT/'POST-STOP-FAT-01.json','FAILED/FAT-CHECK.JSN')
 for name in ('FOLLOWUP-PREP-FAILED01.json','FOLLOWUP-PREP-FAILED02.json','OBSERVER-REPAIR-01.json','COMPACT-WINDOWS-LEASE-03.json'):copy(ROOT/name,'FAILED/'+name)
 for name in ('BUILD.LOG','SETUP.MAP','PROCESS.JSON'):copy(ROOT/'compact-build-02'/name,'BUILD/'+name)
 for name in ('CANCEL.LOG','LEGACY.LOG','LEGACY.STA','UPGRADE.LOG','LUNDO.LOG','S32.LOG','S64.LOG','SWITCH.LOG','UNDO.LOG','NATIVE.OK','TEST.BAT'):
  copy(ROOT/'compact-native-dos-01/CROOT'/name,'DOS/'+name)
 for kind,path in [('install','compact-install-host-04/INSTALL.JSN'),('legacy','compact-upgrade-host-06/CMPINST.JSN'),('resources','compact-resource-host-03/CMPTEST.JSN')]:
  q['host'][kind]=copy(ROOT/path,'HOST/'+kind.upper()+'.JSN')
 copy(ROOT/'compact-prior-gate-01.json','HOST/PRIOR.JSN');copy(ROOT/'compact-gate-host-06/RESULT.JSN','HOST/GATE.JSN')
 lease_row=copy(ROOT/'COMPACT-WINDOWS-LEASE-04.json','WINDOWS/LEASE.JSN')
 captures={};frames=0;pixels=0;mismatches=0
 for mode,width in [('320C',320),('640C',640)]:
  out=ROOT/('recovered-compact-320C' if mode=='320C' else 'booted-compact-640C');base='WINDOWS/'+mode
  result=json.loads((out/'RESULT.json').read_bytes())
  # 86Box normalizes and rewrites its config during launch. Reconstruct the
  # exact launch bytes from the unchanged original config and require the
  # pre-launch digest recorded by the controller to match, not merely fields.
  original=ROOT/('installed-compact-'+mode)
  cfg=(original/'86box.cfg').read_text(encoding='utf-8-sig')
  cfg=re.sub(r'^hdd_01_fn\s*=.*$','hdd_01_fn = '+(original/'DISK.IMG').as_posix(),cfg,flags=re.M)
  launch=cfg.replace('\n','\r\n').encode('ascii');assert pin(launch)==result['config']
  (out/'LAUNCH.CFG').write_bytes(launch)
  q['windows'][mode]=dict(result=copy(out/'RESULT.json',base+'/RESULT.JSN'),installed=copy(out/'INSTALLED.json',base+'/INSTALLED.JSN'),lease=lease_row,config=copy(out/'LAUNCH.CFG',base+'/LAUNCH.CFG'),captures={})
  copy(original/'86box.cfg','FAILED/'+mode+'/ORIGINAL.CFG')
  for p in out.glob('*.TXT'):copy(p,base+'/'+p.name)
  for n in ('PREPARE.json','INST-SYSTEM.INI','INST-WIN.INI','INSTALL.LOG','86box.cfg'):copy(out/n,base+'/'+n)
  for scene in ('BOOT','DESKTOP','NOTEPAD','OPEN','SAVE-AS','SAVED','PAN-SETTINGS','DOS-RETURN'):
   rawpath=out/(scene+'.PNG');vram=out/(scene+'.VRM');native=decode(vram.read_bytes(),width)
   if scene!='DOS-RETURN':
    raw=Image.open(rawpath).convert('RGB');h=min(200,(raw.height-76)//2)
    a=native.crop((0,0,width,h)).resize((640,h*2),Image.Resampling.NEAREST);b=raw.crop((8,76,648,76+h*2))
    diff=ImageChops.difference(a,b);bad=sum(v!=(0,0,0) for v in diff.getdata());bbox=diff.getbbox();note='Exact visible overlap'
    if bad:
     state=(out/(scene+'.TXT')).read_text(encoding='latin1');focus=int(re.search(r'focus=(\d+)',state)[1])
     match=re.search(r'WIN h='+str(focus)+r' .*?rect=([\d,-]+) cls=Edit ',state);assert match,(mode,scene,bad,bbox)
     l,t,r,bt=map(int,match[1].split(','));scale=2 if width==320 else 1
     assert bad<=64 and l*scale<=bbox[0]<bbox[2]<=r*scale and t*2<=bbox[1]<bbox[3]<=bt*2,(mode,scene,bad,bbox)
     note='Small sample-timing difference confined to focused Edit control; likely caret. No pixels corrected.'
    frames+=1;pixels+=640*h*2;mismatches+=bad
    captures[mode+'/'+scene]=dict(raw_origin=[8,76],visible_native_rows=h,compared_pixels=640*h*2,mismatches=bad,difference_bbox=bbox,note=note)
   raw=copy(rawpath,base+'/'+scene+'.PNG');copy(vram,base+'/'+scene+'.VRM')
   if scene!='DOS-RETURN':
    p=QUAL/base/(scene+'-NATIVE.PNG');native.save(p);q['windows'][mode]['captures'][scene]=row(p)
    q['windows'][mode]['captures'][scene+'-RAW']=raw
  assert q['windows'][mode]['captures']
 write(QUAL/'CAPTURES.JSN',json.dumps(dict(method='Unchanged direct framebuffer PNG plus live 16KB CGA VRAM decoded to full native resolution. Framebuffer origin bug retained in raw images. Visible overlap compared pixel by pixel; every difference is recorded below.',frames=frames,pixels_compared=pixels,mismatch_pixels=mismatches,frames_checked=captures),indent=2)+'\n')
 # Source of the completed private harness is evidence, never consumer content.
 with zipfile.ZipFile(QUAL/'TESTSRC.ZIP','w',zipfile.ZIP_DEFLATED) as z:
  for n in ('compact_dos_slot.py','prepare_compact_native.py','prepare_compact_installed.py','run_compact_installed.py','run_compact_installed-FAILED01.py','run_compact_installed-640C.py','compact_full_slot.py','compact_640_remaining.py','compact_recovery_320.py','compact_followup_1200.py','compact_prepared_followup.py','finish_compact_candidate.py'):z.write(ROOT/n,n)
 # Review binds all changed producer/runtime sources and the separate gate.
 names=['src/cga/SETUP.C','src/cga/PACKCGA.PY','src/cga/CGASET.PY','src/cga/CMPPACK.PY','src/cga/CMPRSC.PY','src/cga/CMPINST.PY','src/cga/CMPTEST.PY','src/cga/INSTALLT.PY','src/cga/OEMSETUP.INF','tools/PAN/CGASTAGE.PY','tools/PAN/GUIDES/CGA.TXT','tools/PAN/PREPCGA.PY','tools/PAN/PUBLISH.PY','tools/PAN/COMPOSE.PY','tools/CGACMP/HISTORY.PY','tools/CGACMP/VERIFY.PY','tools/CGACMP/TEST.PY','docs/QUAL/CGACMP/TESTSRC.ZIP']
 q['sources']={n:pin((REPO/n).read_bytes()) for n in names}
 q['review']=dict(path='docs/QUAL/CGACMP/REVIEW.JSN',identity=None)
 write(QUAL/'CANDIDATE.JSN',json.dumps(q,indent=2)+'\n')
 font=ImageFont.truetype(r'C:\Windows\Fonts\arial.ttf',23);small=ImageFont.truetype(r'C:\Windows\Fonts\arial.ttf',18)
 board=Image.new('RGB',(1600,1440),(236,239,243));d=ImageDraw.Draw(board)
 d.text((24,15),'Windows 3.0: compact UI selected by the real DOS installer',font=font,fill=(20,28,40))
 d.text((24,53),'Live guest captures at 320x200 and 640x200. Views below use nearest-neighbor 4:3 presentation.',font=small,fill=(44,55,70))
 for i,(mode,width) in enumerate([('320C',320),('640C',640)]):
  x=24+i*790;d.text((x,91),mode+': 3x5 UI, 4x6 fixed text, six-row controls',font=font,fill=(20,28,40))
  for j,scene in enumerate(('NOTEPAD','PAN-SETTINGS')):
   im=Image.open(QUAL/'WINDOWS'/mode/(scene+'-NATIVE.PNG'));board.paste(im.resize((756,567),Image.Resampling.NEAREST),(x,130+j*610))
 d.text((24,1388),'Raw framebuffer/VRAM, installed-byte readback, Notepad save and normal DOS return retained. Physical hardware unqualified.',font=small,fill=(44,55,70))
 deliver=ROOT/'deliverables/Compact-Modes-Installer-Validation.png';board.save(deliver)
 write(QUAL/'RESULTS.TXT', '''COMPACT CGA CANDIDATE - PRIVATE REVIEW

The DOS installer visibly offers 320C and 640C alongside the unchanged
standard choices. It installs the real CGA100 3x5 UI, 4x6 fixed/OEM fonts
and six-row OEM controls at the selected fixed resolution.

Native checks passed:
- C6 /G0 /AS build with 4,336 bytes of data/heap headroom (4,096 required).
- Six modes, both compact menu choices, cancel without writes, actual prior
  SETUP.EXE upgrade, and exact restoration of 119 Windows files by UNDO.
- IBM XT/CGA guest: 8088 at 4.77 MHz, normal 640 KB, no XMS/EMS/UMB.
- 320C native UNDO/reinstall recovery followed by WIN /R and application tests.
- 640C completed its native install in the first bounded run; the later
  focused cold boot used that same installation without repair.
- Both profiles: all 26 installed payloads and boot font settings match;
  Program Manager, Notepad Open/Save As with exact file readback, 5-pixel
  dialog text, PAN settings, and normal Windows return to DOS passed.
- Host transaction, four legacy inventories, resource/renderer preservation
  and publication guard checks passed. All preceding helper/standard-driver/
  font bytes and all four core release assets retain their original identity.

Authentic raw framebuffer PNGs and live 16 KB CGA VRAM are retained. Full
native images decode that VRAM; enlarged views use nearest-neighbor 4:3
presentation. The emulator's raw-frame origin bug remains visible in the
originals. CAPTURES.JSN records every overlap comparison, including the small
focused-edit sample-timing difference. No captured UI pixels are corrected.

The earlier 3,312-byte heap failure, two native time-bound failures, host
preparation failures and blocked lease are retained. The heap fix reuses
sequential scratch and preserves the 18,000-byte INI limit. The host observer
repair changed no Windows files or installed payloads; see FAILED.

No OS media, compiler or emulator is included. Physical hardware, real mouse
input and ordinary Windows Setup selection for the new profiles remain
unqualified. Native DOS SETUP is the complete supported installation route.

Independent review, catalog promotion and explicit publication approval
remain pending. Nothing has been pushed, merged or published.
''')
 bundle=ROOT/'deliverables/Compact-CGA-Candidate-Review.zip'
 with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED) as z:
  z.write(packet,'CGA-CANDIDATE.ZIP');z.write(deliver,deliver.name)
  for p in QUAL.rglob('*'):
   if p.is_file():z.write(p,'EVIDENCE/'+p.relative_to(QUAL).as_posix())
 with zipfile.ZipFile(bundle) as z:assert not z.testzip()
 print(json.dumps(dict(packet=pin(packet.read_bytes()),review_bundle=pin(bundle.read_bytes()),comparison=pin(deliver.read_bytes()),native='PASS',independent_review='PENDING',publication='NOT_AUTHORIZED'),indent=2))

if __name__=='__main__':main()
