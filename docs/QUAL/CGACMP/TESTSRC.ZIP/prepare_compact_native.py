from pathlib import Path
import sys,json,hashlib,shutil,re
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'compact-native-dos-01';C=OUT/'CROOT'
sys.path.insert(0,r'C:\Users\chad\Documents\Codex\2026-10-14\task-16\deps-local')
from pyfatfs.PyFatFS import PyFatFS
SOURCE=Path(r'C:\Users\chad\Documents\Codex\2026-10-24\task-3\native\PC1512-SETUP\DISK.IMG')
def pin(b):return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def tree(p):return {f.relative_to(p).as_posix():pin(f.read_bytes()) for f in p.rglob('*') if f.is_file()}
def write(p,s):p.write_bytes(s.replace('\n','\r\n').encode())
def prepare():
 OUT.mkdir();C.mkdir();(C/'WINDOWS').mkdir()
 assert pin(SOURCE.read_bytes())['sha256']=='37d831fe15f1df18313b496e5a168a5516d81f532eb492a2f9d2b46fb99bdf35'
 with PyFatFS(str(SOURCE),offset=17408,read_only=True) as fs:
  for name in fs.walk.files('WINDOWS'):
   rel=name.lstrip('/').split('/',1)[1];dest=C/'WINDOWS'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(fs.readbytes(name))
 w=C/'WINDOWS';assert not any((w/n).exists() for n in ('CGACOPY.STA','CGASET.STA'))
 s=(w/'SYSTEM.INI').read_bytes();s,n=re.subn(rb'^display.drv=.*?\r?$',b'display.drv=CGA.DRV\r',s,count=1,flags=re.M|re.I);assert n==1;(w/'SYSTEM.INI').write_bytes(s)
 s=(w/'WIN.INI').read_bytes();s,n=re.subn(rb'^load=.*?\r?$',lambda m:b'load=C:\\UITEST.EXE\r',s,count=1,flags=re.M|re.I);assert n==1
 s=re.sub(rb'^run=.*?\r?$',b'run=\r',s,count=1,flags=re.M|re.I)
 for key in ('Wallpaper','Pattern'):s=re.sub(rb'^'+key.encode()+rb'=.*?\r?$',(key+'=(None)\r').encode(),s,count=1,flags=re.M|re.I)
 (w/'WIN.INI').write_bytes(s);(OUT/'BEFORE.json').write_text(json.dumps(tree(w),indent=2))
 shutil.copyfile(Path(r'C:\Users\chad\Documents\Codex\2026-10-27\task-3\dib-ui-probe\UITEST.EXE'),C/'UITEST.EXE')
 (C/'UITASK.TXT').write_bytes(b'0 SNAP\r\n'+b' '*4088);(C/'SPTEST.INI').write_bytes(b'[test]\r\nvseg=47104\r\n')
 (C/'ROOM.TXT').write_bytes(b'USER SELECTED COMPACT UI\r\n\r\n'+b''.join(('%02d  More room for notes and applications.\r\n'%i).encode() for i in range(1,35)))
 # Menu choices are exercised through the actual native stdin path.
 (C/'CH32.TXT').write_bytes(b'4\r\n');(C/'CH64.TXT').write_bytes(b'6\r\n');(C/'CANCEL.TXT').write_bytes(b'\r\n')
 commands=['@ECHO OFF','C:','CD \\','SETUP C:\\WINDOWS < CANCEL.TXT > CANCEL.LOG','IF ERRORLEVEL 1 GOTO FAIL']
 for tag,mode,choice in [('S32','320C','CH32.TXT'),('S64','640C','CH64.TXT')]:
  commands+=['SETUP C:\\WINDOWS < '+choice+' > '+tag+'.LOG','IF ERRORLEVEL 1 GOTO FAIL',
             'MD '+tag,'MD '+tag+'\\SYSTEM','COPY C:\\WINDOWS\\*.* C:\\'+tag+' > NUL',
             'COPY C:\\WINDOWS\\SYSTEM\\*.* C:\\'+tag+'\\SYSTEM > NUL']
 for mode in ('320','320C','640','640C','100','PAN','320'):
  commands+=['SETUP C:\\WINDOWS '+mode+' >> SWITCH.LOG','IF ERRORLEVEL 1 GOTO FAIL']
 commands+=['SETUP UNDO C:\\WINDOWS > UNDO.LOG','IF ERRORLEVEL 1 GOTO FAIL','ECHO PASS > NATIVE.OK','GOTO DONE',':FAIL','ECHO FAIL > NATIVE.ERR',':DONE','EXIT']
 write(C/'TEST.BAT','\n'.join(commands)+'\n')
 config='''[sdl]
fullscreen=false
output=surface
[dosbox]
machine=cga
memsize=1
[cpu]
core=normal
cputype=8086_prefetch
cycles=fixed 200000
fpu=false
[dos]
xms=false
ems=false
umb=false
[mixer]
nosound=true
[autoexec]
@ECHO OFF
mount C "%s"
C:
TEST.BAT
'''%C
 write(OUT/'RUN.CNF',config)
 (OUT/'PREPARE.json').write_text(json.dumps(dict(source=str(SOURCE),source_image=pin(SOURCE.read_bytes()),baseline_windows_files=len(tree(w)),instrumentation='Observer load token and stock CGA baseline; all feature fonts/drivers/helpers must be installed by actual native SETUP',native='NOT_RUN'),indent=2));print('Native DOS matrix and real Windows baseline prepared; no emulator launched.')
if __name__=='__main__':prepare()
