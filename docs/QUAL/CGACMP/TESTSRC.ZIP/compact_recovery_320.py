"""Later coordinated slot: native UNDO/reinstall on the existing failed image.

No new OS image is made. The first failure receipts/captures stay intact.
Run only after the queued HPDIB boot followup and its verified handback.
"""
from pathlib import Path
import hashlib,json,re,shutil,sys
import run_compact_installed as r

def prepare():
 old=r.ROOT/'installed-compact-320C';out=r.ROOT/'recovered-compact-320C';image=old/'DISK.IMG'
 first=json.loads((old/'RESULT.json').read_bytes());assert first['status']=='FAILED' and first['owned_stopped']
 lease=json.loads((r.ROOT/'COMPACT-WINDOWS-LEASE-01.json').read_bytes());assert lease['lease_released'] and lease['inventory_after']==[]
 if out.exists():assert {p.name for p in out.iterdir()}<={'INTERRUPTED-INVENTORY.json','86box.cfg','PREPARE.json'},'Existing native output refused'
 else:out.mkdir()
 prep=json.loads((old/'PREPARE.json').read_bytes())
 with r.PyFatFS(str(image),offset=17408) as fs:
  assert fs.exists('WINDOWS/CGACOPY.STA') and not fs.exists('UISTATE.TXT') and not fs.exists('RETURN1.TXT')
  inventory={}
  for name,row in prep['payload'].items():
   if row['installed']:
    path=('WINDOWS/' if row['destination']=='WINDOWS' else 'WINDOWS/SYSTEM/')+row['installed']
    if fs.exists(path):inventory[path]=r.pin(fs.readbytes(path))
  (out/'INTERRUPTED-INVENTORY.json').write_text(json.dumps(dict(files=inventory,journal=r.pin(fs.readbytes('WINDOWS/CGACOPY.STA')),original_failure=r.pin((old/'RESULT.json').read_bytes())),indent=2)+'\n',encoding='ascii')
  auto='@ECHO OFF\nPATH C:\\;C:\\WINDOWS;C:\\DOS\nC:\nCD \\\nSETUP UNDO C:\\WINDOWS > C:\\RECOVER.LOG\nIF ERRORLEVEL 1 GOTO FAIL\nECHO RECOVERED>C:\\RECOVER.OK\nSETUP C:\\WINDOWS < C:\\CHOICE.TXT > C:\\INSTALL.LOG\nIF ERRORLEVEL 1 GOTO FAIL\nECHO INSTALLED>C:\\INSTALL.OK\nCD \\WINDOWS\nWIN /R\nECHO RETURNED>C:\\RETURN1.TXT\nGOTO END\n:FAIL\nECHO FAILED>C:\\RETURN1.TXT\n:END\n'
  fs.writebytes('AUTOEXEC.BAT',auto.replace('\n','\r\n').encode('ascii'))
 cfg=(old/'86box.cfg').read_text(encoding='utf-8-sig');cfg=re.sub(r'^hdd_01_fn\s*=.*$','hdd_01_fn = '+image.as_posix(),cfg,flags=re.M)
 (out/'86box.cfg').write_bytes(cfg.replace('\n','\r\n').encode('ascii'))
 prep.update(route='Native UNDO of interrupted copy, native menu reinstall, normal Win/R; reused private image',reused_image=str(image),image_before=r.pin(image.read_bytes()))
 (out/'PREPARE.json').write_text(json.dumps(prep,indent=2)+'\n',encoding='ascii')
 return out,image

if __name__=='__main__':
 assert '--coordinated' in sys.argv,'Explicit peer-coordinated slot required'
 out,image=prepare();runner=r.Lease(r.ROOT/'COMPACT-WINDOWS-LEASE-03.json',r.LOCK)
 assert not runner.record.exists()
 with runner.lease():
  result=r.run_case('320C',320,runner,900,out,image)
  assert result['status']=='PASS_NATIVE_COMPACT_WINDOWS',result.get('error')
  with r.PyFatFS(str(image),offset=17408,read_only=True) as fs:
   assert fs.readbytes('RECOVER.OK')==b'RECOVERED\r\n'
   (out/'RECOVER.LOG').write_bytes(fs.readbytes('RECOVER.LOG'))
