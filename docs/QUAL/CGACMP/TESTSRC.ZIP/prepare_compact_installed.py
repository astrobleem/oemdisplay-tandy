"""Boot fixtures that run native compact SETUP on the actual IBM XT guest.

No feature INI selection or font/driver installation occurs on the host.
"""
from pathlib import Path
import hashlib,json,shutil,sys
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,r'C:\Users\chad\Documents\Codex\2026-10-14\task-16\deps-local')
from pyfatfs.PyFatFS import PyFatFS
SOURCE=Path(r'C:\Users\chad\Documents\Codex\2026-10-24\task-3\native\PC1512-SETUP\DISK.IMG')

def pin(b):return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def put(fs,name,b):
 if fs.exists(name):fs.remove(name)
 fs.writebytes(name,b)
def prepare():
 result=json.loads((ROOT/'COMPACT-DOS-SLOT-02.json').read_bytes())
 assert result['status']=='PASS_NATIVE_COMPACT_INSTALLER'
 assert pin(SOURCE.read_bytes())['sha256']=='37d831fe15f1df18313b496e5a168a5516d81f532eb492a2f9d2b46fb99bdf35'
 prep=json.loads((ROOT/'compact-prepared-05/PREPARED.JSN').read_bytes())
 exe=(ROOT/'compact-build-02/SETUP.EXE').read_bytes()
 for mode,width,tag in [('320C',320,'S32'),('640C',640,'S64')]:
  out=ROOT/('installed-compact-'+mode);out.mkdir(exist_ok=False)
  snapshot=ROOT/'compact-native-dos-01/CROOT/WINDOWS'
  shutil.copyfile(SOURCE,out/'DISK.IMG')
  shutil.copyfile(ROOT/'fixtures/640-compact/86box.cfg',out/'86box.cfg')
  with PyFatFS(str(out/'DISK.IMG'),offset=17408) as fs:
   for p in snapshot.rglob('*'):
    if p.is_file():put(fs,'WINDOWS/'+p.relative_to(snapshot).as_posix(),p.read_bytes())
   for name in ('UITEST.EXE','UITASK.TXT','SPTEST.INI','ROOM.TXT'):
    put(fs,name,(ROOT/'compact-native-dos-01/CROOT'/name).read_bytes())
   fs.makedirs('CGA',recreate=True)
   for p in (ROOT/'compact-packet-02/expanded/CGA').iterdir():put(fs,'CGA/'+p.name,p.read_bytes())
   put(fs,'SETUP.EXE',exe)
   put(fs,'CHOICE.TXT',b'4\r\n' if mode=='320C' else b'6\r\n')
   auto='@ECHO OFF\nPATH C:\\;C:\\WINDOWS;C:\\DOS\nC:\nCD \\\nSETUP C:\\WINDOWS < C:\\CHOICE.TXT > C:\\INSTALL.LOG\nIF ERRORLEVEL 1 GOTO FAIL\nECHO INSTALLED>C:\\INSTALL.OK\nCD \\WINDOWS\nWIN /R\nECHO RETURNED>C:\\RETURN1.TXT\nGOTO END\n:FAIL\nECHO FAILED>C:\\RETURN1.TXT\n:END\n'
   put(fs,'AUTOEXEC.BAT',auto.replace('\n','\r\n').encode('ascii'))
   assert not fs.exists('RETURN1.TXT') and not fs.exists('INSTALL.OK')
   for name in ('SYSTEM.INI','WIN.INI'):
    b=fs.readbytes('WINDOWS/'+name);assert b==(snapshot/name).read_bytes();(out/name).write_bytes(b)
  (out/'PREPARE.json').write_text(json.dumps(dict(profile=mode,width=width,source=pin(SOURCE.read_bytes()),image_before=pin((out/'DISK.IMG').read_bytes()),installer=pin(exe),payload=prep['payload'],native='NOT_RUN',route='Actual DOS SETUP menu input, followed by WIN /R in IBM XT/CGA guest'),indent=2)+'\n',encoding='ascii')
 print('Two private boot images prepared for actual native DOS menu install and Windows startup.',flush=True)

if __name__=='__main__':prepare()
