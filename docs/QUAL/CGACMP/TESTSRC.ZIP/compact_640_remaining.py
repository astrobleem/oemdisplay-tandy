"""Independent 640 test within the remainder of the agreed 900-second slot."""
import datetime,json,time
from pathlib import Path
import run_compact_installed as r
start=datetime.datetime.fromisoformat(json.loads((r.ROOT/'COMPACT-DOS-SLOT-02.json').read_bytes())['started']).timestamp()
bound=min(560,int(start+900-time.time())-12)
assert bound>=400,'Insufficient remaining coordinated slot; no launch'
runner=r.Lease(r.ROOT/'COMPACT-WINDOWS-LEASE-02.json',r.LOCK)
assert not runner.record.exists()
with runner.lease():
 result=r.run_case('640C',640,runner,bound)
 assert result['status']=='PASS_NATIVE_COMPACT_WINDOWS',result.get('error')
