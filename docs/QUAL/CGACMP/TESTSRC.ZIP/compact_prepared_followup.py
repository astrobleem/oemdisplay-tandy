"""Coordinated run of prepared existing images; no further host disk edits."""
import sys,time
from pathlib import Path
import run_compact_installed as r

if __name__=='__main__':
 assert '--coordinated' in sys.argv,'Verified peer handback required'
 deadline=time.monotonic()+1200
 cases=[('320C',320,r.ROOT/'recovered-compact-320C',r.ROOT/'installed-compact-320C/DISK.IMG','RETURN1.TXT','CMPNOTE.TXT'),
        ('640C',640,r.ROOT/'booted-compact-640C',r.ROOT/'installed-compact-640C/DISK.IMG','RETURN2.TXT','CMPNOTE2.TXT')]
 for mode,width,out,image,ret,save in cases:
  assert (out/'PREPARE.json').exists() and (out/'86box.cfg').exists() and not (out/'RESULT.json').exists()
 runner=r.Lease(r.ROOT/'COMPACT-WINDOWS-LEASE-04.json',r.LOCK);assert not runner.record.exists()
 with runner.lease():
  for mode,width,out,image,ret,save in cases:
   bound=min(900 if mode=='320C' else 400,int(deadline-time.monotonic())-5)
   assert bound>=200,'Insufficient remaining coordinated slot; no new child'
   result=r.run_case(mode,width,runner,bound,out,image,ret,save)
   assert result['status']=='PASS_NATIVE_COMPACT_WINDOWS',result.get('error')
   if mode=='320C':
    with r.PyFatFS(str(image),offset=17408,read_only=True) as fs:
     assert fs.readbytes('RECOVER.OK')==b'RECOVERED\r\n'
     (out/'RECOVER.LOG').write_bytes(fs.readbytes('RECOVER.LOG'))
