"""One coordinated <=5 minute compact compiler and native DOS slot.

Uses existing private fixture; each child gets its own byte lease and watchdog.
Never stops any process except the children owned by the existing RUNDOS helper.
"""
from pathlib import Path
import datetime,hashlib,importlib.machinery,json,socket,subprocess,sys,time,shutil,zipfile

ROOT=Path(__file__).resolve().parent
REPO=ROOT/'integration'
PREP=ROOT/'compact-prepared-05'
BUILD=ROOT/'compact-build-02'
PACKET=ROOT/'compact-packet-02'
TEST=ROOT/'compact-native-dos-01'
LOCK=Path(r'C:\Users\chad\Documents\Codex\2026-10-06\tandy-emulator.lock')
DOS=Path(r'C:\DOSBox-X\dosbox-x.exe')
TOOL=Path(r'C:\Users\chad\Documents\Codex\2026-10-25\task-4\cga-source-e30579b')

def pin(b):return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def tree(p):return {f.relative_to(p).as_posix():pin(f.read_bytes()) for f in p.rglob('*') if f.is_file()}
def inventory():
    q=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-Command',
        "@(Get-CimInstance Win32_Process -ErrorAction Stop | Where-Object { $_.Name -match '^(86Box|dosbox.*|pcem|tandybox|FIXBOX|TRACEIO|Mesen2?)\\.exe$' } | Select-Object ProcessId,Name,CommandLine) | ConvertTo-Json -Compress"],capture_output=True,text=True,timeout=15)
    if q.returncode:raise RuntimeError('Unavailable process inventory: '+q.stderr)
    return json.loads(q.stdout) if q.stdout.strip() else []
def clear():
    assert not inventory(),'Existing emulator; no launch'
    for port in (12345,12346):
        with socket.socket() as s:assert s.connect_ex(('127.0.0.1',port))!=0,'Headless port occupied'
def command(*args):
    subprocess.run([sys.executable,*map(str,args)],cwd=REPO,check=True,timeout=160)

def main():
    receipt=ROOT/'COMPACT-DOS-SLOT-02.json'
    assert not receipt.exists(),'Never overwrite a prior native run'
    result=dict(status='FAILED',started=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                bound_seconds=300,source_commit='a88f81e94bc6cd9cd957397733abebbea1549fe9',
                physical_hardware='UNQUALIFIED')
    start=time.monotonic()
    try:
        clear();result['inventory_before']=[]
        command(REPO/'src/cga/BUILDSET.PY','--prepared',PREP,'--repo',REPO,'--toolchain',TOOL,
                '--dosbox',DOS,'--lease',LOCK,'--out',BUILD)
        result['compiler_process']=json.loads((BUILD/'PROCESS.JSON').read_bytes())
        command(REPO/'src/cga/PACKCGA.PY','finish','--prepared',PREP,'--build',BUILD,'--out',PACKET)
        for p in (PACKET/'expanded').rglob('*'):
            if p.is_file():
                dst=TEST/'CROOT'/p.relative_to(PACKET/'expanded')
                dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dst)
        with zipfile.ZipFile(REPO/'docs/QUAL/CGACMP/BASE.ZIP') as z:
            legacy=TEST/'CROOT/LEGACY';legacy.mkdir(exist_ok=False);z.extractall(legacy)
        clear()
        runner=importlib.machinery.SourceFileLoader('compact_native_dos_runner',str(REPO/'tools/SOUNDOWN/RUNDOS.PY')).load_module()
        runner.run(DOS,TEST/'RUN.CNF',LOCK,120)
        result['installer_process']=json.loads((TEST/'PROCESS.JSON').read_bytes())
        c=TEST/'CROOT'
        assert (c/'NATIVE.OK').read_bytes()==b'PASS\r\n' and not (c/'NATIVE.ERR').exists(),'Native transaction matrix failed'
        before=json.loads((TEST/'BEFORE.json').read_bytes());after=tree(c/'WINDOWS')
        assert before==after,'Native UNDO did not restore exact initial Windows tree'
        result['undo_exact_files']=len(before)
        legacy=(c/'LEGACY.STA').read_bytes();assert legacy.startswith(b'CGA COPY 1 936532cea1ea6b8bdef55bdeddfff70a1283de0b5f9b51c676db809eec0143ed\r\n'),legacy
        result['legacy_upgrade']=dict(packet=pin((REPO/'docs/QUAL/CGACMP/BASE.ZIP').read_bytes()),journal=pin(legacy),native='Actual preceding SETUP.EXE installs 320, new SETUP upgrades to320C, exact final UNDO')
        profiles={}
        for mode,tag,name in [('320C','S32','CGA32C.DRV'),('640C','S64','CGA64C.DRV')]:
            w=c/tag;s=(w/'SYSTEM.INI').read_text();ini=(w/'WIN.INI').read_text()
            assert ('display.drv='+name).lower() in s.lower()
            for font in ('CG1SYS.FON','CG1FIX.FON','CG1OEM.FON'):
                assert font.lower() in (s+ini).lower(),'Native compact font missing: '+font
            assert 'CGACTL.EXE'.lower() in ini.lower()
            assert pin((w/'SYSTEM'/name).read_bytes())==pin((PACKET/'expanded/CGA'/name).read_bytes())
            profiles[mode]=dict(driver=pin((w/'SYSTEM'/name).read_bytes()),system_ini=pin((w/'SYSTEM.INI').read_bytes()),win_ini=pin((w/'WIN.INI').read_bytes()))
        result.update(status='PASS_NATIVE_COMPACT_INSTALLER',profiles=profiles,
                      selected_through_menu=['320C','640C'],switches=['320','320C','640','640C','100','PAN','320'],
                      menu_cancel='PASS',windows='NOT_TESTED_NEW_INSTALLER')
    except BaseException as e:
        result['error']=repr(e)
    finally:
        result['seconds']=round(time.monotonic()-start,3)
        for key,path in [('compiler_process',BUILD/'PROCESS.JSON'),('installer_process',TEST/'PROCESS.JSON')]:
            if path.exists():result[key]=json.loads(path.read_bytes())
        try:result['inventory_after']=inventory()
        except BaseException as e:result['inventory_error']=repr(e)
        if result.get('inventory_after') or 'inventory_error' in result:result['status']='FAILED'
        result['owned_stopped']=all(x.get('owned_child_stopped') for x in [result[k] for k in ('compiler_process','installer_process') if k in result])
        result['lease_released']=all(x.get('lease_released') for x in [result[k] for k in ('compiler_process','installer_process') if k in result])
        receipt.write_text(json.dumps(result,indent=2)+'\n',encoding='ascii')
        print(json.dumps(result,indent=2),flush=True)
    return 0 if result['status']=='PASS_NATIVE_COMPACT_INSTALLER' else 1

if __name__=='__main__':sys.exit(main())
