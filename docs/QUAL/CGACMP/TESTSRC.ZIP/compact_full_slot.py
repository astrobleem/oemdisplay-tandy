"""Previously coordinated compact slot, at most 900 seconds including children."""
import time
import compact_dos_slot,prepare_compact_installed,run_compact_installed
start=time.monotonic()
if compact_dos_slot.main():raise SystemExit(1)
prepare_compact_installed.prepare()
raise SystemExit(run_compact_installed.main(start+900))
