"""Actual compact Windows smoke tests, bounded and leased, no publication."""
from pathlib import Path
import base64,hashlib,importlib.machinery,json,os,re,socket,subprocess,sys,threading,time
ROOT=Path(__file__).resolve().parent
sys.path[:0]=[r'C:\Users\chad\Documents\Codex\2026-10-14\task-16\deps-local',r'E:\DOSMCP\mcp-server']
from pyfatfs.PyFatFS import PyFatFS
from src.gdbclient import GdbClient
from src.headless_input import HeadlessCtl,type_string,alt_tap
Lease=importlib.machinery.SourceFileLoader('compact_installed_lease',str(ROOT/'integration/src/softpan/WINRUN.PY')).load_module().Runner
EXE=Path(r'C:\Users\chad\Documents\Codex\2026-10-16\task-10\EMU-STOS1\fixed\86Box.exe')
LOCK=Path(r'C:\Users\chad\Documents\Codex\2026-10-06\tandy-emulator.lock')
TEXT='COMPACT UI SAVED FROM NOTEPAD'

def pin(b):return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def windows(s):
 rows=[]
 for line in s.splitlines():
  m=re.match(r'WIN h=(\d+) parent=(\d+) id=(-?\d+) vis=(\d+) enabled=(\d+) rect=([\d,-]+) cls=(\S+) text=(.*)',line)
  if m:rows.append(dict(handle=int(m[1]),parent=int(m[2]),id=int(m[3]),visible=int(m[4]),enabled=int(m[5]),rect=list(map(int,m[6].split(','))),cls=m[7],text=m[8]))
 return rows
def find(s,cls=None,text=None,parent=None,id=None):
 for w in windows(s):
  if (cls is None or w['cls']==cls) and (text is None or text.lower() in w['text'].lower()) and (parent is None or w['parent']==parent) and (id is None or w['id']==id):return w['handle']
 return 0
def menu(s,handle,text):
 active=False
 for line in s.splitlines():
  if line.startswith('WIN h='+str(handle)+' '):active=True;continue
  if active and line.startswith('WIN ') and 'parent=0 ' in line:break
  if active:
   m=re.match(r'MENU depth=\d+ pos=\d+ id=(\d+) text=(.*)',line)
   if m and m[2].replace('&','').lower().startswith(text.lower()):return int(m[1])
 raise ValueError('Missing actual application menu: '+text)

def run_case(mode,width,runner,bound):
 out=ROOT/('installed-compact-'+mode);image=out/'DISK.IMG';p=g=ctl=watch=None;seq=0;child=None
 result=dict(status='FAILED',profile=mode,width=width,height=200,bound_seconds=bound,
             physical_hardware=False,
             input='Native keyboard plus documented private Win16 observer commands; no physical mouse qualification')
 start=time.monotonic()
 with PyFatFS(str(image),offset=17408,read_only=True) as fs:
  entry=fs.fs.root_dir.get_entry('UITASK.TXT');clusters=list(fs.fs.get_cluster_chain(entry.get_cluster()));unit=fs.fs.bytes_per_cluster
  offsets=[17408+fs.fs.get_data_cluster_address(c) for c in clusters]
 def state():
  try:
   with PyFatFS(str(image),offset=17408,read_only=True) as fs:
    if fs.exists('UISTATE.TXT'):
     s=fs.readbytes('UISTATE.TXT').decode('latin1')
     if s.startswith('STATE ') and s.endswith('UI_COMPLETE\r\n'):return s
  except (OSError,ValueError):pass
  return ''
 def tick(seconds=1):
  assert p.poll() is None,'Owned emulator stopped'
  assert time.monotonic()-start<bound-3,'Case deadline'
  g.run_while(lambda:None,settle_seconds=seconds,start_delay=.001)
 def wait(predicate,timeout=70):
  end=time.monotonic()+timeout
  while time.monotonic()<end:
   s=state()
   if predicate(s):return s
   tick(1)
  raise TimeoutError('UI state timeout: '+state()[:1600])
 def send(action,label,timeout=70):
  nonlocal seq
  seq+=1;b=(str(seq)+' '+action+'\r\n').encode('ascii');assert len(b)<4096;b+=b' '*(4096-len(b))
  with image.open('r+b',buffering=0) as f:
   for i,offset in enumerate(offsets):
    part=b[i*unit:(i+1)*unit]
    if part:f.seek(offset);f.write(part)
  if action=='EXIT':return ''
  s=wait(lambda s:s.startswith('STATE seq='+str(seq)+' '),timeout)
  (out/(label+'.TXT')).write_text(s,encoding='latin1');print(mode,label,s.splitlines()[0],flush=True);return s
 def capture(label):
  tick(.3);(out/(label+'.PNG')).write_bytes(base64.b64decode(ctl.capture_frame_png_b64()))
  (out/(label+'.VRM')).write_bytes(g.read_memory(0xb8000,16384))
 def keys(s):g.run_while(lambda:type_string(ctl,s),settle_seconds=.6,start_delay=.01)
 def keyalt(s):g.run_while(lambda:alt_tap(ctl,s),settle_seconds=.6,start_delay=.01)
 def dialog(s,label):
  h=find(s,cls='#32770',text=label);assert h,s[:1000];return h
 try:
  for port in (12345,12346):
   with socket.socket() as sock:assert sock.connect_ex(('127.0.0.1',port))!=0,'Headless port occupied'
  si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0
  with (out/'HOST.LOG').open('wb') as log:
   p=subprocess.Popen([str(EXE),'-P',str(out),'-R',r'E:\x86box\roms','-N'],cwd=out,
       env=dict(os.environ,QT_QPA_PLATFORM='offscreen'),stdout=log,stderr=subprocess.STDOUT,
       startupinfo=si,creationflags=subprocess.CREATE_NO_WINDOW)
   child=dict(pid=p.pid,bound_seconds=bound,profile=mode);runner.state['children'].append(child);runner.save();result['owned_pid']=p.pid
   watch=threading.Timer(bound,lambda:p.kill() if p.poll() is None else None);watch.daemon=True;watch.start()
   for _ in range(40):
    try:g=GdbClient(timeout=3);g.connect();ctl=HeadlessCtl('127.0.0.1',12346);break
    except OSError:
     if g:g.close();g=None
     time.sleep(.25)
   assert g and ctl
   while not state():
    tick(2);raw=g.read_memory(0xb8000,4000)[::2]
    if b'RESUME' in raw and b'F1' in raw:keys('{F1}');result['rom_f1']=True
    if time.monotonic()-start>min(540,bound-90):raise TimeoutError('Native setup/Windows boot: '+raw.decode('cp437'))
   with PyFatFS(str(image),offset=17408,read_only=True) as fs:
    assert fs.readbytes('INSTALL.OK')==b'INSTALLED\r\n','Native menu SETUP did not succeed'
    (out/'INSTALL.LOG').write_bytes(fs.readbytes('INSTALL.LOG'))
    prep=json.loads((out/'PREPARE.json').read_bytes());observed={}
    for name,row in prep['payload'].items():
     if row['installed']:
      path=('WINDOWS/' if row['destination']=='WINDOWS' else 'WINDOWS/SYSTEM/')+row['installed']
      actual=fs.readbytes(path);assert pin(actual)=={k:row[k] for k in ('bytes','sha256')},path
      observed[path]=pin(actual)
    for name in ('SYSTEM.INI','WIN.INI'):(out/('INST-'+name)).write_bytes(fs.readbytes('WINDOWS/'+name))
   installed=dict(profile=mode,files=observed,installer=prep['installer'],route='Native DOS menu SETUP installed exact payload on IBM XT before normal WIN /R')
   (out/'INSTALLED.json').write_text(json.dumps(installed,indent=2)+'\n',encoding='ascii')
   result['installed_receipt']=pin((out/'INSTALLED.json').read_bytes())
   s=send('SNAP','BOOT');assert ('width=%d height=200 '%width) in s.splitlines()[0]
   assert 'CGACTL.EXE' in s.splitlines()[0] and not find(s,cls='CGASlide') and 'helper=0 ' in s.splitlines()[0]
   capture('BOOT');result['boot']=s.splitlines()[0]
   s=send(r'RUN C:\WINDOWS\NOTEPAD.EXE C:\ROOM.TXT','NOTEPAD-LAUNCH');note=find(s,text='Notepad',parent=0);assert note,s[:1200]
   keyalt(' ');keys('x');s=send('SNAP','NOTEPAD');capture('NOTEPAD')
   result['notepad_edit']=next(w for w in windows(s) if w['parent']==note and w['cls']=='Edit')
   s=send('MENU %d %d'%(note,menu(s,note,'Open')),'OPEN');dlg=dialog(s,'Open');capture('OPEN')
   heights=[int(m[1]) for m in re.finditer(r'TEXTMETRIC h=\d+ height=(\d+)',s)];assert heights and set(heights)=={5},heights
   result['dialog_text_height']=5
   edit=find(s,cls='Edit',parent=dlg);ok=find(s,cls='Button',parent=dlg,id=1);assert edit and ok
   send('TEXT %d C:\ROOM.TXT'%edit,'OPEN-NAME');s=send('CLICK '+str(ok),'OPENED')
   assert not find(s,cls='#32770',text='Open')
   note=find(s,text='Notepad',parent=0);edit=find(s,cls='Edit',parent=note);assert note and edit
   s=send('TEXT %d %s'%(edit,TEXT),'EDITED');assert TEXT in s
   s=send('MENU %d %d'%(note,menu(s,note,'Save As')),'SAVE-AS');dlg=dialog(s,'Save');capture('SAVE-AS')
   edit=find(s,cls='Edit',parent=dlg);ok=find(s,cls='Button',parent=dlg,id=1);assert edit and ok
   send('TEXT %d C:\CMPNOTE.TXT'%edit,'SAVE-NAME');s=send('CLICK '+str(ok),'SAVED')
   assert not find(s,cls='#32770',text='Save')
   with PyFatFS(str(image),offset=17408,read_only=True) as fs:
    saved=fs.readbytes('CMPNOTE.TXT');assert saved==TEXT.encode('ascii'),saved
   result['saved_text']=saved.decode('ascii');capture('SAVED')
   send('CLOSE '+str(note),'NOTEPAD-CLOSED')
   send(r'RUN C:\WINDOWS\PAN.EXE /SETTINGS','PAN-LAUNCH',90)
   wait(lambda s:bool(find(s,text='Panning settings')),90)
   s=send('SNAP','PAN-SETTINGS');pan=find(s,text='Panning settings');assert pan
   cancel=find(s,cls='Button',parent=pan,id=2);assert cancel,s[:1000]
   capture('PAN-SETTINGS');result['pan_settings']='Opened installed public PAN /SETTINGS; screenshot and control tree retained'
   send('CLICK '+str(cancel),'PAN-CANCELLED')
   # Exit uses the normal Windows shutdown path; the optional owner gets its normal end-session messages.
   send('EXIT','EXIT')
   end=time.monotonic()+70
   while time.monotonic()<end:
    tick(1)
    with PyFatFS(str(image),offset=17408,read_only=True) as fs:
     if fs.exists('RETURN1.TXT'):
      b=fs.readbytes('RETURN1.TXT');assert b==b'RETURNED\r\n';result['dos_return']=b.decode('ascii');break
   else:raise TimeoutError('No normal DOS return')
   capture('DOS-RETURN');result['status']='PASS_NATIVE_COMPACT_WINDOWS'
 except BaseException as e:
  result['error']=repr(e)
  if g and ctl:
   try:capture('FAILURE')
   except BaseException:pass
 finally:
  if watch:watch.cancel()
  if ctl:ctl.close()
  if g:g.close()
  if p and p.poll() is None:p.kill();p.wait(timeout=10)
  result['owned_stopped']=p is None or p.poll() is not None
  if child:child['stopped']=result['owned_stopped'];runner.save()
  result['seconds']=round(time.monotonic()-start,3)
  (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n',encoding='ascii');print(json.dumps(result),flush=True)
 return result

def main(deadline=None):
 runner=Lease(ROOT/'COMPACT-WINDOWS-LEASE-01.json',LOCK)
 assert not runner.record.exists(),'Never overwrite a prior lease receipt'
 deadline=deadline or time.monotonic()+810
 with runner.lease():
  for mode,width in [('320C',320),('640C',640)]:
   bound=min(400,int(deadline-time.monotonic())-3)
   assert bound>=120,'Insufficient remaining coordinated slot; no new child'
   result=run_case(mode,width,runner,bound)
   assert result['status']=='PASS_NATIVE_COMPACT_WINDOWS',result.get('error')
 return 0
if __name__=='__main__':sys.exit(main())
