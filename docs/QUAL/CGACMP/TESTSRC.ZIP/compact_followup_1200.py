"""Later coordinated followup; reuse two images, preserve original failures."""
from pathlib import Path
import json,re,sys,time
import run_compact_installed as r
import compact_recovery_320 as recovery

def observer_write(fs,name,data):
 # Avoid this helper version's truncate-to-zero bug on multicluster files.
 entry=fs.fs.root_dir.get_entry(name)
 with fs.openbin(name,'r+') as f:f.seek(0);f.write(data)
 entry.filesize=len(data);fs.fs.update_directory_entry(entry.get_parent_dir())

def prepare640():
 old=r.ROOT/'installed-compact-640C';out=r.ROOT/'booted-compact-640C';image=old/'DISK.IMG';out.mkdir(exist_ok=True);assert not (out/'RESULT.json').exists()
 assert json.loads((old/'RESULT.json').read_bytes())['owned_stopped']
 prep=json.loads((old/'PREPARE.json').read_bytes())
 with r.PyFatFS(str(image),offset=17408) as fs:
  assert fs.readbytes('INSTALL.OK')==b'INSTALLED\r\n' and not fs.exists('RETURN2.TXT')
  if fs.exists('UISTATE.TXT') and not (out/'PREVIOUS-STATE.TXT').exists():(out/'PREVIOUS-STATE.TXT').write_bytes(fs.readbytes('UISTATE.TXT'))
  observer_write(fs,'UISTATE.TXT',b'')
  observer_write(fs,'UITASK.TXT',b'0 SNAP\r\n'+b' '*4088)
  auto='@ECHO OFF\nPATH C:\\;C:\\WINDOWS;C:\\DOS\nC:\nCD \\WINDOWS\nWIN /R\nECHO RETURNED>C:\\RETURN2.TXT\n'
  observer_write(fs,'AUTOEXEC.BAT',auto.replace('\n','\r\n').encode('ascii'))
 cfg=(old/'86box.cfg').read_text(encoding='utf-8-sig');cfg=re.sub(r'^hdd_01_fn\s*=.*$','hdd_01_fn = '+image.as_posix(),cfg,flags=re.M)
 (out/'86box.cfg').write_bytes(cfg.replace('\n','\r\n').encode('ascii'))
 prep.update(route='Actual native menu SETUP completed in previous bounded run; focused normal cold boot, no repair or driver/font/INI edits',reused_image=str(image),image_before=r.pin(image.read_bytes()))
 (out/'PREPARE.json').write_text(json.dumps(prep,indent=2)+'\n',encoding='ascii')
 return out,image

if __name__=='__main__':
 assert '--coordinated' in sys.argv,'Peer-coordinated slot required'
 start=time.monotonic();deadline=start+1200
 out32,image32=recovery.prepare();out64,image64=prepare640()
 runner=r.Lease(r.ROOT/'COMPACT-WINDOWS-LEASE-03.json',r.LOCK);assert not runner.record.exists()
 with runner.lease():
  for mode,width,out,image,return_name,save_name in [
      ('320C',320,out32,image32,'RETURN1.TXT','CMPNOTE.TXT'),
      ('640C',640,out64,image64,'RETURN2.TXT','CMPNOTE2.TXT')]:
   bound=min(900 if mode=='320C' else 400,int(deadline-time.monotonic())-5)
   assert bound>=200,'Insufficient remaining slot; no new child'
   result=r.run_case(mode,width,runner,bound,out,image,return_name,save_name)
   assert result['status']=='PASS_NATIVE_COMPACT_WINDOWS',result.get('error')
   if mode=='320C':
    with r.PyFatFS(str(image),offset=17408,read_only=True) as fs:
     assert fs.readbytes('RECOVER.OK')==b'RECOVERED\r\n'
     (out/'RECOVER.LOG').write_bytes(fs.readbytes('RECOVER.LOG'))
