#include <assert.h>
#include "PANKEY.C"
static int posts,chain,control=1,post_ok=1,remove_ok=1,reenter=0;
static void dummy(void){}
int GetKeyState(int key){return control?0x8000:0;}
int PostMessage(HWND h,WORD m,WORD w,long l){assert(h);posts++;return post_ok;}
int DefHookProc(int c,WORD k,DWORD b,FARPROC *p){chain++;if(reenter){assert(!PanKeyRemove());}return 7;}
FARPROC GetProcAddress(HINSTANCE h,const char *n){return dummy;}
FARPROC SetWindowsHook(int kind,FARPROC proc){return NULL;}
int UnhookWindowsHook(int kind,FARPROC proc){return remove_ok;}
int main(void){int i;
 LibMain((HINSTANCE)1,0,0,NULL);
 assert(PanKeyInstall((HWND)2,100));
 assert(!PanKeyInstall((HWND)3,100));
 assert(PanKeyHook(-1,VK_RIGHT,0x20000000L)==7);
 PanKeyHook(0,VK_RIGHT,0xa0000000L);
 control=0;PanKeyHook(0,VK_RIGHT,0x20000000L);control=1;
 assert(PanKeyNext()==0 && posts==0 && chain==3);
 for(i=0;i<31;i++)PanKeyHook(0,VK_RIGHT,0x20000000L);
 assert(posts==1);
 PanKeyHook(0,VK_LEFT,0x20000000L);
 for(i=0;i<31;i++)assert(PanKeyNext()==CMD_RIGHT);
 assert(PanKeyNext()==0);
 post_ok=0;PanKeyHook(0,VK_DOWN,0x20000000L);
 assert(PanKeyNext()==CMD_DOWN && PanKeyNext()==0);
 post_ok=1;PanKeyHook(0,VK_HOME,0x20000000L);
 assert(PanKeyNext()==CMD_HOME);
 reenter=1;PanKeyHook(0,VK_LEFT,0x20000000L);reenter=0;assert(live && !owner);
 assert(PanKeyRemove());assert(PanKeyInstall((HWND)2,100));
 remove_ok=0;assert(!PanKeyRemove());
 i=posts;PanKeyHook(0,VK_LEFT,0x20000000L);assert(posts==i);
 assert(!PanKeyInstall((HWND)4,100));
 remove_ok=1;assert(PanKeyRemove());
 assert(PanKeyInstall((HWND)4,100));assert(PanKeyRemove());
 return 0;}
