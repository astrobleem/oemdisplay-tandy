#define FAR
#define PASCAL
#define NULL ((void*)0)
#define TRUE 1
#define FALSE 0
#define HC_ACTION 0
#define WH_KEYBOARD 2
#define VK_HOME 36
#define VK_END 35
#define VK_LEFT 37
#define VK_RIGHT 39
#define VK_UP 38
#define VK_DOWN 40
#define VK_NUMPAD1 97
#define VK_NUMPAD2 98
#define VK_NUMPAD4 100
#define VK_NUMPAD6 102
#define VK_NUMPAD7 103
#define VK_NUMPAD8 104
#define VK_CONTROL 17
typedef unsigned short WORD;
typedef unsigned char BYTE;
typedef unsigned long DWORD;
typedef int BOOL;
typedef void *HINSTANCE;
typedef void *HWND;
typedef char *LPSTR;
typedef void (*FARPROC)(void);
int GetKeyState(int);
int PostMessage(HWND,WORD,WORD,long);
int DefHookProc(int,WORD,DWORD,FARPROC*);
FARPROC GetProcAddress(HINSTANCE,const char*);
FARPROC SetWindowsHook(int,FARPROC);
int UnhookWindowsHook(int,FARPROC);
