from pathlib import Path
import base64,hashlib,json,msvcrt,os,re,shutil,socket,subprocess,sys,threading,time
ROOT=Path(__file__).resolve().parent
sys.path[:0]=[r'C:\Users\chad\Documents\Codex\2026-10-14\task-16\deps-local',r'E:\DOSMCP\mcp-server']
from pyfatfs.PyFatFS import PyFatFS
from src.gdbclient import GdbClient
from src.headless_input import HeadlessCtl,type_string,alt_tap,hold_modifier_and_tap,SC_ALT,SC_CTRL
SOURCE=Path(r'C:\Users\chad\Documents\Codex\2026-10-24\task-3\native\PC1512-SETUP\DISK.IMG')
EXE=Path(r'C:\Users\chad\Documents\Codex\2026-10-16\task-10\EMU-STOS1\fixed\86Box.exe')
LOCK=Path(r'C:\Users\chad\Documents\Codex\2026-10-06\tandy-emulator.lock')
PROBE=os.environ.get('PANGUI_PROBE','CGAMET')
INJECT=os.environ.get('PANGUI_INJECT_DRV')
def ident(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def verify_installed(fs,packet,mode,skip=()):
 record=json.loads((packet/'CGADEV.JSN').read_bytes());checked={}
 for name,pin in record['payload'].items():
  if not pin['installed'] or pin['installed'] in skip:continue
  destination=pin.get('destination','SYSTEM')
  assert destination in ('SYSTEM','WINDOWS'),(name,destination)
  path='WINDOWS/'+('SYSTEM/' if destination=='SYSTEM' else '')+pin['installed']
  data=fs.readbytes(path)
  assert ident(data)=={key:pin[key] for key in ('bytes','sha256')},path
  checked[path]=ident(data)
 system=fs.readbytes('WINDOWS/SYSTEM.INI').decode('latin1')
 display=re.search(r'^display\.drv=(.*?)\r?$',system,re.M|re.I)
 assert display and display[1].upper()=='CGA'+mode+'.DRV','Installed display selection'
 win=fs.readbytes('WINDOWS/WIN.INI').decode('latin1')
 load=re.search(r'^load=(.*?)\r?$',win,re.M|re.I)
 tokens=re.split(r'[\s,]+',load[1].upper()) if load else []
 if 'helper_by_mode' in record:
  want=record['helper_by_mode'][mode]
  assert want in tokens and all(h not in tokens for h in set(record['helper_by_mode'].values())-{want}),'Mode-specific helper autoload'
 elif 'CGACTL.EXE' in record['payload']:
  assert ('CGACTL.EXE' in tokens)==(mode in record.get('helper_autoload_modes',['100'])),'Mode-specific helper autoload'
 return {'status':'PASS_ACTUAL_INSTALLED_BYTES_AND_SELECTION','packet':str(packet),
         'mode':mode,'installed':checked,'developer_injected':sorted(skip),'helper_load_tokens':tokens,
         'runtime_helper':'Separate native OWNER/API/lifecycle checks required'}
def prepare(out,mode,packet,probe):
 out.mkdir();image=SOURCE.read_bytes()
 assert hashlib.sha256(image).hexdigest()=='37d831fe15f1df18313b496e5a168a5516d81f532eb492a2f9d2b46fb99bdf35'
 (out/'DISK.IMG').write_bytes(image)
 with PyFatFS(str(out/'DISK.IMG'),offset=17408) as fs:
  def put(n,b):
   if fs.exists(n):fs.remove(n)
   fs.writebytes(n,b)
  ini=fs.readbytes('WINDOWS/SYSTEM.INI').decode('latin1')
  # Replace the existing boot display only; stock CGA is the reversible baseline.
  ini=re.sub(r'^display.drv=.*$', 'display.drv=CGA.DRV\r',ini,flags=re.M|re.I)
  put('WINDOWS/SYSTEM.INI',ini.encode('latin1'))
  win=fs.readbytes('WINDOWS/WIN.INI').decode('latin1')
  win=re.sub(r'^load=.*$',lambda m:'load=C:\\'+PROBE+'.EXE\r',win,flags=re.M|re.I)
  win=re.sub(r'^run=.*$', 'run=\r',win,flags=re.M|re.I)
  if os.environ.get('PANGUI_EDGE'):win=win.rstrip()+'\r\n[PanWatch]\r\nEdge='+os.environ['PANGUI_EDGE']+'\r\n'
  if os.environ.get('PANGUI_INI'):win=win.rstrip()+'\r\n'+os.environ['PANGUI_INI'].replace('|','\r\n')+'\r\n'
  put('WINDOWS/WIN.INI',win.encode('latin1'))
  put(PROBE+'.EXE',(ROOT/probe/(PROBE+'.EXE')).read_bytes())
  if INJECT:put('INJECT.DRV',Path(INJECT).read_bytes())
  fs.makedirs('CGA',recreate=True)
  for p in (ROOT/packet/'expanded/CGA').iterdir():put('CGA/'+p.name,p.read_bytes())
  put('SETUP.EXE',(ROOT/packet/'expanded/SETUP.EXE').read_bytes())
  bat='@ECHO OFF\r\nPATH C:\\;C:\\WINDOWS;C:\\DOS\r\nC:\r\nCD \\\r\nSETUP C:\\WINDOWS '+mode+' > C:\\INSTALL.LOG\r\nIF ERRORLEVEL 1 GOTO FAIL\r\n'+('COPY C:\\INJECT.DRV C:\\WINDOWS\\SYSTEM\\CGA100.DRV > C:\\INJECT.LOG\r\n' if INJECT else '')+'MEM > C:\\MEM.TXT\r\nCD \\WINDOWS\r\nWIN /R'+os.environ.get('PANGUI_WINARGS','')+'\r\nECHO RETURNED>C:\\CGARET.TXT\r\nGOTO END\r\n:FAIL\r\nECHO FAILED>C:\\CGARET.TXT\r\n:END\r\n'
  put('AUTOEXEC.BAT',bat.encode('ascii'))
 config='''[General]
confirm_exit = 0
confirm_reset = 0
confirm_save = 0
enable_overscan = 1
video_filter_method = 0
[Machine]
cpu_family = 8088
cpu_multi = 1
cpu_speed = 4772728
cpu_use_dynarec = 0
machine = ibmxt86
mem_size = 640
time_sync = disabled
[Video]
gfxcard = cga
[IBM CGA]
display_type = 0
composite_type = 1
rgb_type = 0
snow_enabled = 1
double_type = 1
[Input devices]
keyboard_type = keyboard_pc_xt
mouse_type = msserial
[Storage controllers]
hdc_1 = xtide
[Hard disks]
hdd_01_fn = DISK.IMG
hdd_01_ide_channel = 0:0
hdd_01_parameters = 34, 5, 969, 0, ide
hdd_01_speed = ramdisk
[PC/XT XTIDE #1]
bios = xt
[Floppy and CD-ROM drives]
fdd_01_turbo = 1
fdd_01_type = 525_2dd
fdd_02_type = none
'''
 (out/'86box.cfg').write_text(config)
 (out/'PREPARE.JSON').write_text(json.dumps({'source_image':ident(image),'mode':mode,'config':ident(config.encode()),'probe':ident((ROOT/probe/(PROBE+'.EXE')).read_bytes()),'probe_name':PROBE,'injected_driver':ident(Path(INJECT).read_bytes()) if INJECT else None,'packet':str(ROOT/packet)},indent=2))
def run(out,wait_lease=False,bound=900):
 assert bound in (900,1200)
 result={'complete':False,'bound_seconds':bound,'minimum_free_bytes':512*1024**2,'capture_bound_bytes':32*1024**2,'host_log_bound_bytes':32*1024**2};p=g=ctl=watch=None;acquired=False;start=time.monotonic();last=0;last_stage=''
 monitor_stop=threading.Event();monitor=None
 with LOCK.open('rb') as lease:
  try:
   assert lease.read(1), 'Shared lease is empty; launch refused'
   lease.seek(0)
   assert shutil.disk_usage(out).free>=1024**3,'Less than1GiB free; native launch refused'
   queued=time.monotonic();announced=False
   while True:
    try:
     lease.seek(0);msvcrt.locking(lease.fileno(),msvcrt.LK_NBLCK,1);break
    except OSError:
     if not wait_lease or time.monotonic()-queued>900:raise
     if (out/'STOP-QUEUE').exists():raise InterruptedError('Queued native launch cancelled')
     if not announced:print('Waiting for normal shared lease; no emulator launched',flush=True);announced=True
     time.sleep(1)
   acquired=True;result['lease_acquired']=True;result['queue_seconds']=round(time.monotonic()-queued,1);start=time.monotonic()
   assert shutil.disk_usage(out).free>=1024**3,'Capacity changed while queued; native launch refused'
   count=subprocess.check_output(['powershell.exe','-NoProfile','-Command','@(Get-Process -Name dosbox*,86Box,TRACEIO,FIXBOX,pcem,tandybox -ErrorAction SilentlyContinue).Count'],text=True).strip()
   assert count=='0','Existing emulator; no process touched'
   assert not (out/'STARTED.JSN').exists(),'Clone already used'
   for port in [12345,12346]:
    with socket.socket() as s:assert s.connect_ex(('127.0.0.1',port))!=0,'Port already in use'
   (out/'STARTED.JSN').write_text(json.dumps({'started':time.time()}))
   si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0
   env=dict(os.environ,QT_QPA_PLATFORM='offscreen',PATH=r'C:\msys64\ucrt64\bin;'+os.environ.get('PATH',''))
   with (out/'HOST.LOG').open('wb') as host:
    p=subprocess.Popen([str(EXE),'-P',str(out),'-R',r'E:\x86box\roms','-N'],cwd=out,env=env,stdout=host,stderr=subprocess.STDOUT,startupinfo=si,creationflags=subprocess.CREATE_NO_WINDOW)
    result['owned_pid']=p.pid;result['emulator']=ident(EXE.read_bytes());(out/'OWNED.JSON').write_text(json.dumps(result))
    def resources():
     while not monitor_stop.wait(2):
      captures=[q for q in out.iterdir() if q.suffix.upper() in ('.PNG','.VRM')]
      free=shutil.disk_usage(out).free
      size=sum(q.stat().st_size for q in captures)
      host_size=(out/'HOST.LOG').stat().st_size
      if free<result['minimum_free_bytes'] or size>result['capture_bound_bytes'] or host_size>result['host_log_bound_bytes'] or len(captures)>192:
       result['resource_guard']={'free_bytes':free,'capture_bytes':size,'host_log_bytes':host_size,'capture_files':len(captures)}
       if p.poll() is None:p.kill()
       return
    monitor=threading.Thread(target=resources,daemon=True);monitor.start()
    watch=threading.Timer(bound,lambda:p.kill() if p.poll() is None else None);watch.daemon=True;watch.start()
    for _ in range(60):
     assert p.poll() is None,'Emulator exited'
     try:g=GdbClient(timeout=3);g.connect();ctl=HeadlessCtl('127.0.0.1',12346);break
     except (OSError,ConnectionError):
      if g:g.close();g=None
      time.sleep(.3)
    assert g and ctl,'Control unavailable'
    while time.monotonic()-start<bound-20:
     assert p.poll() is None,'Emulator exited'
     g.run_while(lambda:None,settle_seconds=3,start_delay=.01)
     if not result.get('rom_floppy_prompt_acknowledged') and time.monotonic()-start>40:
      textbytes=g.read_memory(0xb8000,4000)[::2]
      if b'RESUME' in textbytes and b'F1' in textbytes:
       g.run_while(lambda:type_string(ctl,'{F1}'),settle_seconds=2,start_delay=.05)
       result['rom_floppy_prompt_acknowledged']=True
     req={}
     if (out/'REQUEST.JSON').exists():
      try:req=json.loads((out/'REQUEST.JSON').read_text())
      except (ValueError,OSError):pass
     if req.get('id',0)>last:
      last=req['id'];action=req.get('action')
      if action=='stop':result['complete']=True;break
      for step in req.get('steps',[req]):
       def keys():
        if step.get('action')=='type':type_string(ctl,step['text'],inter_char_ms=80)
        elif step.get('action')=='alt':alt_tap(ctl,step['key'])
        elif step.get('action')=='combo':hold_modifier_and_tap(ctl,SC_ALT if step['modifier']=='alt' else SC_CTRL,int(step['scan']))
        elif step.get('action')=='chord':
         scans=[SC_CTRL,SC_ALT,int(step['scan'])]
         try:
          for sc in scans:ctl.key(True,sc);time.sleep(.08)
          time.sleep(step.get('hold',1.2))
         finally:
          for sc in reversed(scans):ctl.key(False,sc);time.sleep(.08)
       g.run_while(keys,settle_seconds=step.get('settle',3),start_delay=.05)
       if step.get('label'):(out/(step['label']+'.PNG')).write_bytes(base64.b64decode(ctl.capture_frame_png_b64()))
      (out/(str(last).zfill(3)+'.PNG')).write_bytes(base64.b64decode(ctl.capture_frame_png_b64()))
      if req.get('vram',False):(out/(str(last).zfill(3)+'.VRM')).write_bytes(g.read_memory(0xb8000,16384))
     status={'seconds':round(time.monotonic()-start,1),'action':last,'bios_mode':g.read_memory(0x449,1)[0],'conventional_kb':int.from_bytes(g.read_memory(0x413,2),'little'),'pc':g.cs_ip_display()}
     with PyFatFS(str(out/'DISK.IMG'),offset=17408,read_only=True) as fs:
      for n in ['INSTALL.LOG',PROBE+'.LOG','INJECT.LOG','CGARET.TXT','D100.TXT','D320.TXT','D640.TXT','MEM.TXT','WINDOWS/SYSTEM.INI','WINDOWS/WIN.INI']:
       if fs.exists(n):
        b=fs.readbytes(n);(out/n.replace('/','-')).write_bytes(b)
        if n in ['INSTALL.LOG',PROBE+'.LOG','INJECT.LOG','CGARET.TXT','D100.TXT','D320.TXT','D640.TXT','MEM.TXT']:status[n]=b.decode('latin1')[-3000:]
      if PROBE+'.LOG' in status and not (out/'INSTALLVERIFY.JSON').exists():
       prep=json.loads((out/'PREPARE.JSON').read_text())
       if prep.get('packet') and prep.get('mode'):
        verified=verify_installed(fs,Path(prep['packet']),prep['mode'],('CGA'+prep['mode']+'.DRV',) if prep.get('injected_driver') else ())
        (out/'INSTALLVERIFY.JSON').write_text(json.dumps(verified,indent=2))
     stage='windows' if PROBE+'.LOG' in status else 'install' if 'INSTALL.LOG' in status else 'boot'
     if stage!=last_stage:
      last_stage=stage;print(stage,status['seconds'],flush=True)
      (out/(stage.upper()+'.PNG')).write_bytes(base64.b64decode(ctl.capture_frame_png_b64()))
     (out/'STATUS.JSON').write_text(json.dumps(status,indent=2))
    else:raise TimeoutError('Qualification bound reached')
  except BaseException as e:
   result['error']=repr(e)
   if ctl:
    try:(out/'STOPPED.PNG').write_bytes(base64.b64decode(ctl.capture_frame_png_b64()))
    except Exception:pass
  finally:
   monitor_stop.set()
   if monitor:monitor.join(timeout=3)
   if watch:watch.cancel()
   if ctl:ctl.close()
   if g:g.close()
   if p and p.poll() is None:p.kill();p.wait(timeout=10)
   result['owned_stopped']=p is None or p.poll() is not None
   if acquired:lease.seek(0);msvcrt.locking(lease.fileno(),msvcrt.LK_UNLCK,1);result['lease_released']=True
   result['seconds']=time.monotonic()-start;(out/'RESULT.JSON').write_text(json.dumps(result,indent=2))
 print(json.dumps(result,indent=2));return 0 if result['complete'] else 1
if __name__=='__main__':
 out=ROOT/sys.argv[2]
 if sys.argv[1]=='prepare':prepare(out,sys.argv[3],sys.argv[4],sys.argv[5])
 else:sys.exit(run(out,'wait' in sys.argv[3:],1200 if '1200' in sys.argv[3:] else 900))
