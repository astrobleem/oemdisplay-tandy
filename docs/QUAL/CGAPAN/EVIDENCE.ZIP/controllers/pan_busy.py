"""Busy-load input: Ctrl+Alt commands sent while Paintbrush is still reading its
bitmap must all be retained and applied in order afterwards. Follow and edge
panning are switched off in WIN.INI so only the commands move the view.
Sequence R R R Home D D R is expected to end at 40,50."""
import json, sys, time
from pathlib import Path
import cga_actions as A

ROOT = Path(__file__).resolve().parent
out = ROOT / sys.argv[1]
RIGHT, LEFT, UP, DOWN, HOME, END = 77, 75, 72, 80, 71, 79
SEQUENCE = [RIGHT, RIGHT, RIGHT, HOME, DOWN, DOWN, RIGHT]


def log():
    try:
        return (out / 'PANWATCH.LOG').read_text(errors='replace')
    except OSError:
        return ''


def wait_for(text, seconds=240, start=0):
    end = time.monotonic() + seconds
    while time.monotonic() < end:
        if text in log()[start:]:
            return True
        assert not (out / 'RESULT.JSON').exists(), 'Runner ended before ' + text
        time.sleep(1)
    raise TimeoutError(text)


# PANWATCH writes this line at once; its timer (and so OWNER/ACTIVE) only runs once
# Paintbrush has finished loading, so start sending while Windows is still busy.
wait_for('PANWATCH START', 900)
time.sleep(12)          # let PANCTL finish starting; the load runs for about 70 s
mark = len(log())
for i, scan in enumerate(SEQUENCE, 1):
    A.send(out, 'busy%d' % i, [{'action': 'chord', 'scan': scan, 'hold': 0.15, 'settle': 1}], vram=False)
print('chords sent', flush=True)
wait_for('VIEW 40,50', int(sys.argv[2]) if len(sys.argv) > 2 else 600, mark)   # applied once the load finishes
time.sleep(20)
A.send(out, 'busy result', [A.key('', 6)])
# Capture useful views, then prove the normal application and Windows exits.
A.send(out, 'maximize Paintbrush', [A.alt(' '), A.key('x', 10)])
A.send(out, 'top-left view', [{'action':'chord','scan':71,'hold':0.15,'settle':8,'label':'PAINT-HOME'}])
A.send(out, 'bottom-right view', [{'action':'chord','scan':79,'hold':0.15,'settle':8,'label':'PAINT-END'}])
A.send(out, 'close Paintbrush', [{'action':'combo','modifier':'alt','scan':62,'settle':10}])
A.send(out, 'exit Windows', [{'action':'combo','modifier':'alt','scan':62,'settle':6},A.key('{ENTER}',20)])
end=time.monotonic()+180
while time.monotonic()<end:
    if 'RETURNED' in A.status(out).get('CGARET.TXT',''):
        print('returned to DOS',flush=True);break
    time.sleep(2)
else:raise AssertionError('Windows did not return normally to DOS')
(out/'REQUEST.NEW').write_text(json.dumps({'id':A.status(out).get('action',0)+5,'action':'stop'}))
(out/'REQUEST.NEW').replace(out/'REQUEST.JSON')
