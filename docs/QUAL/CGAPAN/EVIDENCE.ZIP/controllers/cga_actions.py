"""Private requests to an already-owned, bounded native test runner."""
from pathlib import Path
import json,time
ROOT=Path(__file__).resolve().parent
def status(out):
 try:return json.loads((out/'STATUS.JSON').read_text())
 except (OSError,ValueError):return {}
def send(out,label,steps,vram=True):
 assert out.parent==ROOT and (out/'OWNED.JSON').exists()
 assert not (out/'RESULT.JSON').exists(),'Owned runner already ended'
 old=json.loads((out/'REQUEST.JSON').read_text()).get('id',0) if (out/'REQUEST.JSON').exists() else 0
 serial=max(old,status(out).get('action',0))+1
 (out/'REQUEST.NEW').write_text(json.dumps({'id':serial,'action':'sequence','steps':steps,'vram':vram}))
 (out/'REQUEST.NEW').replace(out/'REQUEST.JSON')
 end=time.monotonic()+180
 while time.monotonic()<end:
  if status(out).get('action',0)>=serial:print(label,serial,flush=True);return serial
  assert not (out/'RESULT.JSON').exists(),'Owned runner ended'
  time.sleep(.5)
 raise TimeoutError(label)
def key(text,settle=4,label=None):
 v={'action':'type','text':text,'settle':settle}
 if label:v['label']=label
 return v
def alt(ch):return {'action':'alt','key':ch,'settle':3}
