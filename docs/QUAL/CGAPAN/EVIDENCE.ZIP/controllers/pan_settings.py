"""Settings check: open the shared panning window, tab through it, apply a
change, prove the next command and the edge setting honour it, exit cleanly."""
import json, sys, time
from pathlib import Path
import cga_actions as A

ROOT = Path(__file__).resolve().parent
out = ROOT / sys.argv[1]
SC_S, SC_RIGHT = 31, 77


def log():
    try:
        return (out / 'PANWATCH.LOG').read_text(errors='replace')
    except OSError:
        return ''


def wait_for(text, seconds=240, start=0):
    end = time.monotonic() + seconds
    while time.monotonic() < end:
        if text in log()[start:]:
            return True
        assert not (out / 'RESULT.JSON').exists(), 'Runner ended before ' + text
        time.sleep(1)
    raise TimeoutError(text)


def chord(scan, hold=0.15, settle=4):
    return {'action': 'chord', 'scan': scan, 'hold': hold, 'settle': settle}


wait_for('PANWATCH START', 900)
wait_for('OWNER pan=1 slide=0', 120)
wait_for('SETTLED', 300)
A.send(out, 'desktop', [A.key('', 4)])

mark = len(log())
A.send(out, 'open settings (Ctrl+Alt+S)', [chord(SC_S)])
wait_for('txt=CGAPAN panning', 120, mark)
wait_for('TREE END', 120, mark)
A.send(out, 'dialog', [A.key('', 6)])

# One full Tab cycle: Step, Dwell, Follow, Edge, Home, Apply, Cancel.
for i in range(1, 8):
    A.send(out, 'tab%d' % i, [A.key('{TAB}', 3)])

# Back on Step: 20 is not a multiple of 8, so the owner must round it (24).
# Then Dwell, Follow, Edge; space clears Edge; Enter is the default Apply.
A.send(out, 'edit and apply', [A.key('{END}{BACK}{BACK}20', 2), A.key('{TAB}{TAB}{TAB}', 2), A.key(' ', 2),
                               A.key('{ENTER}', 6)])
A.send(out, 'applied', [A.key('', 4)])
A.send(out, 'close (Cancel)', [A.key('{ESC}', 5)])

mark = len(log())     # before the chord: the edge push follows 8 s after the close
A.send(out, 'Ctrl+Alt+Right with the new step', [chord(SC_RIGHT)])
wait_for('VIEW 24,0', 120, mark)
A.send(out, 'moved', [A.key('', 4)])

# PANWATCH pushes the pointer to the right edge 8 s after the window closed.
wait_for('EDGE after settings', 120, mark)
time.sleep(30)
A.send(out, 'edge settled', [A.key('', 4)])

# Exit Windows to DOS: close the active application, then Program Manager.
A.send(out, 'exit Windows', [{'action': 'combo', 'modifier': 'alt', 'scan': 62, 'settle': 6},
                             A.key('{ENTER}', 15)])
end = time.monotonic() + 120
while time.monotonic() < end:
    if 'RETURNED' in A.status(out).get('CGARET.TXT', ''):
        break
    time.sleep(2)
else:
    raise AssertionError('Windows did not return normally to DOS')
time.sleep(3)
(out / 'REQUEST.NEW').write_text(json.dumps({'id': A.status(out).get('action', 0) + 5, 'action': 'stop'}))
(out / 'REQUEST.NEW').replace(out / 'REQUEST.JSON')
print('stop requested', flush=True)
